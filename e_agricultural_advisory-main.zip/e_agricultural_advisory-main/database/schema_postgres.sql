-- ============================================================
-- BASE SCHEMA — PostgreSQL
-- Date: 2026-11-18
--
-- This is the canonical schema for a NEW PostgreSQL database
-- (the system moved from MySQL/Aiven to PostgreSQL). It contains
-- base tables only — product images are added afterwards by
-- database/migrations/001, so the migration path stays testable.
--
-- How to build a fresh database:
--   1. createdb <database_name>
--   2. psql <database_name> < schema_postgres.sql
--   3. psql <database_name> < migrations/001_market_listings_image_url.sql
--   4. psql <database_name> < migrations/002_chatroom.sql
--   5. psql <database_name> < migrations/003_seed_chat_rooms.sql
--
-- Conventions:
--   * SERIAL primary keys (auto-increment)
--   * TIMESTAMPTZ for all timestamps (timezone-safe)
--   * CHECK constraints instead of MySQL ENUMs (easier to alter)
--   * Foreign keys with explicit ON DELETE behaviour
-- ============================================================

-- ------------------------------------------------------------
-- Users (registration / login / roles)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  user_id    SERIAL PRIMARY KEY,
  full_name  VARCHAR(150) NOT NULL,
  email      VARCHAR(190) NOT NULL UNIQUE,
  phone      VARCHAR(30),
  password   VARCHAR(255) NOT NULL,
  role       VARCHAR(10) NOT NULL DEFAULT 'farmer'
             CHECK (role IN ('farmer', 'advisor', 'admin')),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- Crops (referenced by advisories)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS crops (
  crop_id SERIAL PRIMARY KEY,
  name    VARCHAR(100) NOT NULL UNIQUE
);

-- ------------------------------------------------------------
-- Advisories (structure preserved from the original MySQL dump)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS advisories (
  advisory_id  SERIAL PRIMARY KEY,
  crop_id      INT REFERENCES crops(crop_id) ON DELETE SET NULL,
  title        VARCHAR(200) NOT NULL,
  category     VARCHAR(30) DEFAULT 'general'
               CHECK (category IN ('planting', 'fertilization', 'irrigation',
                                   'weed_management', 'harvesting', 'general')),
  growth_stage VARCHAR(100),
  content      TEXT NOT NULL,
  created_by   INT REFERENCES users(user_id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_advisories_crop
  ON advisories(crop_id);
CREATE INDEX IF NOT EXISTS idx_advisories_created_by
  ON advisories(created_by);

-- ------------------------------------------------------------
-- Market listings (public browse + farmer-owned CRUD)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS market_listings (
  listing_id    SERIAL PRIMARY KEY,
  seller_id     INT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  title         VARCHAR(200) NOT NULL,
  description   TEXT,
  category      VARCHAR(20) NOT NULL DEFAULT 'produce'
                CHECK (category IN ('produce', 'seeds', 'seedlings',
                                    'fertilizer', 'other')),
  quantity      NUMERIC(14, 2) NOT NULL CHECK (quantity > 0),
  unit          VARCHAR(30) NOT NULL,
  price         NUMERIC(14, 2) NOT NULL CHECK (price >= 0),
  district      VARCHAR(60) NOT NULL,
  contact_phone VARCHAR(30),
  status        VARCHAR(10) NOT NULL DEFAULT 'available'
                CHECK (status IN ('available', 'sold')),
  created_at    TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_market_status_created
  ON market_listings(status, created_at);
CREATE INDEX IF NOT EXISTS idx_market_seller
  ON market_listings(seller_id);
CREATE INDEX IF NOT EXISTS idx_market_district
  ON market_listings(district);
