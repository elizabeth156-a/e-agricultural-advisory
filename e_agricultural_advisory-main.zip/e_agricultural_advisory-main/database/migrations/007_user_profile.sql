-- ============================================================
-- Migration: profile fields on users
-- Date: 2026-11-18  (PostgreSQL)
-- Safety: additive only. Adds nullable columns; existing rows
--         are untouched. Idempotent (IF NOT EXISTS).
--
-- How to run:  psql <database_name> < this_file.sql
--
-- Notes:
--   * district supports the register form's location field and
--     profile page.
--   * avatar_url accepts an http(s) link or a compact base64
--     data:image URL (same convention as market listings).
-- ============================================================

ALTER TABLE users ADD COLUMN IF NOT EXISTS district VARCHAR(60);
ALTER TABLE users ADD COLUMN IF NOT EXISTS bio TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_url TEXT;
