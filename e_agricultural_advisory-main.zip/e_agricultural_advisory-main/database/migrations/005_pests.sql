-- ============================================================
-- Migration: pests & diseases reference library
-- Date: 2026-11-18  (PostgreSQL)
-- Safety: additive only. Creates one new table and seeds real
--         reference content (idempotent ON CONFLICT DO NOTHING).
--         Never overwrites content an advisor has edited.
--
-- How to run:  psql <database_name> < this_file.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS pests (
  pest_id         SERIAL PRIMARY KEY,
  name            VARCHAR(150) NOT NULL UNIQUE,
  pest_type       VARCHAR(10) NOT NULL DEFAULT 'pest'
                  CHECK (pest_type IN ('pest', 'disease')),
  summary         VARCHAR(255),
  symptoms        TEXT NOT NULL,
  management      TEXT NOT NULL,
  affected_crops  VARCHAR(255),
  icon            VARCHAR(10),
  created_by      INT REFERENCES users(user_id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_pests_type
  ON pests(pest_type);

-- Seed: migrates the content that previously lived as hardcoded
-- frontend data, plus widely-recognised Ugandan field pests.
INSERT INTO pests (name, pest_type, summary, symptoms, management, icon) VALUES
  ('Fall Armyworm', 'pest', 'Common crop pest',
   'Leaves may have irregular holes and damaged areas.',
   'Regularly inspect crops and use recommended pest management practices.',
   '🐛'),
  ('Late Blight', 'disease', 'Common crop disease',
   'Dark lesions may appear on leaves and stems.',
   'Remove severely infected material and apply appropriate disease management practices.',
   '🍂'),
  ('Aphids', 'pest', 'Plant-sucking insects',
   'Small insects may cluster on young leaves and shoots.',
   'Monitor plants regularly and use appropriate integrated pest management methods.',
   '🐜'),
  ('Striga (Witchweed)', 'pest', 'Parasitic weed of cereals',
   'Purple or white flowers appear near maize and sorghum plants; affected plants are stunted and yellow.',
   'Plant early, hand-weed before Striga sets seed, rotate with non-host crops and use resistant varieties where available.',
   '🌸'),
  ('Maize Stalk Borer', 'pest', 'Stem-boring insect of maize',
   'Larvae bore into stems causing dead hearts, breakages and empty panicles.',
   'Plant in time, destroy crop residues after harvest, and use push-pull or recommended biological control where practical.',
   '🪱'),
  ('Cassava Brown Streak', 'disease', 'Viral root disease',
   'Yellowing of leaves and brown necrotic streaks inside stored roots.',
   'Use clean planting material from healthy plants and plant recommended resistant varieties.',
   '🍠')
ON CONFLICT (name) DO NOTHING;
