-- ============================================================
-- Migration: default chatroom discussion rooms
-- Date: 2026-11-18  (PostgreSQL)
-- Safety: additive only. Uses ON CONFLICT DO NOTHING against the
--         UNIQUE key on room name, so running it twice never
--         duplicates rooms and never overwrites rooms an admin
--         has edited.
-- How to run:  psql <database_name> < this_file.sql
-- ============================================================

INSERT INTO chat_rooms (name, description, icon) VALUES
  ('General Farming Discussion', 'General questions and conversations about farming in Uganda.', '💬'),
  ('Crop Farming', 'Growing, managing and harvesting crops.', '🌾'),
  ('Livestock Farming', 'Cattle, poultry, goats, pigs and other livestock.', '🐄'),
  ('Seeds and Fertilizers', 'Certified seed, fertiliser application and soil fertility.', '🌰'),
  ('Pests and Diseases', 'Identify and manage crop pests and diseases.', '🐛'),
  ('Weather and Climate', 'Rainfall patterns, forecasts and climate-smart farming.', '🌦️'),
  ('Agricultural Market Discussion', 'Prices, buyers, selling and market trends.', '🛒')
ON CONFLICT (name) DO NOTHING;
