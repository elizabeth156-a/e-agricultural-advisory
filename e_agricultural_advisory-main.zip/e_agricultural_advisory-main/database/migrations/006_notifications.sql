-- ============================================================
-- Migration: user notifications
-- Date: 2026-11-18  (PostgreSQL)
-- Safety: additive only. Creates one new table. Idempotent.
--
-- How to run:  psql <database_name> < this_file.sql
--
-- Design notes:
--   * link is a frontend path (e.g. /ask-advisor) so the bell
--     menu can navigate straight to the relevant page.
--   * Unread badge count = COUNT(*) WHERE user_id = ? AND is_read = false.
-- ============================================================

CREATE TABLE IF NOT EXISTS notifications (
  notification_id SERIAL PRIMARY KEY,
  user_id         INT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  type            VARCHAR(20) NOT NULL DEFAULT 'system'
                  CHECK (type IN ('answer', 'question', 'market', 'chat', 'system')),
  title           VARCHAR(200) NOT NULL,
  body            VARCHAR(500),
  link            VARCHAR(255),
  is_read         BOOLEAN NOT NULL DEFAULT false,
  created_at      TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notifications_user
  ON notifications(user_id, is_read, created_at DESC);
