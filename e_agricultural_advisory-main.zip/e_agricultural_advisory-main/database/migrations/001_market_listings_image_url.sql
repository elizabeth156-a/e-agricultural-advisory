-- ============================================================
-- Migration: product images for market listings
-- Date: 2026-11-18  (PostgreSQL)
-- Safety: additive only. Does not modify or remove any
--         existing columns, rows or tables. Idempotent.
--
-- How to run:  psql <database_name> < this_file.sql
--
-- image_url accepts:
--   * an http(s) link to an image, or
--   * a compact base64 data:image/... URL produced by the
--     browser after resizing (no temporary files on Render).
-- ============================================================

ALTER TABLE market_listings
  ADD COLUMN IF NOT EXISTS image_url TEXT;
