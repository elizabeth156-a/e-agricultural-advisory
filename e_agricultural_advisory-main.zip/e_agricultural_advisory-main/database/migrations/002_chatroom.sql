-- ============================================================
-- Migration: farmer chatroom (database-backed messaging)
-- Date: 2026-11-18  (PostgreSQL)
-- Safety: additive only. Creates new tables; does not modify
--         any existing table, column or row. Idempotent.
--
-- How to run:  psql <database_name> < this_file.sql
--
-- Design notes:
--   * chat_room_reads tracks each member's read pointer so the
--     UI can show unread counts without extra tables.
--   * message_reports enforces one report per user per message
--     via UNIQUE (message_id, reporter_id).
--   * ON DELETE CASCADE keeps data consistent when a room or
--     message is removed by an administrator.
-- ============================================================

-- ------------------------------------------------------------
-- Discussion rooms
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chat_rooms (
  room_id     SERIAL PRIMARY KEY,
  name        VARCHAR(100) NOT NULL UNIQUE,
  description VARCHAR(255),
  icon        VARCHAR(10),
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- Messages
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chat_messages (
  message_id BIGSERIAL PRIMARY KEY,
  room_id    INT NOT NULL REFERENCES chat_rooms(room_id) ON DELETE CASCADE,
  sender_id  INT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  body       VARCHAR(5000) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Message paging is WHERE room_id = ? ORDER BY message_id DESC LIMIT ?
CREATE INDEX IF NOT EXISTS idx_chat_messages_room_id
  ON chat_messages(room_id, message_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_sender
  ON chat_messages(sender_id);

-- ------------------------------------------------------------
-- Read pointers for unread indicators
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chat_room_reads (
  user_id              INT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  room_id              INT NOT NULL REFERENCES chat_rooms(room_id) ON DELETE CASCADE,
  last_read_message_id BIGINT NOT NULL DEFAULT 0,
  updated_at           TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, room_id)
);

-- ------------------------------------------------------------
-- Reported messages (moderation)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS message_reports (
  report_id   SERIAL PRIMARY KEY,
  message_id  BIGINT NOT NULL
              REFERENCES chat_messages(message_id) ON DELETE CASCADE,
  reporter_id INT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  reason      VARCHAR(500) NOT NULL,
  status      VARCHAR(10) NOT NULL DEFAULT 'open'
              CHECK (status IN ('open', 'reviewed', 'dismissed')),
  reviewed_by INT REFERENCES users(user_id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ,
  UNIQUE (message_id, reporter_id)
);

CREATE INDEX IF NOT EXISTS idx_message_reports_status
  ON message_reports(status);
