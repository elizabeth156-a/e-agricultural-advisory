-- ============================================================
-- Migration: Ask Advisor (questions & answers)
-- Date: 2026-11-18  (PostgreSQL)
-- Safety: additive only. Creates new tables; does not modify
--         any existing table, column or row. Idempotent.
--
-- How to run:  psql <database_name> < this_file.sql
--
-- Design notes:
--   * crop_name keeps the question even when the crop is not in
--     the crops table; crop_id is a soft reference for filtering.
--   * status: open -> answered (advisor replied) -> closed
--     (asker or advisor closed it).
--   * Answers cascade with their question; notifications for
--     answers live in migration 006.
-- ============================================================

CREATE TABLE IF NOT EXISTS questions (
  question_id SERIAL PRIMARY KEY,
  asker_id    INT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  crop_id     INT REFERENCES crops(crop_id) ON DELETE SET NULL,
  crop_name   VARCHAR(100),
  title       VARCHAR(200) NOT NULL,
  body        TEXT NOT NULL,
  status      VARCHAR(10) NOT NULL DEFAULT 'open'
              CHECK (status IN ('open', 'answered', 'closed')),
  created_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_questions_status
  ON questions(status, created_at);
CREATE INDEX IF NOT EXISTS idx_questions_asker
  ON questions(asker_id);

CREATE TABLE IF NOT EXISTS answers (
  answer_id   SERIAL PRIMARY KEY,
  question_id INT NOT NULL REFERENCES questions(question_id) ON DELETE CASCADE,
  advisor_id  INT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  body        TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_answers_question
  ON answers(question_id, created_at);
CREATE INDEX IF NOT EXISTS idx_answers_advisor
  ON answers(advisor_id);
