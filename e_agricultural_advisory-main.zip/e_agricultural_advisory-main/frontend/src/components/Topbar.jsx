import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";

export default function Topbar({ onMenuClick, onLogout }) {
  const { user, role } = useAuth();
  const navigate = useNavigate();

  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [unread, setUnread] = useState(0);
  const menuRef = useRef(null);

  // Unread badge: fetch on mount, on tab focus, and once a minute.
  useEffect(() => {
    let cancelled = false;

    async function loadUnread() {
      try {
        const data = await apiFetch("/api/notifications");
        if (!cancelled) setUnread(data.unread || 0);
      } catch {
        // Badge is non-critical; keep the previous value.
      }
    }

    loadUnread();
    const interval = setInterval(loadUnread, 60000);
    window.addEventListener("focus", loadUnread);

    return () => {
      cancelled = true;
      clearInterval(interval);
      window.removeEventListener("focus", loadUnread);
    };
  }, []);

  useEffect(() => {
    function handleClickOutside(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  function handleSearch(event) {
    event.preventDefault();
    const term = query.trim();
    navigate(term ? `/market?search=${encodeURIComponent(term)}` : "/market");
  }

  const roleLabel =
    role === "admin" ? "Administrator" :
    role === "advisor" ? "Advisor" :
    "Farmer";

  const initials = (user?.full_name || "?")
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");

  return (
    <header className="topbar">
      <button
        type="button"
        className="topbar-menu-btn"
        onClick={onMenuClick}
        aria-label="Toggle navigation menu"
      >
        ☰
      </button>

      <Link to="/dashboard" className="topbar-brand">
        <span aria-hidden="true">🌱</span>
        <strong>E-Agri Advisory</strong>
      </Link>

      <form className="topbar-search" onSubmit={handleSearch} role="search">
        <input
          type="search"
          placeholder="Search marketplace products..."
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          aria-label="Search marketplace products"
        />
        <button type="submit" aria-label="Search">🔍</button>
      </form>

      <div className="topbar-actions">
        <Link
          to="/notifications"
          className="topbar-icon-btn"
          aria-label={
            unread > 0
              ? `Notifications (${unread} unread)`
              : "Notifications"
          }
          title="Notifications"
        >
          🔔
          {unread > 0 && (
            <span className="topbar-badge" aria-hidden="true">
              {unread > 99 ? "99+" : unread}
            </span>
          )}
        </Link>

        <div className="user-menu" ref={menuRef}>
          <button
            type="button"
            className="user-menu-trigger"
            onClick={() => setMenuOpen((open) => !open)}
            aria-expanded={menuOpen}
            aria-haspopup="menu"
          >
            <span className="avatar" aria-hidden="true">
              {initials || "?"}
            </span>
            <span className="user-menu-meta">
              <strong>{user?.full_name || "Account"}</strong>
              <small>{roleLabel}</small>
            </span>
            <span aria-hidden="true">▾</span>
          </button>

          {menuOpen && (
            <div className="user-menu-dropdown" role="menu">
              <div className="user-menu-header">
                <strong>{user?.full_name}</strong>
                <small>{user?.email}</small>
              </div>
              <Link to="/profile" role="menuitem" onClick={() => setMenuOpen(false)}>
                👤 My Profile
              </Link>
              <Link to="/notifications" role="menuitem" onClick={() => setMenuOpen(false)}>
                🔔 Notifications
              </Link>
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setMenuOpen(false);
                  onLogout();
                }}
              >
                🚪 Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
