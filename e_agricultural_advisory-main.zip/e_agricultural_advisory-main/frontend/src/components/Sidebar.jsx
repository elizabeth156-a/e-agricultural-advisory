import { NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: "📊" },
  { to: "/advisories", label: "Agricultural Advisories", icon: "🌱" },
  { to: "/weather", label: "Weather", icon: "🌦️" },
  { to: "/pests-diseases", label: "Pests & Diseases", icon: "🐛" },
  { to: "/ask-advisor", label: "Ask Advisor", icon: "💬" },
  { to: "/chatroom", label: "Farmer Chatroom", icon: "👥" },
  { to: "/market", label: "Marketplace", icon: "🛒" },
  { to: "/my-listings", label: "My Listings", icon: "🏷️", roles: ["farmer"] }
];

export default function Sidebar({ open, onClose, onLogout }) {
  const { role } = useAuth();

  const items = NAV_ITEMS.filter(
    (item) => !item.roles || item.roles.includes(role)
  );

  return (
    <>
      {open && (
        <div
          className="sidebar-overlay"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
        <div className="sidebar-brand">
          <span className="sidebar-logo" aria-hidden="true">🌱</span>
          <span className="sidebar-brand-text">
            <strong>E-Agri</strong>
            <small>Advisory System</small>
          </span>
        </div>

        <nav className="sidebar-nav" aria-label="Application">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `sidebar-link ${isActive ? "active" : ""}`
              }
              onClick={onClose}
            >
              <span className="sidebar-icon" aria-hidden="true">
                {item.icon}
              </span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <button
          type="button"
          className="sidebar-link sidebar-logout"
          onClick={() => {
            onClose();
            onLogout();
          }}
        >
          <span className="sidebar-icon" aria-hidden="true">🚪</span>
          <span>Logout</span>
        </button>
      </aside>
    </>
  );
}
