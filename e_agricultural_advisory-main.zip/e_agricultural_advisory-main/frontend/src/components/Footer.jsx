import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div>
          <h2>🌱 E-Agri Advisory</h2>
          <p>
            Empowering smallholder farmers with accessible
            digital agricultural advice and information.
          </p>
        </div>

        <div>
          <h3>Quick Links</h3>
          <Link to="/">Home</Link>
          <Link to="/advisories">Advisories</Link>
          <Link to="/weather">Weather</Link>
          <Link to="/ask-advisor">Ask Advisor</Link>
          <Link to="/market">Marketplace</Link>
        </div>

        <div>
          <h3>Services</h3>
          <Link to="/advisories">Crop Advisory</Link>
          <Link to="/pests-diseases">Pest & Disease Information</Link>
          <Link to="/weather">Weather Guidance</Link>
          <Link to="/chatroom">Farmer Chatroom</Link>
        </div>
      </div>

      <div className="footer-bottom">
        © 2026 E-Agricultural Advisory System. All rights reserved.
      </div>
    </footer>
  );
}

export default Footer;
