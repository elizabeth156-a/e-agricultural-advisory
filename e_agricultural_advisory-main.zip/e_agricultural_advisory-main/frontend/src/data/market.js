// Shared marketplace constants and formatting helpers.
export const MARKET_CATEGORIES = [
  { value: "produce", label: "Farm produce" },
  { value: "seeds", label: "Seeds" },
  { value: "seedlings", label: "Seedlings" },
  { value: "fertilizer", label: "Fertilizers" },
  { value: "other", label: "Other agricultural goods" }
];

export function categoryLabel(value) {
  const found = MARKET_CATEGORIES.find((item) => item.value === value);
  return found ? found.label : "Other agricultural goods";
}

export function formatPrice(price) {
  const amount = Number(price);
  if (!Number.isFinite(amount)) return "UGX —";
  return `UGX ${amount.toLocaleString("en-UG")}`;
}

export function formatDate(value) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("en-UG", {
    day: "numeric",
    month: "short",
    year: "numeric"
  });
}
