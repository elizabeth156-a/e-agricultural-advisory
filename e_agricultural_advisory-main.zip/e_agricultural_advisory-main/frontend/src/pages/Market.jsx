import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";
import { Alert, EmptyState, PageHeader, Spinner } from "../components/ui";
import { DISTRICT_NAMES } from "../data/districts";
import { MARKET_CATEGORIES, categoryLabel, formatPrice } from "../data/market";

const CATEGORY_ICONS = {
  produce: "🥬",
  seeds: "🌰",
  seedlings: "🌱",
  fertilizer: "🧪",
  other: "📦"
};

function ListingImage({ listing, className }) {
  const src = listing.image_url;

  if (src && /^(https?:|data:image\/)/i.test(src)) {
    return (
      <img
        className={className}
        src={src}
        alt={listing.title}
        loading="lazy"
        onError={(event) => {
          event.currentTarget.style.display = "none";
        }}
      />
    );
  }

  return (
    <div className={className} aria-hidden="true">
      {CATEGORY_ICONS[listing.category] || "📦"}
    </div>
  );
}

export { ListingImage };

export default function Market() {
  const { isAuthenticated, role } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();

  const [listings, setListings] = useState([]);
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [category, setCategory] = useState(searchParams.get("category") || "");
  const [district, setDistrict] = useState(searchParams.get("district") || "");
  const [sort, setSort] = useState(searchParams.get("sort") || "");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  // Tracks the last query string this component wrote, so the two
  // sync effects below never fight each other.
  const lastSyncedQuery = useRef("");

  // State -> URL (shareable links, no history spam).
  useEffect(() => {
    const params = new URLSearchParams();
    if (search.trim()) params.set("search", search.trim());
    if (category) params.set("category", category);
    if (district) params.set("district", district);
    if (sort) params.set("sort", sort);

    const query = params.toString();
    if (query === lastSyncedQuery.current) return;

    lastSyncedQuery.current = query;
    setSearchParams(params, { replace: true });
  }, [search, category, district, sort, setSearchParams]);

  // URL -> State (e.g. the top bar search navigated here).
  useEffect(() => {
    const query = searchParams.toString();
    if (query === lastSyncedQuery.current) return;

    lastSyncedQuery.current = query;
    setSearch(searchParams.get("search") || "");
    setCategory(searchParams.get("category") || "");
    setDistrict(searchParams.get("district") || "");
    setSort(searchParams.get("sort") || "");
  }, [searchParams]);

  useEffect(() => {
    const controller = new AbortController();

    async function loadListings() {
      setLoading(true);
      setError("");

      try {
        const params = new URLSearchParams();

        if (search.trim()) params.set("search", search.trim());
        if (category) params.set("category", category);
        if (district.trim()) params.set("district", district.trim());
        if (sort) params.set("sort", sort);

        const query = params.toString();

        const data = await apiFetch(
          `/api/market${query ? `?${query}` : ""}`,
          { signal: controller.signal }
        );

        setListings(Array.isArray(data.listings) ? data.listings : []);
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(
            "Could not load market listings. Please check your connection and try again."
          );
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    loadListings();
    return () => controller.abort();
  }, [search, category, district, sort, reloadKey]);

  const canSell = isAuthenticated && role === "farmer";

  return (
    <div className="market-page">
      <PageHeader
        eyebrow="AGRICULTURAL MARKETPLACE"
        title="Market Space"
        description="Discover farm produce, seeds, seedlings, fertilizers and other agricultural goods from sellers across Uganda."
        actions={
          canSell ? (
            <Link to="/market/new" className="btn btn-primary">
              + Sell a Product
            </Link>
          ) : isAuthenticated ? null : (
            <Link to="/login" className="btn btn-primary">
              Login to Sell
            </Link>
          )
        }
      />

      <section className="market-filters" aria-label="Filter market listings">
        <input
          className="market-input"
          type="search"
          placeholder="Search products..."
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          aria-label="Search products"
        />

        <select
          className="market-input"
          value={category}
          onChange={(event) => setCategory(event.target.value)}
          aria-label="Filter by category"
        >
          <option value="">All categories</option>
          {MARKET_CATEGORIES.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>

        <select
          className="market-input"
          value={district}
          onChange={(event) => setDistrict(event.target.value)}
          aria-label="Filter by district"
        >
          <option value="">All districts</option>
          {DISTRICT_NAMES.map((name) => (
            <option key={name} value={name}>
              {name}
            </option>
          ))}
        </select>

        <select
          className="market-input"
          value={sort}
          onChange={(event) => setSort(event.target.value)}
          aria-label="Sort by price"
        >
          <option value="">Newest first</option>
          <option value="price_asc">Price: lowest first</option>
          <option value="price_desc">Price: highest first</option>
        </select>
      </section>

      {loading && <Spinner label="Loading market listings..." />}

      {!loading && error && (
        <div role="alert">
          <Alert type="error">{error}</Alert>
          <button
            className="btn btn-secondary"
            onClick={() => setReloadKey((key) => key + 1)}
          >
            Try again
          </button>
        </div>
      )}

      {!loading && !error && listings.length === 0 && (
        <EmptyState
          icon="🛒"
          title="No listings found"
          message="There are no matching products yet. Try another search or check back later."
          action={
            canSell ? (
              <Link to="/market/new" className="btn btn-primary">
                Be the first to sell here
              </Link>
            ) : null
          }
        />
      )}

      {!loading && !error && listings.length > 0 && (
        <>
          <p className="market-count">
            <strong>{listings.length}</strong> listing(s) found
          </p>

          <section className="market-grid">
            {listings.map((item) => (
              <article key={item.listing_id} className="market-card">
                <Link to={`/market/${item.listing_id}`} aria-label={`View ${item.title}`}>
                  <ListingImage listing={item} className="market-card-image" />
                </Link>

                <div className="market-card-body">
                  <span className="badge badge-green">
                    {categoryLabel(item.category)}
                  </span>

                  <Link to={`/market/${item.listing_id}`}>
                    <h2 className="market-card-title">{item.title}</h2>
                  </Link>

                  <p className="market-card-desc">
                    {item.description || "No description provided."}
                  </p>

                  <p className="market-price">{formatPrice(item.price)}</p>

                  <p className="market-meta">
                    {item.quantity} {item.unit} · {item.district}
                  </p>

                  <div className="market-card-footer">
                    <span className="market-meta">
                      👤 {item.seller_name || "Farmer"}
                    </span>
                    <Link
                      to={`/market/${item.listing_id}`}
                      className="panel-link"
                    >
                      View details →
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </section>
        </>
      )}
    </div>
  );
}
