import { useEffect, useState } from "react";
import { apiFetch } from "../api/client";
import { Alert, EmptyState, Spinner } from "../components/ui";

function PestsDiseases() {
  const [pests, setPests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [search, setSearch] = useState("");
  const [appliedSearch, setAppliedSearch] = useState("");
  const [type, setType] = useState("");
  const [selectedId, setSelectedId] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");

    const params = new URLSearchParams();
    if (appliedSearch) params.set("search", appliedSearch);
    if (type) params.set("type", type);
    const query = params.toString();

    apiFetch(`/api/pests${query ? `?${query}` : ""}`, {
      signal: controller.signal
    })
      .then((data) => {
        const rows = data.pests || [];
        setPests(rows);
        // Keep the open detail panel when it still matches the
        // filters; otherwise close it.
        setSelectedId((current) =>
          current && rows.some((row) => row.pest_id === current)
            ? current
            : null
        );
      })
      .catch((err) => {
        if (err.name !== "AbortError") {
          setError("Pests and diseases are unavailable right now.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, [appliedSearch, type]);

  const selected = pests.find((item) => item.pest_id === selectedId) || null;

  return (
    <div className="page">
      <div className="page-header">
        <span>FARM HEALTH</span>
        <h1>Pests &amp; Diseases</h1>
        <p>
          Learn about common crop pests and diseases and how to manage
          them.
        </p>
      </div>

      <div className="filter-bar filter-bar-card">
        <div className="filter-field filter-field-grow">
          <label htmlFor="pest-search">Search</label>
          <form
            className="search-row"
            onSubmit={(e) => {
              e.preventDefault();
              setAppliedSearch(search.trim());
            }}
          >
            <input
              id="pest-search"
              type="search"
              placeholder="Search by name, symptom or crop..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button className="btn btn-secondary btn-sm" type="submit">
              Search
            </button>
          </form>
        </div>

        <div className="filter-field">
          <label htmlFor="pest-type">Type</label>
          <select
            id="pest-type"
            value={type}
            onChange={(e) => setType(e.target.value)}
          >
            <option value="">All</option>
            <option value="pest">Pests</option>
            <option value="disease">Diseases</option>
          </select>
        </div>
      </div>

      {loading && <Spinner label="Loading library..." />}

      {!loading && error && <Alert type="error">{error}</Alert>}

      {!loading && !error && pests.length === 0 && (
        <EmptyState
          icon="🐛"
          title="No entries found"
          message="Try a different search term or filter."
        />
      )}

      {!loading && !error && pests.length > 0 && (
        <div className="pest-grid">
          {pests.map((item) => (
            <button
              key={item.pest_id}
              className={`pest-card${selectedId === item.pest_id ? " selected" : ""}`}
              onClick={() =>
                setSelectedId(
                  selectedId === item.pest_id ? null : item.pest_id
                )
              }
            >
              {item.icon || (item.pest_type === "disease" ? "🍂" : "🐛")}
              <h3>{item.name}</h3>
              <p>{item.summary || (item.pest_type === "disease" ? "Disease" : "Pest")}</p>
            </button>
          ))}
        </div>
      )}

      {selected && (
        <div className="pest-information">
          <div className="advisory-meta">
            <span className="badge badge-amber">
              {selected.pest_type === "disease" ? "Disease" : "Pest"}
            </span>
            {selected.affected_crops && (
              <span className="meta-date">
                Affects: {selected.affected_crops}
              </span>
            )}
          </div>
          <h2>{selected.name}</h2>

          <h3>Symptoms</h3>
          <p>{selected.symptoms}</p>

          <h3>Management</h3>
          <p>{selected.management}</p>
        </div>
      )}
    </div>
  );
}

export default PestsDiseases;
