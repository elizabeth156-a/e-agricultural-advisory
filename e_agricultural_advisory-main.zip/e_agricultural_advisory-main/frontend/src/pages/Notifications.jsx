import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiFetch } from "../api/client";
import { Alert, Badge, EmptyState, Spinner } from "../components/ui";

const TYPE_ICONS = {
  answer: "🧑‍🏫",
  question: "💬",
  market: "🛒",
  chat: "👥",
  system: "🔔"
};

function timeAgo(value) {
  try {
    const seconds = Math.floor((Date.now() - new Date(value).getTime()) / 1000);
    if (seconds < 60) return "just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d ago`;
    return new Date(value).toLocaleDateString("en-UG", {
      year: "numeric",
      month: "short",
      day: "numeric"
    });
  } catch {
    return "";
  }
}

function Notifications() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const data = await apiFetch("/api/notifications");
      setItems(data.notifications || []);
      setUnread(data.unread || 0);
      setError("");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function markRead(item) {
    if (item.is_read) {
      if (item.link) navigate(item.link);
      return;
    }

    setItems((current) =>
      current.map((row) =>
        row.notification_id === item.notification_id
          ? { ...row, is_read: true }
          : row
      )
    );
    setUnread((count) => Math.max(0, count - 1));

    try {
      await apiFetch(`/api/notifications/${item.notification_id}/read`, {
        method: "PATCH"
      });
      if (item.link) navigate(item.link);
    } catch {
      // The optimistic update already reflected the read state.
    }
  }

  async function markAllRead() {
    setBusy(true);
    try {
      await apiFetch("/api/notifications/read-all", { method: "POST" });
      setItems((current) =>
        current.map((row) => ({ ...row, is_read: true }))
      );
      setUnread(0);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header page-header-row">
        <div>
          <span>UPDATES</span>
          <h1>Notifications</h1>
          <p>Answers to your questions and other important updates.</p>
        </div>
        {unread > 0 && (
          <button
            className="btn btn-secondary"
            type="button"
            onClick={markAllRead}
            disabled={busy}
          >
            {busy ? "Marking..." : `Mark all read (${unread})`}
          </button>
        )}
      </div>

      {loading && <Spinner label="Loading notifications..." />}

      {!loading && error && <Alert type="error">{error}</Alert>}

      {!loading && !error && items.length === 0 && (
        <EmptyState
          icon="🔔"
          title="No notifications yet"
          message="Updates about your questions and account will appear here."
        />
      )}

      {!loading && items.length > 0 && (
        <ul className="notification-list">
          {items.map((item) => (
            <li key={item.notification_id}>
              <button
                type="button"
                className={`notification-item${item.is_read ? "" : " unread"}`}
                onClick={() => markRead(item)}
              >
                <span className="notification-icon" aria-hidden="true">
                  {TYPE_ICONS[item.type] || "🔔"}
                </span>
                <span className="notification-body">
                  <strong>
                    {item.title}
                    {!item.is_read && (
                      <Badge tone="green">New</Badge>
                    )}
                  </strong>
                  {item.body && <p>{item.body}</p>}
                  <small>{timeAgo(item.created_at)}</small>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Notifications;
