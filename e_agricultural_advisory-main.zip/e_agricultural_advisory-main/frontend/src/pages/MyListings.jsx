import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { apiFetch } from "../api/client";
import {
  Alert,
  Badge,
  ConfirmDialog,
  EmptyState,
  PageHeader,
  Spinner
} from "../components/ui";
import { categoryLabel, formatDate, formatPrice } from "../data/market";
import { ListingImage } from "./Market";

export default function MyListings() {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busyId, setBusyId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await apiFetch("/api/market/mine");
      setListings(Array.isArray(data.listings) ? data.listings : []);
    } catch (err) {
      setError(err.message || "Could not load your listings.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function toggleStatus(listing) {
    setBusyId(listing.listing_id);
    setNotice("");
    setError("");

    try {
      const data = await apiFetch(`/api/market/${listing.listing_id}`, {
        method: "PUT",
        body: JSON.stringify({
          title: listing.title,
          description: listing.description,
          image_url: listing.image_url,
          category: listing.category,
          quantity: listing.quantity,
          unit: listing.unit,
          price: listing.price,
          district: listing.district,
          contact_phone: listing.contact_phone,
          status: listing.status === "available" ? "sold" : "available"
        })
      });
      setNotice(data.message);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function deleteListing() {
    if (!deleteTarget) return;

    setBusyId(deleteTarget.listing_id);
    setNotice("");
    setError("");

    try {
      const data = await apiFetch(`/api/market/${deleteTarget.listing_id}`, {
        method: "DELETE"
      });
      setNotice(data.message);
      setDeleteTarget(null);
      await load();
    } catch (err) {
      setError(err.message);
      setDeleteTarget(null);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="page">
      <PageHeader
        eyebrow="MY LISTINGS"
        title="Manage Your Marketplace Listings"
        description="Create, update and track the products you are selling."
        actions={
          <Link to="/market/new" className="btn btn-primary">
            + New Listing
          </Link>
        }
      />

      {notice && (
        <Alert type="success" onClose={() => setNotice("")}>{notice}</Alert>
      )}
      {error && (
        <Alert type="error" onClose={() => setError("")}>{error}</Alert>
      )}

      {loading && <Spinner label="Loading your listings..." />}

      {!loading && listings.length === 0 && (
        <EmptyState
          icon="🏷️"
          title="You have no listings yet"
          message="Publish your first product and buyers across Uganda can find it."
          action={
            <Link to="/market/new" className="btn btn-primary">
              Create a Listing
            </Link>
          }
        />
      )}

      {!loading && listings.length > 0 && (
        <div className="my-listings">
          {listings.map((listing) => (
            <article key={listing.listing_id} className="my-listing-card">
              <Link
                to={`/market/${listing.listing_id}`}
                className="my-listing-media"
                aria-label={`View ${listing.title}`}
              >
                <ListingImage listing={listing} className="market-card-image" />
              </Link>

              <div className="my-listing-body">
                <div className="my-listing-top">
                  <div>
                    <Link to={`/market/${listing.listing_id}`}>
                      <h2 className="market-card-title">{listing.title}</h2>
                    </Link>
                    <p className="market-meta">
                      {categoryLabel(listing.category)} · {listing.district} ·{" "}
                      Listed {formatDate(listing.created_at)}
                    </p>
                  </div>

                  <Badge tone={listing.status === "available" ? "green" : "gray"}>
                    {listing.status === "available" ? "Available" : "Sold"}
                  </Badge>
                </div>

                <p className="market-price">{formatPrice(listing.price)}</p>
                <p className="market-meta">
                  {listing.quantity} {listing.unit}
                </p>

                <div className="my-listing-actions">
                  <Link
                    to={`/market/${listing.listing_id}/edit`}
                    className="btn btn-secondary btn-sm"
                  >
                    ✏️ Edit
                  </Link>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    onClick={() => toggleStatus(listing)}
                    disabled={busyId === listing.listing_id}
                  >
                    {busyId === listing.listing_id
                      ? "Saving..."
                      : listing.status === "available"
                        ? "Mark as Sold"
                        : "Mark as Available"}
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger btn-sm"
                    onClick={() => setDeleteTarget(listing)}
                    disabled={busyId === listing.listing_id}
                  >
                    🗑 Delete
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete listing"
          message={`Delete "${deleteTarget.title}"? This cannot be undone.`}
          confirmLabel="Delete"
          danger
          onCancel={() => setDeleteTarget(null)}
          onConfirm={deleteListing}
        />
      )}
    </div>
  );
}
