import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";
import {
  Alert,
  Badge,
  ConfirmDialog,
  EmptyState,
  Modal,
  PageHeader,
  Spinner
} from "../components/ui";

function timeAgo(value) {
  if (!value) return "";
  const seconds = Math.max(0, (Date.now() - new Date(value).getTime()) / 1000);

  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} hr ago`;
  if (seconds < 86400 * 7) return `${Math.floor(seconds / 86400)} d ago`;

  return new Date(value).toLocaleDateString("en-UG", {
    day: "numeric",
    month: "short"
  });
}

export default function Chatroom() {
  const { role } = useAuth();
  const isAdmin = role === "admin";

  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  // Admin: room editor
  const [roomModal, setRoomModal] = useState(null); // null | {mode:'create'} | {mode:'edit', room}
  const [roomForm, setRoomForm] = useState({ name: "", description: "", icon: "" });
  const [roomBusy, setRoomBusy] = useState(false);
  const [roomError, setRoomError] = useState("");

  // Admin: moderation
  const [reports, setReports] = useState([]);
  const [reportsLoading, setReportsLoading] = useState(false);
  const [reportsError, setReportsError] = useState("");
  const [reportBusyId, setReportBusyId] = useState(null);
  const [deleteMessageTarget, setDeleteMessageTarget] = useState(null);

  const loadRooms = useCallback(async (silent = false) => {
    // Only the first load shows the spinner; refreshes (mutations,
    // unread polling) update the grid in place.
    if (!silent) setLoading(true);
    if (!silent) setError("");

    try {
      const data = await apiFetch("/api/chat/rooms");
      setRooms(data.rooms || []);
      if (silent) setError("");
    } catch (err) {
      setError(err.message || "Could not load discussion rooms.");
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  const loadReports = useCallback(async () => {
    if (!isAdmin) return;

    setReportsLoading(true);
    setReportsError("");

    try {
      const data = await apiFetch("/api/chat/reports?status=open");
      setReports(data.reports || []);
    } catch (err) {
      setReportsError(err.message || "Could not load reported messages.");
    } finally {
      setReportsLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    loadRooms();
    loadReports();

    // Keep unread badges fresh while the member sits on the page.
    const interval = setInterval(() => {
      if (!document.hidden) loadRooms(true);
    }, 30000);

    return () => clearInterval(interval);
  }, [loadRooms, loadReports]);

  function openCreateRoom() {
    setRoomForm({ name: "", description: "", icon: "" });
    setRoomError("");
    setRoomModal({ mode: "create" });
  }

  function openEditRoom(room) {
    setRoomForm({
      name: room.name || "",
      description: room.description || "",
      icon: room.icon || ""
    });
    setRoomError("");
    setRoomModal({ mode: "edit", room });
  }

  async function saveRoom(event) {
    event.preventDefault();

    if (!roomForm.name.trim() || roomBusy) return;

    setRoomBusy(true);
    setRoomError("");

    try {
      if (roomModal.mode === "create") {
        await apiFetch("/api/chat/rooms", {
          method: "POST",
          body: JSON.stringify({
            name: roomForm.name.trim(),
            description: roomForm.description.trim(),
            icon: roomForm.icon.trim()
          })
        });
        setNotice("Discussion room created.");
      } else {
        await apiFetch(`/api/chat/rooms/${roomModal.room.room_id}`, {
          method: "PATCH",
          body: JSON.stringify({
            name: roomForm.name.trim(),
            description: roomForm.description.trim(),
            icon: roomForm.icon.trim()
          })
        });
        setNotice("Discussion room updated.");
      }

      setRoomModal(null);
      await loadRooms(true);
    } catch (err) {
      setRoomError(err.message);
    } finally {
      setRoomBusy(false);
    }
  }

  async function toggleRoom(room) {
    setNotice("");
    setError("");

    try {
      await apiFetch(`/api/chat/rooms/${room.room_id}`, {
        method: "PATCH",
        body: JSON.stringify({ is_active: !room.is_active })
      });
      setNotice(
        room.is_active
          ? `"${room.name}" closed.`
          : `"${room.name}" reopened.`
      );
      await loadRooms(true);
    } catch (err) {
      setError(err.message);
    }
  }

  async function reviewReport(report, status) {
    setReportBusyId(report.report_id);

    try {
      await apiFetch(`/api/chat/reports/${report.report_id}`, {
        method: "PATCH",
        body: JSON.stringify({ status })
      });
      setNotice(`Report marked as ${status}.`);
      await loadReports();
    } catch (err) {
      setReportsError(err.message);
    } finally {
      setReportBusyId(null);
    }
  }

  async function deleteReportedMessage() {
    if (!deleteMessageTarget) return;

    try {
      await apiFetch(
        `/api/chat/messages/${deleteMessageTarget.message_id}`,
        { method: "DELETE" }
      );
      setNotice("Message removed.");
      setDeleteMessageTarget(null);
      await loadReports();
      await loadRooms(true);
    } catch (err) {
      // Keep the dialog open so the admin can retry or cancel.
      setReportsError(err.message);
    }
  }

  return (
    <div className="page">
      <PageHeader
        eyebrow="FARMER CHATROOM"
        title="Community Discussion Rooms"
        description="Join discussions with other farmers and agricultural advisors."
        actions={
          isAdmin ? (
            <button type="button" className="btn btn-primary" onClick={openCreateRoom}>
              + New Room
            </button>
          ) : null
        }
      />

      {notice && <Alert type="success" onClose={() => setNotice("")}>{notice}</Alert>}
      {error && <Alert type="error" onClose={() => setError("")}>{error}</Alert>}

      {loading && <Spinner label="Loading discussion rooms..." />}

      {!loading && rooms.length === 0 && (
        <EmptyState
          icon="👥"
          title="No discussion rooms"
          message="Discussion rooms will appear here once they are available."
        />
      )}

      {!loading && rooms.length > 0 && (
        <div className="room-grid">
          {rooms.map((room) => (
            <article
              key={room.room_id}
              className={`room-card ${room.is_active ? "" : "room-card-closed"}`}
            >
              <Link to={`/chatroom/${room.room_id}`} className="room-card-link">
                <div className="room-card-top">
                  <span className="room-icon" aria-hidden="true">
                    {room.icon || "💬"}
                  </span>
                  <div>
                    <h2>{room.name}</h2>
                    <p>{room.description || "Community discussion"}</p>
                  </div>
                </div>

                <div className="room-card-meta">
                  <span>
                    {room.message_count} message
                    {Number(room.message_count) === 1 ? "" : "s"}
                  </span>
                  {room.last_message_at && (
                    <span>last {timeAgo(room.last_message_at)}</span>
                  )}
                </div>

                {room.last_message && (
                  <p className="room-card-preview">“{room.last_message}”</p>
                )}

                <div className="room-card-footer">
                  {!room.is_active ? (
                    <Badge tone="gray">Closed</Badge>
                  ) : Number(room.unread_count) > 0 ? (
                    <Badge tone="amber">
                      {room.unread_count} unread
                    </Badge>
                  ) : (
                    <Badge tone="green">Open</Badge>
                  )}
                  <span className="room-card-cta">Join discussion →</span>
                </div>
              </Link>

              {isAdmin && (
                <div className="room-admin-controls">
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => openEditRoom(room)}
                  >
                    ✏️ Edit
                  </button>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => toggleRoom(room)}
                  >
                    {room.is_active ? "Close" : "Reopen"}
                  </button>
                </div>
              )}
            </article>
          ))}
        </div>
      )}

      {isAdmin && (
        <section className="panel moderation-panel">
          <div className="panel-header">
            <h2>🚩 Reported Messages</h2>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={loadReports}
            >
              Refresh
            </button>
          </div>

          {reportsError && <Alert type="error">{reportsError}</Alert>}
          {reportsLoading && <Spinner label="Loading reports..." />}

          {!reportsLoading && reports.length === 0 && (
            <p className="moderation-empty">
              No open reports. Everything looks fine.
            </p>
          )}

          {!reportsLoading && reports.length > 0 && (
            <div className="report-list">
              {reports.map((report) => (
                <article key={report.report_id} className="report-item">
                  <div className="report-item-body">
                    <p className="report-quote">“{report.message_body}”</p>
                    <p className="market-meta">
                      by <strong>{report.sender_name}</strong> in{" "}
                      {report.room_name} · reported by{" "}
                      {report.reporter_name} · reason: {report.reason}
                    </p>
                  </div>

                  <div className="report-item-actions">
                    <button
                      type="button"
                      className="btn btn-secondary btn-sm"
                      disabled={reportBusyId === report.report_id}
                      onClick={() => reviewReport(report, "reviewed")}
                    >
                      Mark Reviewed
                    </button>
                    <button
                      type="button"
                      className="btn btn-ghost btn-sm"
                      disabled={reportBusyId === report.report_id}
                      onClick={() => reviewReport(report, "dismissed")}
                    >
                      Dismiss
                    </button>
                    <button
                      type="button"
                      className="btn btn-danger btn-sm"
                      onClick={() => setDeleteMessageTarget(report)}
                    >
                      Remove Message
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      )}

      {roomModal && (
        <Modal
          title={roomModal.mode === "create" ? "Create discussion room" : "Edit room"}
          onClose={() => setRoomModal(null)}
        >
          <form onSubmit={saveRoom}>
            {roomError && <Alert type="error">{roomError}</Alert>}

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="room-name">Room name *</label>
                <input
                  id="room-name"
                  type="text"
                  value={roomForm.name}
                  onChange={(event) =>
                    setRoomForm((form) => ({ ...form, name: event.target.value }))
                  }
                  maxLength={100}
                  placeholder="e.g. Crop Farming"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="room-icon">Icon</label>
                <input
                  id="room-icon"
                  type="text"
                  value={roomForm.icon}
                  onChange={(event) =>
                    setRoomForm((form) => ({ ...form, icon: event.target.value }))
                  }
                  maxLength={10}
                  placeholder="e.g. 🌽"
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="room-description">Description</label>
              <textarea
                id="room-description"
                rows="3"
                value={roomForm.description}
                onChange={(event) =>
                  setRoomForm((form) => ({
                    ...form,
                    description: event.target.value
                  }))
                }
                maxLength={255}
                placeholder="What is this room about?"
              />
            </div>

            <div className="modal-actions">
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => setRoomModal(null)}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={roomBusy || !roomForm.name.trim()}
              >
                {roomBusy ? "Saving..." : "Save Room"}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {deleteMessageTarget && (
        <ConfirmDialog
          title="Remove reported message"
          message={`Remove the message “${deleteMessageTarget.message_body}” from the discussion? This cannot be undone.`}
          confirmLabel="Remove"
          danger
          onCancel={() => setDeleteMessageTarget(null)}
          onConfirm={deleteReportedMessage}
        />
      )}
    </div>
  );
}
