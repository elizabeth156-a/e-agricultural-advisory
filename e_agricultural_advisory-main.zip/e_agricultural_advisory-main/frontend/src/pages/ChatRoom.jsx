import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";
import {
  Alert,
  Badge,
  ConfirmDialog,
  Modal,
  PageHeader,
  Spinner
} from "../components/ui";

const POLL_INTERVAL_MS = 7000;
const PAGE_SIZE = 50;

function formatMessageTime(value) {
  const date = new Date(value);
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();

  return sameDay
    ? date.toLocaleTimeString("en-UG", { hour: "2-digit", minute: "2-digit" })
    : date.toLocaleDateString("en-UG", {
        day: "numeric",
        month: "short"
      }) +
        " " +
        date.toLocaleTimeString("en-UG", { hour: "2-digit", minute: "2-digit" });
}

function initials(name) {
  return (name || "?")
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

function roleBadge(role) {
  if (role === "admin") return <Badge tone="amber">Admin</Badge>;
  if (role === "advisor") return <Badge tone="green">Advisor</Badge>;
  return null;
}

export default function ChatRoom() {
  const { roomId } = useParams();
  const { user, isAuthenticated } = useAuth();

  const [room, setRoom] = useState(null);
  const [messages, setMessages] = useState([]);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [offline, setOffline] = useState(false);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [reportTarget, setReportTarget] = useState(null);
  const [reportReason, setReportReason] = useState("");
  const [reportBusy, setReportBusy] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const listRef = useRef(null);
  const pollRef = useRef(null);
  const seenIdsRef = useRef(new Set());
  const markedReadRef = useRef(null);
  // Scroll-to-bottom is requested inside the state updater (which
  // must stay pure) and performed by an effect after the DOM has
  // actually been committed.
  const scrollPendingRef = useRef(false);
  // Set before older messages are prepended so the viewport can
  // be re-anchored to the same messages afterwards.
  const anchorRef = useRef(null);

  const mergeMessages = useCallback((incoming) => {
    setMessages((current) => {
      const map = new Map();
      current.forEach((item) => map.set(item.message_id, item));
      incoming.forEach((item) => map.set(item.message_id, item));

      const merged = [...map.values()].sort(
        (a, b) => a.message_id - b.message_id
      );

      // Detect genuinely new messages for scrolling purposes.
      const fresh = incoming.some(
        (item) => !seenIdsRef.current.has(item.message_id)
      );
      merged.forEach((item) => seenIdsRef.current.add(item.message_id));

      if (fresh) {
        scrollPendingRef.current = true;
      }

      return merged;
    });
  }, []);

  // Scroll to the newest message once React has committed it.
  useEffect(() => {
    if (!scrollPendingRef.current) return;
    scrollPendingRef.current = false;
    const node = listRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages]);

  // Keep the reading position when older messages are prepended.
  useEffect(() => {
    if (!anchorRef.current || !listRef.current) return;
    const node = listRef.current;
    node.scrollTop += node.scrollHeight - anchorRef.current;
    anchorRef.current = null;
  }, [messages]);

  const loadLatest = useCallback(async (signal) => {
    const data = await apiFetch(
      `/api/chat/rooms/${roomId}/messages?limit=${PAGE_SIZE}`,
      { signal }
    );

    setRoom(data.room);
    setHasMore(Boolean(data.hasMore));
    mergeMessages(data.messages || []);
    setOffline(false);

    // Mark the newest visible message as read — only after the
    // server confirms it, so a failed request is retried on the
    // next poll instead of being silently skipped.
    const newest = data.messages?.[data.messages.length - 1];
    if (newest && markedReadRef.current !== newest.message_id) {
      apiFetch(`/api/chat/rooms/${roomId}/read`, {
        method: "POST",
        body: JSON.stringify({ last_read_message_id: newest.message_id })
      })
        .then(() => {
          markedReadRef.current = newest.message_id;
        })
        .catch(() => {});
    }

    return data;
  }, [roomId, mergeMessages]);

  // Initial load + polling. Everything is reset when the room
  // changes so messages never leak between rooms.
  useEffect(() => {
    const controller = new AbortController();
    let active = true;

    setMessages([]);
    setRoom(null);
    setHasMore(false);
    setOffline(false);
    seenIdsRef.current = new Set();
    markedReadRef.current = null;
    scrollPendingRef.current = false;
    anchorRef.current = null;

    async function initialLoad() {
      setLoading(true);
      setError("");

      try {
        await loadLatest(controller.signal);
      } catch (err) {
        if (err.name !== "AbortError" && active) {
          setError(
            err.status === 404
              ? "This discussion room does not exist."
              : err.status === 401
                ? "Your session has expired. Please log in again."
                : "Could not load messages. Please try again."
          );
        }
      } finally {
        if (active) setLoading(false);
      }
    }

    initialLoad();

    pollRef.current = setInterval(() => {
      if (document.hidden) return;
      loadLatest()
        .catch((err) => {
          if (active && err.name !== "AbortError") {
            setOffline(true);
          }
        });
    }, POLL_INTERVAL_MS);

    return () => {
      active = false;
      controller.abort();
      clearInterval(pollRef.current);
    };
  }, [loadLatest]);

  async function loadOlder() {
    if (!messages.length) return;

    const node = listRef.current;
    anchorRef.current = node ? node.scrollHeight : null;

    try {
      const data = await apiFetch(
        `/api/chat/rooms/${roomId}/messages?limit=${PAGE_SIZE}&before=${messages[0].message_id}`
      );
      setHasMore(Boolean(data.hasMore));

      setMessages((current) => {
        const map = new Map();
        data.messages.forEach((item) => {
          map.set(item.message_id, item);
          seenIdsRef.current.add(item.message_id);
        });
        current.forEach((item) => map.set(item.message_id, item));
        return [...map.values()].sort(
          (a, b) => a.message_id - b.message_id
        );
      });
    } catch {
      anchorRef.current = null;
      setError("Could not load earlier messages.");
    }
  }

  async function handleSend(event) {
    event.preventDefault();

    const body = draft.trim();
    if (!body || sending) return;

    setSending(true);
    setError("");

    try {
      const data = await apiFetch(`/api/chat/rooms/${roomId}/messages`, {
        method: "POST",
        body: JSON.stringify({ body })
      });
      mergeMessages([data.message]);
      setDraft("");
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  }

  async function submitReport() {
    const reason = reportReason.trim();
    if (!reason || reportBusy) return;

    setReportBusy(true);

    try {
      await apiFetch(`/api/chat/messages/${reportTarget.message_id}/report`, {
        method: "POST",
        body: JSON.stringify({ reason })
      });
      setReportTarget(null);
      setReportReason("");
      setError("");
      alert("Report submitted. An administrator will review it.");
    } catch (err) {
      setError(err.message);
    } finally {
      setReportBusy(false);
    }
  }

  async function deleteMessage() {
    if (!deleteTarget) return;

    try {
      await apiFetch(`/api/chat/messages/${deleteTarget.message_id}`, {
        method: "DELETE"
      });
      setMessages((current) =>
        current.filter((item) => item.message_id !== deleteTarget.message_id)
      );
      setDeleteTarget(null);
    } catch (err) {
      setError(err.message);
      setDeleteTarget(null);
    }
  }

  if (loading) {
    return (
      <div className="page">
        <Spinner label="Opening discussion room..." />
      </div>
    );
  }

  if (error && !room) {
    return (
      <div className="page">
        <Alert type="error">{error}</Alert>
        <Link to="/chatroom" className="btn btn-secondary">
          ← Back to Chatroom
        </Link>
      </div>
    );
  }

  return (
    <div className="page chat-page">
      <PageHeader
        eyebrow="FARMER CHATROOM"
        title={`${room?.icon || "👥"} ${room?.name || "Discussion"}`}
        description={room?.description || "Discuss farming with the community."}
        actions={
          <Link to="/chatroom" className="btn btn-ghost">
            ← All Rooms
          </Link>
        }
      />

      {error && <Alert type="error" onClose={() => setError("")}>{error}</Alert>}
      {offline && (
        <Alert type="warning">
          Could not refresh messages — check your connection. Retrying…
        </Alert>
      )}

      <section className="chat-panel">
        <div className="chat-messages" ref={listRef}>
          {hasMore && (
            <div className="chat-older">
              <button type="button" className="btn btn-ghost btn-sm" onClick={loadOlder}>
                Load earlier messages
              </button>
            </div>
          )}

          {messages.length === 0 && (
            <p className="chat-empty">
              No messages yet. Start the conversation!
            </p>
          )}

          {messages.map((message) => {
            const mine = Number(message.sender_id) === Number(user?.user_id);

            return (
              <article
                key={message.message_id}
                className={`chat-message ${mine ? "chat-message-mine" : ""}`}
              >
                <span className="chat-avatar" aria-hidden="true">
                  {initials(message.sender_name)}
                </span>

                <div className="chat-message-content">
                  <div className="chat-message-meta">
                    <strong>{mine ? "You" : message.sender_name}</strong>
                    {roleBadge(message.sender_role)}
                    <time dateTime={message.created_at}>
                      {formatMessageTime(message.created_at)}
                    </time>
                  </div>

                  <p className="chat-message-body">{message.body}</p>
                </div>

                <div className="chat-message-actions">
                  {!mine && isAuthenticated && (
                    <button
                      type="button"
                      className="chat-action-btn"
                      title="Report message"
                      onClick={() => {
                        setReportTarget(message);
                        setReportReason("");
                      }}
                    >
                      🚩
                    </button>
                  )}

                  {user?.role === "admin" && (
                    <button
                      type="button"
                      className="chat-action-btn"
                      title="Remove message"
                      onClick={() => setDeleteTarget(message)}
                    >
                      🗑
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>

        {room?.is_active ? (
          <form className="chat-composer" onSubmit={handleSend}>
            <textarea
              rows="2"
              placeholder="Write a message... (Enter to send, Shift+Enter for a new line)"
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => {
                if (
                  event.key === "Enter" &&
                  !event.shiftKey &&
                  !event.nativeEvent.isComposing
                ) {
                  event.preventDefault();
                  handleSend(event);
                }
              }}
              maxLength={5000}
              aria-label="Message"
            />
            <button
              type="submit"
              className="btn btn-primary"
              disabled={sending || !draft.trim()}
            >
              {sending ? "Sending..." : "Send"}
            </button>
          </form>
        ) : (
          <p className="chat-closed">
            This room is closed for new messages.
          </p>
        )}
      </section>

      {reportTarget && (
        <Modal
          title="Report message"
          onClose={() => setReportTarget(null)}
        >
          <p className="confirm-message">
            Report the message from{" "}
            <strong>{reportTarget.sender_name}</strong> for review by an
            administrator.
          </p>

          <div className="form-group" style={{ marginTop: "16px" }}>
            <label htmlFor="report-reason">Reason</label>
            <textarea
              id="report-reason"
              rows="4"
              placeholder="Explain what is wrong with this message..."
              value={reportReason}
              onChange={(event) => setReportReason(event.target.value)}
              maxLength={500}
            />
          </div>

          <div className="modal-actions">
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => setReportTarget(null)}
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-danger"
              onClick={submitReport}
              disabled={reportBusy || !reportReason.trim()}
            >
              {reportBusy ? "Submitting..." : "Submit Report"}
            </button>
          </div>
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Remove message"
          message="This message will be permanently removed from the discussion."
          confirmLabel="Remove"
          danger
          onCancel={() => setDeleteTarget(null)}
          onConfirm={deleteMessage}
        />
      )}
    </div>
  );
}
