
import { useEffect, useState } from "react";

import { DISTRICTS } from "../data/districts";

const API_URL = (
  import.meta.env.VITE_API_URL ||
  "https://e-agricultural-advisory.onrender.com"
).replace(/\/$/, "");

function weatherDescription(code) {
  if (code === 0) return "Clear sky";
  if ([1, 2].includes(code)) return "Mainly clear or partly cloudy";
  if (code === 3) return "Overcast";
  if ([45, 48].includes(code)) return "Foggy";
  if ([51, 53, 55].includes(code)) return "Drizzle";
  if ([56, 57].includes(code)) return "Freezing drizzle";
  if ([61, 63, 65].includes(code)) return "Rain";
  if ([66, 67].includes(code)) return "Freezing rain";
  if ([71, 73, 75, 77].includes(code)) return "Snow or ice pellets";
  if ([80, 81, 82].includes(code)) return "Rain showers";
  if ([85, 86].includes(code)) return "Snow showers";
  if (code === 95) return "Thunderstorm";
  if ([96, 99].includes(code)) return "Thunderstorm with hail";
  return "Conditions unavailable";
}

function getFarmingAdvice(current, daily) {
  const advice = [];

  if (daily.precipitation_probability_max.some(
    value => value != null && value >= 60
  )) {
    advice.push({
      title: "Rain expected",
      message:
        "Rain is likely on at least one forecast day. Check drainage, protect harvested produce, and avoid unnecessary irrigation."
    });
  } else {
    advice.push({
      title: "Water management",
      message:
        "High rain probability is not shown in this forecast. Check soil moisture before irrigating or planting."
    });
  }

  if (daily.temperature_2m_max.some(
    value => value != null && value >= 32
  )) {
    advice.push({
      title: "High temperatures",
      message:
        "Hot conditions are forecast. Monitor crops for water stress and irrigate according to crop needs and soil moisture."
    });
  }

  if (current.wind_speed_10m >= 20) {
    advice.push({
      title: "Wind conditions",
      message:
        "Winds are relatively strong. Consider delaying pesticide spraying until label-specified weather conditions are met."
    });
  }

  if (current.precipitation > 0) {
    advice.push({
      title: "Current rainfall",
      message:
        "Precipitation is being recorded. Inspect drainage and avoid watering fields that are already sufficiently wet."
    });
  }

  advice.push({
    title: "Plan farm activities",
    message:
      "Use the forecast alongside soil conditions, crop growth stage, and local extension advice. Forecasts can change."
  });

  return advice;
}

function Weather() {
  const [selectedDistrict, setSelectedDistrict] = useState("Mukono");
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const location = DISTRICTS.find(
      item => item.district === selectedDistrict
    );

    if (!location) return;

    const controller = new AbortController();

    async function loadWeather() {
      setLoading(true);
      setError("");
      setWeather(null);

      try {
        const params = new URLSearchParams({
          latitude: String(location.latitude),
          longitude: String(location.longitude)
        });

        const response = await fetch(
          `${API_URL}/api/weather?${params}`,
          { signal: controller.signal }
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Could not load weather.");
        }

        setWeather(data);
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(
            err.message ||
            "Unable to load weather. Please try again."
          );
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    loadWeather();

    return () => controller.abort();
  }, [selectedDistrict]);

  const current = weather?.current;
  const daily = weather?.daily;

  return (
    <div className="page">
      <div className="page-header">
        <span>WEATHER INFORMATION</span>
        <h1>Farming Weather</h1>
        <p>
          Check local weather forecasts and practical farming
          recommendations for locations across Uganda.
        </p>
      </div>

      <section className="weather-card">
        <div className="weather-location">
          <label htmlFor="weather-district">
            Select district or town
          </label>

          <select
            id="weather-district"
            value={selectedDistrict}
            onChange={event =>
              setSelectedDistrict(event.target.value)
            }
          >
            {DISTRICTS
              .slice()
              .sort((a, b) =>
                a.district.localeCompare(b.district)
              )
              .map(location => (
                <option
                  key={location.district}
                  value={location.district}
                >
                  {location.district}
                </option>
              ))}
          </select>
        </div>

        <h2>{selectedDistrict} District</h2>

        {loading && (
          <p role="status">Loading weather forecast...</p>
        )}

        {error && (
          <div className="info-box" role="alert">
            <h3>Weather unavailable</h3>
            <p>{error}</p>
            <p>
              If the API was just deployed, wait for the
              Render service to finish deploying and try again.
            </p>
          </div>
        )}

        {!loading && !error && current && (
          <>
            <div className="weather-icon">
              {current.weather_code === 0 ? "☀️" :
               current.weather_code >= 61 ? "🌧️" :
               current.weather_code >= 51 ? "🌦️" : "☁️"}
            </div>

            <h3>{weatherDescription(current.weather_code)}</h3>

            <p>
              Current temperature:{" "}
              <strong>{current.temperature_2m}°C</strong>
            </p>

            <div className="weather-stats">
              <span>
                🌡️ Feels like: {current.apparent_temperature}°C
              </span>
              <span>
                💧 Humidity: {current.relative_humidity_2m}%
              </span>
              <span>
                🌧️ Precipitation: {current.precipitation} mm
              </span>
              <span>
                💨 Wind: {current.wind_speed_10m} km/h
              </span>
            </div>
          </>
        )}
      </section>

      {!loading && !error && daily && (
        <>
          <section className="weather-card">
            <h2>7-Day Forecast</h2>

            <div className="forecast-grid">
              {daily.time.map((date, index) => (
                <article className="forecast-day" key={date}>
                  <h3>
                    {new Date(
                      `${date}T12:00:00`
                    ).toLocaleDateString("en-UG", {
                      weekday: "short",
                      day: "numeric",
                      month: "short"
                    })}
                  </h3>

                  <p>
                    {weatherDescription(
                      daily.weather_code[index]
                    )}
                  </p>

                  <p>
                    <strong>
                      {daily.temperature_2m_max[index]}°C
                    </strong>
                    {" / "}
                    {daily.temperature_2m_min[index]}°C
                  </p>

                  <p>
                    🌧️ Rain chance:{" "}
                    {daily.precipitation_probability_max[index] ??
                      "N/A"}%
                  </p>

                  <p>
                    Rainfall: {daily.precipitation_sum[index]} mm
                  </p>
                </article>
              ))}
            </div>
          </section>

          <section className="info-box">
            <h2>🌾 Farming Recommendations</h2>

            {getFarmingAdvice(current, daily).map(
              (item, index) => (
                <article key={index}>
                  <h3>{item.title}</h3>
                  <p>{item.message}</p>
                </article>
              )
            )}
          </section>

          <p className="weather-disclaimer">
            Forecasts are estimates, not guarantees. Confirm
            local conditions before making important farming
            decisions.
          </p>
        </>
      )}
    </div>
  );
}

export default Weather;
