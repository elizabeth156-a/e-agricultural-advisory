import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";
import { Alert, Badge, EmptyState, Spinner } from "../components/ui";

const MAX_TITLE = 200;
const MAX_BODY = 5000;

function formatDate(value) {
  try {
    return new Date(value).toLocaleString("en-UG", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch {
    return "";
  }
}

function statusBadge(status) {
  if (status === "answered") return <Badge tone="green">Answered</Badge>;
  if (status === "closed") return <Badge tone="gray">Closed</Badge>;
  return <Badge tone="amber">Open</Badge>;
}

function QuestionCard({ question, isStaff, onChanged }) {
  const [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [open, setOpen] = useState(false);

  async function submitAnswer(e) {
    e.preventDefault();
    if (!answer.trim()) return;

    setBusy(true);
    setError("");

    try {
      await apiFetch(`/api/questions/${question.question_id}/answers`, {
        method: "POST",
        body: JSON.stringify({ body: answer.trim() })
      });
      setAnswer("");
      setOpen(false);
      onChanged();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function setStatus(status) {
    setBusy(true);
    setError("");

    try {
      await apiFetch(`/api/questions/${question.question_id}`, {
        method: "PATCH",
        body: JSON.stringify({ status })
      });
      onChanged();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <article className="question-card-item">
      <div className="question-card-head">
        <div>
          <h3>{question.title}</h3>
          <p className="question-meta">
            {question.crop_name && (
              <Badge tone="green">{question.crop_name}</Badge>
            )}{" "}
            {!isStaff && <span>Asked by you · </span>}
            {isStaff && <span>{question.asker_name} · </span>}
            <span>{formatDate(question.created_at)}</span>
          </p>
        </div>
        {statusBadge(question.status)}
      </div>

      <p className="question-body">{question.body}</p>

      {question.answers.length > 0 && (
        <div className="question-answers">
          {question.answers.map((item) => (
            <div className="answer-item" key={item.answer_id}>
              <div className="answer-head">
                <strong>🧑‍🏫 {item.advisor_name}</strong>
                <span>{formatDate(item.created_at)}</span>
              </div>
              <p>{item.body}</p>
            </div>
          ))}
        </div>
      )}

      {error && <Alert type="error" onClose={() => setError("")}>{error}</Alert>}

      <div className="question-actions">
        {isStaff && question.status !== "closed" && (
          <button
            type="button"
            className="btn btn-primary btn-sm"
            onClick={() => setOpen(!open)}
            disabled={busy}
          >
            {open ? "Cancel" : "Answer"}
          </button>
        )}

        {!isStaff && question.status !== "closed" && (
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={() => setStatus("closed")}
            disabled={busy}
          >
            Close question
          </button>
        )}

        {isStaff && question.status === "closed" && (
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={() => setStatus("open")}
            disabled={busy}
          >
            Reopen
          </button>
        )}
      </div>

      {open && (
        <form className="answer-form" onSubmit={submitAnswer}>
          <div className="form-group">
            <label htmlFor={`answer-${question.question_id}`}>
              Your answer
            </label>
            <textarea
              id={`answer-${question.question_id}`}
              rows="5"
              placeholder="Write practical advice for this farmer..."
              value={answer}
              maxLength={MAX_BODY}
              onChange={(e) => setAnswer(e.target.value)}
            />
          </div>
          <button
            className="form-btn"
            type="submit"
            disabled={busy || !answer.trim()}
          >
            {busy ? "Submitting..." : "Submit Answer"}
          </button>
        </form>
      )}
    </article>
  );
}

function AskAdvisor() {
  const { role } = useAuth();
  const isStaff = role === "advisor" || role === "admin";

  const [crops, setCrops] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const [cropId, setCropId] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [statusFilter, setStatusFilter] = useState("");

  async function loadQuestions() {
    try {
      const path = isStaff
        ? `/api/questions${statusFilter ? `?status=${statusFilter}` : ""}`
        : "/api/questions/mine";
      const data = await apiFetch(path);
      setQuestions(data.questions || []);
      setError("");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadQuestions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  useEffect(() => {
    apiFetch("/api/advisories/crops")
      .then((data) => setCrops(data.crops || []))
      .catch(() => {});
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();

    if (!title.trim() || !body.trim()) {
      setError("Please enter a title and your question.");
      return;
    }

    setSubmitting(true);
    setError("");
    setNotice("");

    try {
      await apiFetch("/api/questions", {
        method: "POST",
        body: JSON.stringify({
          title: title.trim(),
          body: body.trim(),
          crop_id: cropId || undefined
        })
      });
      setNotice("Your question has been submitted. An advisor will respond.");
      setTitle("");
      setBody("");
      setCropId("");
      await loadQuestions();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  const openCount = questions.filter((q) => q.status === "open").length;

  return (
    <div className="page">
      <div className="page-header">
        <span>EXPERT SUPPORT</span>
        <h1>
          {isStaff ? "Farmer Questions" : "Ask an Agricultural Advisor"}
        </h1>
        <p>
          {isStaff
            ? "Answer questions from farmers and help them make better decisions."
            : "Send your farming question to an agricultural advisor and track the response."}
        </p>
      </div>

      {!isStaff && (
        <div className="question-card">
          <form onSubmit={handleSubmit}>
            {notice && (
              <Alert type="success" onClose={() => setNotice("")}>
                {notice}
              </Alert>
            )}

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="q-crop">Crop (optional)</label>
                <select
                  id="q-crop"
                  value={cropId}
                  onChange={(e) => setCropId(e.target.value)}
                >
                  <option value="">Select crop</option>
                  {crops.map((crop) => (
                    <option key={crop.crop_id} value={crop.crop_id}>
                      {crop.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="q-title">Question title</label>
                <input
                  id="q-title"
                  type="text"
                  maxLength={MAX_TITLE}
                  placeholder="e.g. Yellowing leaves on my maize"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="q-body">Your Question</label>
              <textarea
                id="q-body"
                rows="7"
                maxLength={MAX_BODY}
                placeholder="Describe your farming problem..."
                value={body}
                onChange={(e) => setBody(e.target.value)}
              />
              <small className="form-hint">
                {body.length}/{MAX_BODY} characters
              </small>
            </div>

            <button
              className="form-btn"
              type="submit"
              disabled={submitting || !title.trim() || !body.trim()}
            >
              {submitting ? "Submitting..." : "Submit Question"}
            </button>
          </form>
        </div>
      )}

      <section className="panel question-list-panel">
        <div className="panel-header">
          <h2>
            {isStaff ? "Questions" : "My Questions"}
            {!loading && questions.length > 0 && (
              <span className="panel-count">{questions.length}</span>
            )}
          </h2>

          {isStaff && (
            <select
              className="panel-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by status"
            >
              <option value="">All statuses</option>
              <option value="open">Open</option>
              <option value="answered">Answered</option>
              <option value="closed">Closed</option>
            </select>
          )}
        </div>

        {loading && <Spinner label="Loading questions..." />}

        {!loading && error && <Alert type="error">{error}</Alert>}

        {!loading && !error && questions.length === 0 && (
          <EmptyState
            icon="💬"
            title={isStaff ? "No questions yet" : "No questions yet"}
            message={
              isStaff
                ? openCount === 0
                  ? "There are no questions waiting for an answer."
                  : "Questions from farmers will appear here."
                : "Ask your first question above and advisors will respond here."
            }
          />
        )}

        {!loading && !error && questions.length > 0 && (
          <div className="question-list">
            {questions.map((question) => (
              <QuestionCard
                key={question.question_id}
                question={question}
                isStaff={isStaff}
                onChanged={loadQuestions}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

export default AskAdvisor;
