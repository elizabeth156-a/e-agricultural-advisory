import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";
import { Alert, EmptyState, Spinner } from "../components/ui";

const QUICK_ACTIONS = [
  { to: "/advisories", icon: "🌱", label: "Crop Advisories", hint: "Planting and management advice" },
  { to: "/weather", icon: "🌦️", label: "Weather Forecast", hint: "7-day outlook for your district" },
  { to: "/pests-diseases", icon: "🐛", label: "Pests & Diseases", hint: "Identify and manage threats" },
  { to: "/ask-advisor", icon: "💬", label: "Ask an Advisor", hint: "Get expert answers" },
  { to: "/market", icon: "🛒", label: "Marketplace", hint: "Buy and sell farm goods" }
];

function formatPrice(price) {
  return `UGX ${Number(price).toLocaleString("en-UG")}`;
}

function formatDate(value) {
  try {
    return new Date(value).toLocaleDateString("en-UG", {
      month: "short",
      day: "numeric"
    });
  } catch {
    return "";
  }
}

function Dashboard() {
  const { user, role } = useAuth();
  const isFarmer = role === "farmer";
  const isStaff = role === "advisor" || role === "admin";

  const [stats, setStats] = useState(null);
  const [statsLoading, setStatsLoading] = useState(true);
  const [statsError, setStatsError] = useState("");

  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const controller = new AbortController();

    apiFetch("/api/dashboard/stats", { signal: controller.signal })
      .then((data) => setStats(data.stats))
      .catch((err) => {
        if (err.name !== "AbortError") {
          setStatsError("Your statistics are unavailable right now.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setStatsLoading(false);
      });

    return () => controller.abort();
  }, []);

  useEffect(() => {
    const controller = new AbortController();

    async function loadMarket() {
      try {
        const data = await apiFetch("/api/market?sort=price_desc", {
          signal: controller.signal
        });
        setListings((data.listings || []).slice(0, 4));
      } catch (err) {
        if (err.name !== "AbortError") {
          setError("Marketplace highlights are unavailable right now.");
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    loadMarket();
    return () => controller.abort();
  }, []);

  const firstName = (user?.full_name || "Farmer").split(" ")[0];

  const cards = stats
    ? [
        {
          icon: "🌱",
          title: "Advisories",
          value: stats.advisories_total,
          note: "Published in the library",
          to: "/advisories"
        },
        isFarmer
          ? {
              icon: "🏷️",
              title: "My Listings",
              value: stats.my_listings,
              note: `${stats.my_listings_available} available on the market`,
              to: "/my-listings"
            }
          : {
              icon: "💬",
              title: "Questions to Answer",
              value: stats.pending_questions,
              note: "Waiting for an advisor reply",
              to: "/ask-advisor"
            },
        {
          icon: "❓",
          title: isStaff ? "Questions Received" : "My Questions",
          value: stats.my_questions,
          note: `${stats.my_questions_answered} answered`,
          to: "/ask-advisor"
        },
        {
          icon: "🔔",
          title: "Notifications",
          value: stats.unread_notifications,
          note:
            stats.unread_notifications > 0
              ? "Unread updates"
              : "You are all caught up",
          to: "/notifications"
        }
      ]
    : [];

  return (
    <div className="dashboard">
      <header className="dashboard-welcome">
        <div>
          <span className="page-eyebrow">FARMER DASHBOARD</span>
          <h1>Welcome back, {firstName} 👋</h1>
          <p>
            Here is your agricultural information overview. Manage your
            farm activities, get advice and trade from one place.
          </p>
        </div>
        <Link to="/profile" className="btn btn-secondary">
          View Profile
        </Link>
      </header>

      {statsLoading && <Spinner label="Loading your statistics..." />}

      {!statsLoading && statsError && (
        <Alert type="warning">{statsError}</Alert>
      )}

      {!statsLoading && !statsError && stats && (
        <section className="dashboard-grid" aria-label="Statistics">
          {cards.map((card) => (
            <div className="dashboard-card" key={card.title}>
              <div className="dashboard-card-icon" aria-hidden="true">
                {card.icon}
              </div>
              <h3>{card.title}</h3>
              <strong className="dashboard-card-value">
                <Link to={card.to}>{card.value}</Link>
              </strong>
              <p>{card.note}</p>
            </div>
          ))}
        </section>
      )}

      <div className="dashboard-columns">
        <section className="panel">
          <div className="panel-header">
            <h2>Quick Actions</h2>
          </div>
          <div className="quick-actions">
            {QUICK_ACTIONS.map((action) => (
              <Link key={action.to} to={action.to} className="quick-action">
                <span className="quick-action-icon" aria-hidden="true">
                  {action.icon}
                </span>
                <span>
                  <strong>{action.label}</strong>
                  <small>{action.hint}</small>
                </span>
              </Link>
            ))}
          </div>
        </section>

        <section className="panel">
          <div className="panel-header">
            <h2>Marketplace Highlights</h2>
            <Link to="/market" className="panel-link">View all</Link>
          </div>

          {loading && <Spinner label="Loading listings..." />}

          {!loading && error && (
            <Alert type="warning">{error}</Alert>
          )}

          {!loading && !error && listings.length === 0 && (
            <EmptyState
              icon="🛒"
              title="No listings yet"
              message="New products will appear here once farmers publish them."
            />
          )}

          {!loading && !error && listings.length > 0 && (
            <ul className="highlight-list">
              {listings.map((item) => (
                <li key={item.listing_id}>
                  <div>
                    <strong>{item.title}</strong>
                    <small>
                      {item.district} · {item.seller_name || "Farmer"}
                    </small>
                  </div>
                  <span className="highlight-price">
                    {formatPrice(item.price)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {stats && stats.latest_advisories?.length > 0 && (
        <section className="panel">
          <div className="panel-header">
            <h2>Latest Advisories</h2>
            <Link to="/advisories" className="panel-link">View all</Link>
          </div>
          <ul className="highlight-list">
            {stats.latest_advisories.map((item) => (
              <li key={item.advisory_id}>
                <div>
                  <strong>{item.title}</strong>
                  <small>
                    {item.crop_name ? `${item.crop_name} · ` : ""}
                    {item.category.replace(/_/g, " ")}
                  </small>
                </div>
                <span className="highlight-price">{formatDate(item.created_at)}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="panel dashboard-cta">
        <div>
          <h2>Need expert help?</h2>
          <p>
            Send your farming question to an agricultural advisor and
            track the response from this dashboard.
          </p>
        </div>
        <Link to="/ask-advisor" className="btn btn-primary">
          Ask an Advisor
        </Link>
      </section>
    </div>
  );
}

export default Dashboard;
