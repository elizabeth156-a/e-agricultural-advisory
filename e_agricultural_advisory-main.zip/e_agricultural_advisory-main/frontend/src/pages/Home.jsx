import { Link } from "react-router-dom";

function Home() {
  return (
    <div>

      {/* HERO */}

      <section className="hero">

        <div className="hero-content">

          <span className="hero-tag">
            🌾 Digital Agriculture for Better Farming
          </span>

          <h1>
            Smart Agricultural Advice
            <span> At Your Fingertips</span>
          </h1>

          <p>
            E-Agri Advisory helps smallholder farmers access
            reliable agricultural information, crop advice,
            pest and disease guidance, weather information,
            and agricultural experts.
          </p>

          <div className="hero-buttons">

            <Link to="/register" className="primary-btn">
              Get Started
            </Link>

            <Link to="/advisories" className="secondary-btn">
              Explore Advisories
            </Link>

          </div>

        </div>

        <div className="hero-card">

          <div className="farmer-icon">
            🌱
          </div>

          <h3>Farmer Advisory</h3>

          <p>
            Get recommendations based on your crop,
            farm conditions and farming needs.
          </p>

          <div className="mini-stats">

            <div>
              <strong>24/7</strong>
              <small>Access</small>
            </div>

            <div>
              <strong>🌱</strong>
              <small>Crop Advice</small>
            </div>

            <div>
              <strong>☁️</strong>
              <small>Weather</small>
            </div>

          </div>

        </div>

      </section>


      {/* FEATURES */}

      <section className="section">

        <div className="section-heading">

          <span>OUR SERVICES</span>

          <h2>
            Everything a Farmer Needs
          </h2>

          <p>
            Access useful agricultural information through
            one simple digital platform.
          </p>

        </div>


        <div className="features-grid">

          <div className="feature-card">

            <div className="feature-icon">
              🌱
            </div>

            <h3>Crop Advisory</h3>

            <p>
              Receive crop-specific recommendations covering
              planting, crop management and harvesting.
            </p>

            <Link to="/advisories">
              Learn More →
            </Link>

          </div>


          <div className="feature-card">

            <div className="feature-icon">
              🐛
            </div>

            <h3>Pest & Disease Advice</h3>

            <p>
              Learn how to identify common agricultural pests
              and diseases and how to manage them.
            </p>

            <Link to="/pests-diseases">
              Learn More →
            </Link>

          </div>


          <div className="feature-card">

            <div className="feature-icon">
              🌦️
            </div>

            <h3>Weather Information</h3>

            <p>
              Access weather information to help make better
              farming decisions.
            </p>

            <Link to="/weather">
              View Weather →
            </Link>

          </div>


          <div className="feature-card">

            <div className="feature-icon">
              👨‍🌾
            </div>

            <h3>Ask an Advisor</h3>

            <p>
              Send agricultural questions to an agricultural
              advisor and receive expert guidance.
            </p>

            <Link to="/ask-advisor">
              Ask Question →
            </Link>

          </div>

        </div>

      </section>


      {/* HOW IT WORKS */}

      <section className="how-section">

        <div className="section-heading">

          <span>HOW IT WORKS</span>

          <h2>
            Get Agricultural Advice in Three Steps
          </h2>

        </div>


        <div className="steps">

          <div className="step">

            <div className="step-number">
              1
            </div>

            <h3>Create Account</h3>

            <p>
              Register as a farmer and provide your
              basic farm information.
            </p>

          </div>


          <div className="step">

            <div className="step-number">
              2
            </div>

            <h3>Select Your Crop</h3>

            <p>
              Select your crop, location and farming
              conditions.
            </p>

          </div>


          <div className="step">

            <div className="step-number">
              3
            </div>

            <h3>Receive Advice</h3>

            <p>
              Get relevant agricultural recommendations
              and expert support.
            </p>

          </div>

        </div>

      </section>


      {/* CTA */}

      <section className="cta">

        <h2>
          Ready to Improve Your Farming?
        </h2>

        <p>
          Join E-Agri Advisory and access agricultural
          information whenever you need it.
        </p>

        <Link to="/register" className="primary-btn">
          Create Farmer Account
        </Link>

      </section>

    </div>
  );
}

export default Home;