import { useEffect, useMemo, useState } from "react";
import { apiFetch } from "../api/client";
import { Alert, Badge, EmptyState, Spinner } from "../components/ui";

const CATEGORIES = [
  { value: "planting", label: "Planting" },
  { value: "fertilization", label: "Fertilization" },
  { value: "irrigation", label: "Irrigation" },
  { value: "weed_management", label: "Weed Management" },
  { value: "harvesting", label: "Harvesting" },
  { value: "general", label: "General" }
];

function categoryLabel(value) {
  return CATEGORIES.find((item) => item.value === value)?.label || value;
}

function formatDate(value) {
  try {
    return new Date(value).toLocaleDateString("en-UG", {
      year: "numeric",
      month: "short",
      day: "numeric"
    });
  } catch {
    return "";
  }
}

function Advisories() {
  const [crops, setCrops] = useState([]);
  const [advisories, setAdvisories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [crop, setCrop] = useState("");
  const [category, setCategory] = useState("");
  const [search, setSearch] = useState("");
  const [appliedSearch, setAppliedSearch] = useState("");

  // Crop list loads once; advisories reload when filters change.
  useEffect(() => {
    const controller = new AbortController();

    apiFetch("/api/advisories/crops", { signal: controller.signal })
      .then((data) => setCrops(data.crops || []))
      .catch(() => {
        // The filter still works without the dropdown options.
      });

    return () => controller.abort();
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");

    const params = new URLSearchParams();
    if (crop) params.set("crop", crop);
    if (category) params.set("category", category);
    if (appliedSearch) params.set("search", appliedSearch);

    const query = params.toString();

    apiFetch(`/api/advisories${query ? `?${query}` : ""}`, {
      signal: controller.signal
    })
      .then((data) => setAdvisories(data.advisories || []))
      .catch((err) => {
        if (err.name !== "AbortError") {
          setError("Advisories are unavailable right now.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, [crop, category, appliedSearch]);

  const hasFilters = Boolean(crop || category || appliedSearch);

  const summary = useMemo(() => {
    if (!advisories.length) return "";
    const count =
      advisories.length === 1
        ? "1 advisory"
        : `${advisories.length} advisories`;
    return crop ? `${count} for ${crop}` : count;
  }, [advisories.length, crop]);

  return (
    <div className="page">
      <div className="page-header">
        <span>AGRICULTURAL ADVISORY</span>
        <h1>Crop Advisory</h1>
        <p>
          Select your crop to receive relevant farming advice from
          agricultural advisors.
        </p>
      </div>

      <div className="advisory-selector">
        <div className="filter-bar">
          <div className="filter-field">
            <label htmlFor="advisory-crop">Select Crop</label>
            <select
              id="advisory-crop"
              value={crop}
              onChange={(e) => setCrop(e.target.value)}
            >
              <option value="">All crops</option>
              {crops.map((item) => (
                <option key={item.crop_id} value={item.name}>
                  {item.name}
                </option>
              ))}
            </select>
          </div>

          <div className="filter-field">
            <label htmlFor="advisory-category">Category</label>
            <select
              id="advisory-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">All categories</option>
              {CATEGORIES.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>

          <div className="filter-field filter-field-grow">
            <label htmlFor="advisory-search">Search</label>
            <form
              className="search-row"
              onSubmit={(e) => {
                e.preventDefault();
                setAppliedSearch(search.trim());
              }}
            >
              <input
                id="advisory-search"
                type="search"
                placeholder="Search advisories..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <button className="btn btn-secondary btn-sm" type="submit">
                Search
              </button>
            </form>
          </div>
        </div>
      </div>

      {loading && <Spinner label="Loading advisories..." />}

      {!loading && error && <Alert type="error">{error}</Alert>}

      {!loading && !error && advisories.length === 0 && (
        <EmptyState
          icon="🌱"
          title={hasFilters ? "No advisories match" : "No advisories yet"}
          message={
            hasFilters
              ? "Try a different crop, category or search term."
              : "Advisories published by agricultural advisors will appear here."
          }
        />
      )}

      {!loading && !error && advisories.length > 0 && (
        <>
          <p className="results-summary">{summary}</p>
          {advisories.map((item) => (
            <article className="advisory-result" key={item.advisory_id}>
              <div className="advisory-meta">
                {item.crop_name && <Badge tone="green">{item.crop_name}</Badge>}
                <Badge tone="amber">{categoryLabel(item.category)}</Badge>
                <span className="meta-date">{formatDate(item.created_at)}</span>
              </div>
              <h2>{item.title}</h2>
              {item.growth_stage && (
                <p className="advisory-stage">Stage: {item.growth_stage}</p>
              )}
              <p className="advisory-content">{item.content}</p>
              {item.author_name && (
                <p className="advisory-author">
                  Published by {item.author_name}
                  {item.author_role === "admin" ? " (Administrator)" : ""}
                </p>
              )}
            </article>
          ))}
        </>
      )}
    </div>
  );
}

export default Advisories;
