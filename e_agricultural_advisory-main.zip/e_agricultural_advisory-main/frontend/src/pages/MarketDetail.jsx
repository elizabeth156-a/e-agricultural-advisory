import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";
import {
  Alert,
  Badge,
  ConfirmDialog,
  EmptyState,
  Spinner
} from "../components/ui";
import { categoryLabel, formatDate, formatPrice } from "../data/market";
import { ListingImage } from "./Market";

export default function MarketDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();

  const [listing, setListing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [actionError, setActionError] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await apiFetch(`/api/market/${id}`);
      setListing(data.listing);
    } catch (err) {
      setError(
        err.status === 404
          ? "This listing does not exist or has been removed."
          : "Could not load this listing. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const isOwner = Boolean(
    listing && user && Number(listing.seller_id) === Number(user.user_id)
  );

  async function toggleStatus() {
    setBusy(true);
    setActionError("");

    try {
      await apiFetch(`/api/market/${listing.listing_id}`, {
        method: "PUT",
        body: JSON.stringify({
          title: listing.title,
          description: listing.description,
          image_url: listing.image_url,
          category: listing.category,
          quantity: listing.quantity,
          unit: listing.unit,
          price: listing.price,
          district: listing.district,
          contact_phone: listing.contact_phone,
          status: listing.status === "available" ? "sold" : "available"
        })
      });
      await load();
    } catch (err) {
      setActionError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function deleteListing() {
    setBusy(true);
    setActionError("");

    try {
      await apiFetch(`/api/market/${listing.listing_id}`, {
        method: "DELETE"
      });
      navigate("/my-listings", { replace: true });
    } catch (err) {
      setActionError(err.message);
      setBusy(false);
      setConfirmDelete(false);
    }
  }

  if (loading) {
    return (
      <div className="market-page">
        <Spinner label="Loading listing..." />
      </div>
    );
  }

  if (error) {
    return (
      <div className="market-page">
        <EmptyState
          icon="🔍"
          title="Listing unavailable"
          message={error}
          action={
            <Link to="/market" className="btn btn-primary">
              Back to Marketplace
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="market-page">
      <p className="market-back">
        <Link to="/market" className="panel-link">← Back to Marketplace</Link>
      </p>

      {actionError && <Alert type="error" onClose={() => setActionError("")}>{actionError}</Alert>}

      <div className="listing-detail">
        <div className="listing-detail-media">
          <ListingImage listing={listing} className="listing-detail-image" />
          <div className="listing-detail-status">
            <Badge tone={listing.status === "available" ? "green" : "gray"}>
              {listing.status === "available" ? "Available" : "Sold"}
            </Badge>
            <Badge tone="amber">{categoryLabel(listing.category)}</Badge>
          </div>
        </div>

        <div className="listing-detail-info">
          <h1>{listing.title}</h1>
          <p className="listing-detail-price">{formatPrice(listing.price)}</p>

          <p className="listing-detail-desc">
            {listing.description || "No description provided."}
          </p>

          <dl className="listing-specs">
            <div>
              <dt>Quantity available</dt>
              <dd>{listing.quantity} {listing.unit}</dd>
            </div>
            <div>
              <dt>Location</dt>
              <dd>{listing.district} District</dd>
            </div>
            <div>
              <dt>Listed on</dt>
              <dd>{formatDate(listing.created_at)}</dd>
            </div>
            <div>
              <dt>Seller</dt>
              <dd>{listing.seller_name || "Farmer"}</dd>
            </div>
            <div>
              <dt>Contact</dt>
              <dd>{listing.seller_contact || "Not provided"}</dd>
            </div>
          </dl>

          {isAuthenticated && !isOwner && listing.status === "available" && (
            <div className="listing-actions">
              <a
                className="btn btn-primary"
                href={
                  listing.seller_contact
                    ? `tel:${listing.seller_contact.replace(/\s+/g, "")}`
                    : undefined
                }
                aria-disabled={!listing.seller_contact}
                onClick={(event) => {
                  if (!listing.seller_contact) event.preventDefault();
                }}
              >
                📞 Call Seller
              </a>
              <span className="form-hint">
                Contact the seller directly to agree on price and delivery.
              </span>
            </div>
          )}

          {!isAuthenticated && listing.status === "available" && (
            <div className="listing-actions">
              <Link to="/login" className="btn btn-primary">
                Login to Contact Seller
              </Link>
            </div>
          )}

          {isOwner && (
            <div className="listing-owner-actions">
              <Link
                to={`/market/${listing.listing_id}/edit`}
                className="btn btn-secondary"
              >
                ✏️ Edit Listing
              </Link>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={toggleStatus}
                disabled={busy}
              >
                {busy
                  ? "Saving..."
                  : listing.status === "available"
                    ? "Mark as Sold"
                    : "Mark as Available"}
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={() => setConfirmDelete(true)}
                disabled={busy}
              >
                🗑 Delete
              </button>
            </div>
          )}
        </div>
      </div>

      {confirmDelete && (
        <ConfirmDialog
          title="Delete listing"
          message={`Delete "${listing.title}"? This cannot be undone.`}
          confirmLabel="Delete"
          danger
          onCancel={() => setConfirmDelete(false)}
          onConfirm={deleteListing}
        />
      )}
    </div>
  );
}
