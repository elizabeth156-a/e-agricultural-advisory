import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";
import { Alert, PageHeader, Spinner } from "../components/ui";
import { DISTRICT_NAMES } from "../data/districts";
import { MARKET_CATEGORIES } from "../data/market";

const MAX_IMAGE_CHARS = 1500000;

const EMPTY_FORM = {
  title: "",
  description: "",
  category: "produce",
  quantity: "",
  unit: "bags",
  price: "",
  district: "",
  contact_phone: "",
  image_url: "",
  status: "available"
};

const UNITS = [
  "bags", "kilograms", "grams", "tonnes", "bunches", "pieces",
  "crates", "jerrycans", "litres", "seedlings", "packets", "other"
];

// Downscales an image in the browser so a compact base64 value can be
// stored directly in the database (no temporary files on the server).
function resizeImage(file) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Please choose an image file."));
      return;
    }

    const reader = new FileReader();

    reader.onerror = () => reject(new Error("Could not read the selected file."));
    reader.onload = () => {
      const img = new Image();

      img.onerror = () => reject(new Error("The selected file is not a valid image."));
      img.onload = () => {
        const maxSide = 1000;
        let { width, height } = img;

        if (width > maxSide || height > maxSide) {
          const scale = Math.min(maxSide / width, maxSide / height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;

        const context = canvas.getContext("2d");
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, width, height);
        context.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL("image/jpeg", 0.82);

        if (dataUrl.length > MAX_IMAGE_CHARS) {
          reject(new Error("That image is still too large. Please use a smaller photo."));
          return;
        }

        resolve(dataUrl);
      };

      img.src = reader.result;
    };

    reader.readAsDataURL(file);
  });
}

export default function ListingForm() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const { user } = useAuth();
  const fileInputRef = useRef(null);

  const [form, setForm] = useState(EMPTY_FORM);
  const [preview, setPreview] = useState("");
  const [loading, setLoading] = useState(isEdit);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [imageBusy, setImageBusy] = useState(false);

  useEffect(() => {
    if (!isEdit) return;

    const controller = new AbortController();

    async function loadListing() {
      try {
        const data = await apiFetch(`/api/market/${id}`, {
          signal: controller.signal
        });
        const listing = data.listing;

        if (Number(listing.seller_id) !== Number(user?.user_id)) {
          navigate("/my-listings", { replace: true });
          return;
        }

        setForm({
          title: listing.title || "",
          description: listing.description || "",
          category: listing.category || "produce",
          quantity: listing.quantity ?? "",
          unit: listing.unit || "bags",
          price: listing.price ?? "",
          district: listing.district || "",
          contact_phone: listing.contact_phone || "",
          image_url: listing.image_url || "",
          status: listing.status || "available"
        });
        setPreview(listing.image_url || "");
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(
            err.status === 404
              ? "This listing no longer exists."
              : "Could not load the listing for editing."
          );
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    loadListing();
    return () => controller.abort();
  }, [id, isEdit, user, navigate]);

  function handleChange(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  async function handleImageChange(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    setImageBusy(true);
    setError("");

    try {
      const dataUrl = await resizeImage(file);
      setForm((current) => ({ ...current, image_url: dataUrl }));
      setPreview(dataUrl);
    } catch (err) {
      setError(err.message);
    } finally {
      setImageBusy(false);
    }
  }

  function handleUrlChange(event) {
    const value = event.target.value;
    setForm((current) => ({ ...current, image_url: value }));
    setPreview(value);
  }

  function clearImage() {
    setForm((current) => ({ ...current, image_url: "" }));
    setPreview("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");

    const numericQuantity = Number(form.quantity);
    const numericPrice = Number(form.price);

    if (!form.title.trim()) {
      setError("Please enter the product name.");
      return;
    }
    if (!Number.isFinite(numericQuantity) || numericQuantity <= 0) {
      setError("Quantity must be a number greater than zero.");
      return;
    }
    if (!Number.isFinite(numericPrice) || numericPrice < 0) {
      setError("Please enter a valid price in Ugandan Shillings.");
      return;
    }
    if (!form.district) {
      setError("Please select your district.");
      return;
    }
    if (form.image_url && !/^(https?:\/\/|data:image\/)/i.test(form.image_url)) {
      setError("The image must be an uploaded photo or a valid image link.");
      return;
    }

    setSaving(true);

    try {
      const payload = {
        title: form.title.trim(),
        description: form.description.trim(),
        image_url: form.image_url || null,
        category: form.category,
        quantity: numericQuantity,
        unit: form.unit,
        price: numericPrice,
        district: form.district,
        contact_phone: form.contact_phone.trim() || null
      };

      if (isEdit) {
        const data = await apiFetch(`/api/market/${id}`, {
          method: "PUT",
          body: JSON.stringify({
            ...payload,
            status: form.status
          })
        });
        navigate(`/market/${id}`, { replace: true, state: { message: data.message } });
      } else {
        const data = await apiFetch("/api/market", {
          method: "POST",
          body: JSON.stringify(payload)
        });
        navigate(`/market/${data.listing_id}`, { replace: true });
      }
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="app-content">
        <Spinner label="Loading listing..." />
      </div>
    );
  }

  return (
    <div className="page">
      <PageHeader
        eyebrow={isEdit ? "EDIT LISTING" : "NEW LISTING"}
        title={isEdit ? "Edit Your Listing" : "Sell a Product"}
        description="Provide accurate details so buyers can find and contact you."
        actions={
          <Link
            to={isEdit ? `/market/${id}` : "/my-listings"}
            className="btn btn-ghost"
          >
            Cancel
          </Link>
        }
      />

      <form className="listing-form" onSubmit={handleSubmit}>
        {error && <Alert type="error" onClose={() => setError("")}>{error}</Alert>}

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="listing-title">Product name *</label>
            <input
              id="listing-title"
              name="title"
              type="text"
              placeholder="e.g. Fresh maize cobs"
              value={form.title}
              onChange={handleChange}
              maxLength={200}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="listing-category">Category *</label>
            <select
              id="listing-category"
              name="category"
              value={form.category}
              onChange={handleChange}
            >
              {MARKET_CATEGORIES.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="listing-description">Description</label>
          <textarea
            id="listing-description"
            name="description"
            rows="4"
            placeholder="Describe quality, condition, availability..."
            value={form.description}
            onChange={handleChange}
            maxLength={2000}
          />
        </div>

        <div className="form-group">
          <label>Product image</label>
          <div className="image-picker">
            {preview ? (
              <div className="image-preview">
                <img src={preview} alt="Product preview" />
                <button
                  type="button"
                  className="btn btn-ghost btn-sm"
                  onClick={clearImage}
                >
                  Remove image
                </button>
              </div>
            ) : (
              <div className="image-placeholder" aria-hidden="true">🖼️</div>
            )}

            <div className="image-picker-controls">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                aria-label="Upload product image"
              />
              {imageBusy && <span className="form-hint">Processing image...</span>}
              <input
                type="url"
                name="image_url"
                placeholder="…or paste an image link (https://)"
                value={form.image_url.startsWith("data:") ? "" : form.image_url}
                onChange={handleUrlChange}
                aria-label="Product image link"
              />
              <span className="form-hint">
                Photos are resized in your browser before saving.
              </span>
            </div>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="listing-quantity">Quantity *</label>
            <input
              id="listing-quantity"
              name="quantity"
              type="number"
              min="0"
              step="any"
              placeholder="e.g. 20"
              value={form.quantity}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="listing-unit">Unit *</label>
            <select
              id="listing-unit"
              name="unit"
              value={form.unit}
              onChange={handleChange}
            >
              {UNITS.map((unit) => (
                <option key={unit} value={unit}>{unit}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="listing-price">Price (UGX) *</label>
            <input
              id="listing-price"
              name="price"
              type="number"
              min="0"
              step="any"
              placeholder="e.g. 250000"
              value={form.price}
              onChange={handleChange}
              required
            />
            <span className="form-hint">Total price for the listed quantity.</span>
          </div>

          <div className="form-group">
            <label htmlFor="listing-district">District *</label>
            <select
              id="listing-district"
              name="district"
              value={form.district}
              onChange={handleChange}
              required
            >
              <option value="">Select district</option>
              {DISTRICT_NAMES.map((name) => (
                <option key={name} value={name}>{name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="listing-phone">Contact phone</label>
          <input
            id="listing-phone"
            name="contact_phone"
            type="tel"
            placeholder="e.g. 0772 123456"
            value={form.contact_phone}
            onChange={handleChange}
            maxLength={30}
          />
          <span className="form-hint">
            Buyers will use this number to reach you.
          </span>
        </div>

        <div className="listing-form-actions">
          <button type="submit" className="btn btn-primary" disabled={saving || imageBusy}>
            {saving
              ? isEdit ? "Saving changes..." : "Publishing listing..."
              : isEdit ? "Save Changes" : "Publish Listing"}
          </button>
          <Link
            to={isEdit ? `/market/${id}` : "/market"}
            className="btn btn-ghost"
          >
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}
