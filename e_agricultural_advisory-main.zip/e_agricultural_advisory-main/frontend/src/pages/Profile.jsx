import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../api/client";
import { Alert, Badge, Spinner } from "../components/ui";
import { DISTRICTS } from "../data/districts";

const MAX_AVATAR_CHARS = 500000;

// Downsizes an uploaded photo in the browser so the profile stores
// a compact data:image URL instead of a server file.
function resizeImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read the image."));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("That file is not a valid image."));
      image.onload = () => {
        const size = 256;
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        const context = canvas.getContext("2d");

        const scale = Math.max(size / image.width, size / image.height);
        const width = image.width * scale;
        const height = image.height * scale;
        context.drawImage(
          image,
          (size - width) / 2,
          (size - height) / 2,
          width,
          height
        );

        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function Profile() {
  const { user, updateUser } = useAuth();

  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const [form, setForm] = useState({
    full_name: "",
    phone: "",
    district: "",
    bio: "",
    avatar_url: ""
  });
  const [saving, setSaving] = useState(false);

  const [passwords, setPasswords] = useState({
    current_password: "",
    new_password: "",
    confirm: ""
  });
  const [passwordSaving, setPasswordSaving] = useState(false);

  const fileRef = useRef(null);

  useEffect(() => {
    const controller = new AbortController();

    apiFetch("/api/auth/me", { signal: controller.signal })
      .then((data) => {
        const row = data.user;
        setProfile(row);
        setForm({
          full_name: row.full_name || "",
          phone: row.phone || "",
          district: row.district || "",
          bio: row.bio || "",
          avatar_url: row.avatar_url || ""
        });
      })
      .catch((err) => {
        if (err.name !== "AbortError") {
          setError(err.message);
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, []);

  function updateField(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function handleAvatarFile(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    setError("");
    setNotice("");

    try {
      const dataUrl = await resizeImage(file);
      if (dataUrl.length > MAX_AVATAR_CHARS) {
        throw new Error("That image is too large even after resizing.");
      }
      updateField("avatar_url", dataUrl);
    } catch (err) {
      setError(err.message);
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    setNotice("");

    try {
      const data = await apiFetch("/api/auth/me", {
        method: "PATCH",
        body: JSON.stringify({
          full_name: form.full_name,
          phone: form.phone,
          district: form.district,
          bio: form.bio,
          avatar_url: form.avatar_url
        })
      });

      setProfile(data.user);
      updateUser({
        full_name: data.user.full_name,
        district: data.user.district,
        avatar_url: data.user.avatar_url
      });
      setNotice("Profile updated.");
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleChangePassword(e) {
    e.preventDefault();
    setError("");
    setNotice("");

    if (passwords.new_password !== passwords.confirm) {
      setError("New passwords do not match.");
      return;
    }

    if (!passwords.new_password) {
      setError("Please enter a new password.");
      return;
    }

    setPasswordSaving(true);

    try {
      const data = await apiFetch("/api/auth/me", {
        method: "PATCH",
        body: JSON.stringify({
          current_password: passwords.current_password,
          new_password: passwords.new_password
        })
      });

      setProfile(data.user);
      setPasswords({
        current_password: "",
        new_password: "",
        confirm: ""
      });
      setNotice("Password changed.");
    } catch (err) {
      setError(err.message);
    } finally {
      setPasswordSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="page">
        <Spinner label="Loading your profile..." />
      </div>
    );
  }

  const roleLabel =
    profile?.role === "admin"
      ? "Administrator"
      : profile?.role === "advisor"
        ? "Advisor"
        : "Farmer";

  const initials = (form.full_name || user?.full_name || "?")
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");

  return (
    <div className="page">
      <div className="page-header">
        <span>ACCOUNT</span>
        <h1>My Profile</h1>
        <p>Manage your personal information and account security.</p>
      </div>

      {error && (
        <Alert type="error" onClose={() => setError("")}>
          {error}
        </Alert>
      )}
      {notice && (
        <Alert type="success" onClose={() => setNotice("")}>
          {notice}
        </Alert>
      )}

      <div className="profile-columns">
        <section className="panel">
          <div className="panel-header">
            <h2>Personal Details</h2>
          </div>

          <form onSubmit={handleSave} className="profile-form">
            <div className="profile-avatar-row">
              {form.avatar_url ? (
                <img
                  className="profile-avatar"
                  src={form.avatar_url}
                  alt="Profile"
                />
              ) : (
                <span className="profile-avatar profile-avatar-fallback">
                  {initials}
                </span>
              )}
              <div className="profile-avatar-actions">
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => fileRef.current?.click()}
                >
                  Upload photo
                </button>
                {form.avatar_url && (
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => updateField("avatar_url", "")}
                  >
                    Remove
                  </button>
                )}
                <small className="form-hint">
                  JPG or PNG, resized automatically.
                </small>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={handleAvatarFile}
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="profile-name">Full name</label>
              <input
                id="profile-name"
                type="text"
                maxLength="150"
                value={form.full_name}
                onChange={(e) => updateField("full_name", e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="profile-email">Email</label>
              <input
                id="profile-email"
                type="email"
                value={profile?.email || ""}
                disabled
              />
              <small className="form-hint">Email cannot be changed.</small>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="profile-phone">Phone</label>
                <input
                  id="profile-phone"
                  type="tel"
                  maxLength="30"
                  placeholder="0772 000000"
                  value={form.phone}
                  onChange={(e) => updateField("phone", e.target.value)}
                />
              </div>

              <div className="form-group">
                <label htmlFor="profile-district">District</label>
                <select
                  id="profile-district"
                  value={form.district}
                  onChange={(e) => updateField("district", e.target.value)}
                >
                  <option value="">Select district</option>
                  {DISTRICTS.map((item) => (
                    <option key={item.district} value={item.district}>
                      {item.district}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="profile-bio">About your farm</label>
              <textarea
                id="profile-bio"
                rows="4"
                maxLength="2000"
                placeholder="Crops you grow, experience, interests..."
                value={form.bio}
                onChange={(e) => updateField("bio", e.target.value)}
              />
            </div>

            <button className="form-btn" type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save Changes"}
            </button>
          </form>
        </section>

        <div className="profile-side">
          <section className="panel">
            <div className="panel-header">
              <h2>Account</h2>
            </div>
            <dl className="profile-facts">
              <div>
                <dt>Role</dt>
                <dd>
                  <Badge tone="green">{roleLabel}</Badge>
                </dd>
              </div>
              <div>
                <dt>Member ID</dt>
                <dd>#{profile?.user_id}</dd>
              </div>
              <div>
                <dt>Member since</dt>
                <dd>
                  {profile?.created_at
                    ? new Date(profile.created_at).toLocaleDateString("en-UG", {
                        year: "numeric",
                        month: "long",
                        day: "numeric"
                      })
                    : "—"}
                </dd>
              </div>
            </dl>
            <div className="profile-links">
              <Link to="/dashboard">📊 Dashboard</Link>
              <Link to="/notifications">🔔 Notifications</Link>
              {profile?.role === "farmer" && (
                <Link to="/my-listings">🏷️ My Listings</Link>
              )}
            </div>
          </section>

          <section className="panel">
            <div className="panel-header">
              <h2>Change Password</h2>
            </div>
            <form onSubmit={handleChangePassword} className="profile-form">
              <div className="form-group">
                <label htmlFor="pw-current">Current password</label>
                <input
                  id="pw-current"
                  type="password"
                  autoComplete="current-password"
                  value={passwords.current_password}
                  onChange={(e) =>
                    setPasswords((c) => ({
                      ...c,
                      current_password: e.target.value
                    }))
                  }
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="pw-new">New password</label>
                <input
                  id="pw-new"
                  type="password"
                  autoComplete="new-password"
                  value={passwords.new_password}
                  onChange={(e) =>
                    setPasswords((c) => ({
                      ...c,
                      new_password: e.target.value
                    }))
                  }
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="pw-confirm">Confirm new password</label>
                <input
                  id="pw-confirm"
                  type="password"
                  autoComplete="new-password"
                  value={passwords.confirm}
                  onChange={(e) =>
                    setPasswords((c) => ({
                      ...c,
                      confirm: e.target.value
                    }))
                  }
                  required
                />
              </div>
              <button
                className="form-btn"
                type="submit"
                disabled={passwordSaving}
              >
                {passwordSaving ? "Updating..." : "Change Password"}
              </button>
            </form>
          </section>
        </div>
      </div>
    </div>
  );
}

export default Profile;
