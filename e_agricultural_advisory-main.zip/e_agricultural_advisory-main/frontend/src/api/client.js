// Central place for API access so every page uses the same base URL,
// authentication header and error handling.
import { useAuth } from "../context/AuthContext";

export const API_URL = (
  import.meta.env.VITE_API_URL ||
  "https://e-agricultural-advisory.onrender.com"
).replace(/\/$/, "");

export function authHeaders(token) {
  return token
    ? { Authorization: `Bearer ${token}` }
    : {};
}

export async function apiFetch(path, { token, ...options } = {}) {
  // Fall back to the stored session token so every authenticated
  // call works without each page having to thread the token
  // through by hand.
  const authToken = token || localStorage.getItem("token") || undefined;

  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(authToken),
      ...(options.headers || {})
    }
  });

  let data = null;
  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok) {
    const error = new Error(
      (data && data.message) || `Request failed (${response.status}).`
    );
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
}

// Convenience hook: fetch with the current user's token attached.
export function useApi() {
  const { token } = useAuth();

  return (path, options = {}) => apiFetch(path, { token, ...options });
}
