import { Outlet, Route, Routes } from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import AppLayout from "./components/AppLayout";
import ProtectedRoute from "./components/ProtectedRoute";
import { NotFound } from "./components/ui";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Advisories from "./pages/Advisories";
import PestsDiseases from "./pages/PestsDiseases";
import Weather from "./pages/Weather";
import AskAdvisor from "./pages/AskAdvisor";
import Market from "./pages/Market";
import MarketDetail from "./pages/MarketDetail";
import ListingForm from "./pages/ListingForm";
import MyListings from "./pages/MyListings";
import Chatroom from "./pages/Chatroom";
import ChatRoom from "./pages/ChatRoom";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";

// Public shell: top navigation and footer around open pages.
function PublicLayout() {
  return (
    <div className="app">
      <Navbar />
      <main>
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <Routes>
      {/* Public pages */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/advisories" element={<Advisories />} />
        <Route path="/pests-diseases" element={<PestsDiseases />} />
        <Route path="/weather" element={<Weather />} />
        <Route path="/market" element={<Market />} />
        <Route path="/market/:id" element={<MarketDetail />} />
        <Route path="*" element={<NotFound />} />
      </Route>

      {/* Authenticated application */}
      <Route
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/ask-advisor" element={<AskAdvisor />} />
        <Route path="/market/new" element={<ListingForm />} />
        <Route path="/market/:id/edit" element={<ListingForm />} />
        <Route path="/my-listings" element={<MyListings />} />
        <Route path="/chatroom" element={<Chatroom />} />
        <Route path="/chatroom/:roomId" element={<ChatRoom />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/notifications" element={<Notifications />} />
      </Route>
    </Routes>
  );
}

export default App;
