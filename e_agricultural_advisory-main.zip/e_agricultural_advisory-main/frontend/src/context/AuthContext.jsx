import { createContext, useContext, useEffect, useMemo, useState } from "react";

const AuthContext = createContext(null);

function readStoredUser() {
  try {
    const raw = localStorage.getItem("user");
    if (!raw) return null;
    const user = JSON.parse(raw);
    return user && user.user_id ? user : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem("token"));
  const [user, setUser] = useState(readStoredUser);

  // Keep state in sync when another tab logs in or out.
  useEffect(() => {
    function onStorage(event) {
      if (event.key === "token" || event.key === "user") {
        setToken(localStorage.getItem("token"));
        setUser(readStoredUser());
      }
    }
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const value = useMemo(() => {
    const isAuthenticated = Boolean(token && user);

    function login(nextToken, nextUser) {
      localStorage.setItem("token", nextToken);
      localStorage.setItem("user", JSON.stringify(nextUser));
      setToken(nextToken);
      setUser(nextUser);
    }

    function logout() {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      setToken(null);
      setUser(null);
    }

    function updateUser(patch) {
      setUser((current) => {
        const next = { ...(current || {}), ...patch };
        localStorage.setItem("user", JSON.stringify(next));
        return next;
      });
    }

    return {
      token,
      user,
      isAuthenticated,
      role: user?.role || null,
      login,
      logout,
      updateUser
    };
  }, [token, user]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used inside <AuthProvider>");
  }
  return context;
}
