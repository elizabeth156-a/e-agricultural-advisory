// PostgreSQL connection pool.
//
// Configuration (production and local development):
//   DATABASE_URL   — full connection string (preferred; every hosted
//                    PostgreSQL provider supplies one), e.g.
//                    postgres://user:pass@host:5432/dbname?sslmode=require
//   — or the individual variables —
//   DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
//
//   DB_SSL=false       disable TLS (local development only)
//   DB_SSL_VERIFY=true require full certificate verification
//                      (default: TLS on, CA not pinned — works with
//                      providers whose certs chain to a public CA)
const { Pool, types } = require("pg");
require("dotenv").config();

// PostgreSQL returns BIGINT (int8) as a string by default. Our IDs fit
// comfortably in a JS number, and the rest of the app (and the previous
// MySQL driver) treats them as numbers, so parse int8 as Number.
types.setTypeParser(20, (value) => Number(value));

// Newer pg releases interpret sslmode=require in a URL as verify-full,
// which overrides any explicit ssl option and fails against providers
// whose certificate chain is not in Node's CA store (e.g. Supabase's
// pooler reports "self-signed certificate in certificate chain").
// So: read sslmode from the URL, strip it, and decide TLS ourselves.
function normalizeConnectionString(raw) {
    if (!raw) return { url: null, urlMode: null };

    try {
        const parsed = new URL(raw);
        const urlMode = parsed.searchParams.get("sslmode");
        parsed.searchParams.delete("sslmode");
        return { url: parsed.toString(), urlMode };
    } catch {
        return { url: raw, urlMode: null };
    }
}

const rawConnectionString = process.env.DATABASE_URL || null;
const { url: connectionString, urlMode } =
    normalizeConnectionString(rawConnectionString);

function resolveSsl() {
    const explicit = process.env.DB_SSL;

    if (explicit === "false" || urlMode === "disable") return false;
    if (explicit === "true" || urlMode) {
        return {
            rejectUnauthorized: process.env.DB_SSL_VERIFY === "true"
        };
    }

    // Safe default: hosted providers require TLS.
    return { rejectUnauthorized: false };
}

const ssl = resolveSsl();

const pool = new Pool(
    connectionString
        ? { connectionString, ssl }
        : {
              host: process.env.DB_HOST,
              user: process.env.DB_USER,
              password: process.env.DB_PASSWORD,
              database: process.env.DB_NAME,
              port: Number(process.env.DB_PORT) || 5432,
              ssl
          }
);

// An idle client error must not take the whole server down.
pool.on("error", (error) => {
    console.error("Unexpected PostgreSQL pool error:", error.message);
});

module.exports = pool;
