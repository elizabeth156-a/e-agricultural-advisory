
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { rateLimit } = require("express-rate-limit");
const pool = require("../config/db");
const { authenticateToken } = require("../middleware/auth");

const router = express.Router();

// Brute-force protection for the credential endpoints. Keyed by
// client IP; the budgets are generous enough for normal use (and
// the test suite) while blocking automated password guessing.
const RATE_WINDOW_MS = 15 * 60 * 1000;
const RATE_MESSAGE = {
    message: "Too many attempts. Please wait a few minutes and try again."
};

const registerLimiter = rateLimit({
    windowMs: RATE_WINDOW_MS,
    limit: 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: RATE_MESSAGE
});

const loginLimiter = rateLimit({
    windowMs: RATE_WINDOW_MS,
    limit: 30,
    standardHeaders: true,
    legacyHeaders: false,
    message: RATE_MESSAGE
});

// Minimum password strength, enforced server-side on registration
// and on password changes.
const MIN_PASSWORD_LENGTH = 8;

// Farmer registration
router.post("/register", registerLimiter, async (req, res) => {
    try {
        const { full_name, email, phone, district, password } = req.body;

        if (!full_name || !email || !password) {
            return res.status(400).json({
                message: "Full name, email and password are required"
            });
        }

        if (password.length < MIN_PASSWORD_LENGTH) {
            return res.status(400).json({
                message: `Password must be at least ${MIN_PASSWORD_LENGTH} characters`
            });
        }

        if (district && district.trim().length > 60) {
            return res.status(400).json({
                message: "District must be 60 characters or fewer"
            });
        }

        const existingUser = await pool.query(
            "SELECT user_id FROM users WHERE email = $1",
            [email.trim().toLowerCase()]
        );

        if (existingUser.rows.length > 0) {
            return res.status(409).json({
                message: "Email already registered"
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const result = await pool.query(
            `INSERT INTO users
            (full_name, email, phone, district, password, role)
            VALUES ($1, $2, $3, $4, $5, 'farmer')
            RETURNING user_id`,
            [
                full_name.trim(),
                email.trim().toLowerCase(),
                phone || null,
                district?.trim() || null,
                hashedPassword
            ]
        );

        res.status(201).json({
            message: "Farmer registered successfully",
            user_id: result.rows[0].user_id
        });
    } catch (error) {
        console.error("Registration error:", error.message);

        res.status(500).json({
            message: "Registration failed"
        });
    }
});

// Login
router.post("/login", loginLimiter, async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                message: "Email and password are required"
            });
        }

        const users = await pool.query(
            `SELECT user_id, full_name, email, phone, district,
                    avatar_url, password, role
             FROM users WHERE email = $1`,
            [email.trim().toLowerCase()]
        );

        if (users.rows.length === 0) {
            return res.status(401).json({
                message: "Invalid email or password"
            });
        }

        const user = users.rows[0];
        const passwordMatches = await bcrypt.compare(
            password,
            user.password
        );

        if (!passwordMatches) {
            return res.status(401).json({
                message: "Invalid email or password"
            });
        }

        if (!process.env.JWT_SECRET) {
            console.error("JWT_SECRET is not configured");
            return res.status(500).json({
                message: "Login service is not configured"
            });
        }

        const token = jwt.sign(
            {
                user_id: user.user_id,
                role: user.role
            },
            process.env.JWT_SECRET,
            { expiresIn: "2h" }
        );

        res.json({
            message: "Login successful",
            token,
            user: {
                user_id: user.user_id,
                full_name: user.full_name,
                email: user.email,
                phone: user.phone,
                district: user.district,
                avatar_url: user.avatar_url,
                role: user.role
            }
        });
    } catch (error) {
        console.error("Login error:", error.message);

        res.status(500).json({
            message: "Login failed"
        });
    }
});

// ------------------------------------------------------------
// Profile
// ------------------------------------------------------------

// Product images are stored as an http(s) URL or a compact
// base64 data:image URL (same convention as market listings).
const MAX_AVATAR_CHARS = 500000;

function isValidImageValue(value) {
    if (value === null || value === undefined || value === "") {
        return true;
    }

    if (typeof value !== "string" || value.length > MAX_AVATAR_CHARS) {
        return false;
    }

    if (/^https?:\/\/\S+$/i.test(value)) {
        return true;
    }

    return /^data:image\/(jpeg|jpg|png|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i.test(
        value
    );
}

// GET /api/auth/me
// The full profile for the signed-in user (JWT holds only the ID).
router.get("/me", authenticateToken, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT user_id, full_name, email, phone, district, bio,
                    avatar_url, role, created_at
             FROM users WHERE user_id = $1`,
            [req.user.user_id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                message: "Account not found."
            });
        }

        res.json({ user: result.rows[0] });
    } catch (error) {
        console.error("Profile error:", error.message);
        res.status(500).json({ message: "Could not load your profile." });
    }
});

// PATCH /api/auth/me
// Update profile fields, optionally change the password
// (requires the current password).
router.patch("/me", authenticateToken, async (req, res) => {
    try {
        const {
            full_name,
            phone,
            district,
            bio,
            avatar_url,
            current_password,
            new_password
        } = req.body;

        const sets = [];
        const params = [];

        function push(column, value) {
            params.push(value);
            sets.push(`${column} = $${params.length}`);
        }

        if (full_name !== undefined) {
            if (!full_name?.trim() || full_name.trim().length > 150) {
                return res.status(400).json({
                    message: "Name is required (150 characters maximum)."
                });
            }
            push("full_name", full_name.trim());
        }

        if (phone !== undefined) {
            if (phone && phone.trim().length > 30) {
                return res.status(400).json({
                    message: "Phone must be 30 characters or fewer."
                });
            }
            push("phone", phone?.trim() || null);
        }

        if (district !== undefined) {
            if (district && district.trim().length > 60) {
                return res.status(400).json({
                    message: "District must be 60 characters or fewer."
                });
            }
            push("district", district?.trim() || null);
        }

        if (bio !== undefined) {
            if (bio && bio.length > 2000) {
                return res.status(400).json({
                    message: "Bio must be 2000 characters or fewer."
                });
            }
            push("bio", bio?.trim() || null);
        }

        if (avatar_url !== undefined) {
            if (!isValidImageValue(avatar_url)) {
                return res.status(400).json({
                    message:
                        "The avatar must be a valid image link or uploaded image."
                });
            }
            push("avatar_url", avatar_url || null);
        }

        // Optional password change.
        const wantsPasswordChange =
            current_password !== undefined || new_password !== undefined;

        if (wantsPasswordChange) {
            if (!current_password || !new_password) {
                return res.status(400).json({
                    message:
                        "Both your current and new password are required."
                });
            }

            if (new_password.length < MIN_PASSWORD_LENGTH) {
                return res.status(400).json({
                    message: `New password must be at least ${MIN_PASSWORD_LENGTH} characters.`
                });
            }

            const rows = await pool.query(
                "SELECT password FROM users WHERE user_id = $1",
                [req.user.user_id]
            );

            const matches = await bcrypt.compare(
                current_password,
                rows.rows[0]?.password || ""
            );

            if (!matches) {
                return res.status(401).json({
                    message: "Your current password is incorrect."
                });
            }

            push("password", await bcrypt.hash(new_password, 10));
        }

        if (sets.length === 0) {
            return res.status(400).json({ message: "No changes provided." });
        }

        params.push(req.user.user_id);

        const result = await pool.query(
            `UPDATE users
             SET ${sets.join(", ")}
             WHERE user_id = $${params.length}
             RETURNING user_id, full_name, email, phone, district, bio,
                       avatar_url, role, created_at`,
            params
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: "Account not found." });
        }

        res.json({
            message: "Profile updated.",
            user: result.rows[0]
        });
    } catch (error) {
        console.error("Profile update error:", error.message);
        res.status(500).json({ message: "Could not update your profile." });
    }
});

module.exports = router;
