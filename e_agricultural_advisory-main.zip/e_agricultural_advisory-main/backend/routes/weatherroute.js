 
const express = require("express");
const router = express.Router();

const WEATHER_API =
  "https://api.open-meteo.com/v1/forecast";

router.get("/", async (req, res) => {
  try {
    const latitude = Number(req.query.latitude);
    const longitude = Number(req.query.longitude);

    if (
      !Number.isFinite(latitude) ||
      !Number.isFinite(longitude) ||
      latitude < -90 ||
      latitude > 90 ||
      longitude < -180 ||
      longitude > 180
    ) {
      return res.status(400).json({
        message: "Valid latitude and longitude are required."
      });
    }

    // Restrict coordinates to Uganda.
    if (
      latitude < -1.5 ||
      latitude > 4.3 ||
      longitude < 29.3 ||
      longitude > 35.1
    ) {
      return res.status(400).json({
        message: "Please select a location within Uganda."
      });
    }

    const params = new URLSearchParams({
      latitude: String(latitude),
      longitude: String(longitude),
      current:
        "temperature_2m,relative_humidity_2m,apparent_temperature," +
        "precipitation,rain,wind_speed_10m,weather_code",
      daily:
        "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum",
      timezone: "Africa/Kampala",
      forecast_days: "7"
    });

    const response = await fetch(`${WEATHER_API}?${params}`);

    if (!response.ok) {
      throw new Error("Weather provider request failed.");
    }

    const weather = await response.json();
    const current = weather.current;
    const daily = weather.daily;

    // The provider can return an error payload without data;
    // treat that the same as a failed request instead of crashing.
    if (!current || !daily || !Array.isArray(daily.time)) {
      throw new Error("Weather provider returned incomplete data.");
    }

    const advice = [];

    if (current.precipitation > 0) {
      advice.push(
        "Rain is occurring or has recently been recorded. Check field drainage and avoid unnecessary irrigation."
      );
    }

    if (
      Array.isArray(daily.precipitation_probability_max) &&
      daily.precipitation_probability_max.some(
        probability => probability >= 60
      )
    ) {
      advice.push(
        "Rain is likely on at least one forecast day. Check soil moisture before irrigating and plan fieldwork around expected showers."
      );
    }

    if (
      Array.isArray(daily.temperature_2m_max) &&
      daily.temperature_2m_max.some(
        temperature => temperature >= 32
      )
    ) {
      advice.push(
        "Hot conditions are forecast on at least one day. Monitor crops for water stress and irrigate when needed."
      );
    }

    if (current.wind_speed_10m >= 20) {
      advice.push(
        "Winds are relatively strong. Consider postponing spraying until conditions are suitable and always follow the pesticide label."
      );
    }

    if (advice.length === 0) {
      advice.push(
        "Conditions may be suitable for routine farm activities. Check soil moisture, crop condition and the local forecast before making decisions."
      );
    }

    res.json({
      location: {
        latitude: weather.latitude,
        longitude: weather.longitude,
        timezone: weather.timezone
      },
      current,
      daily,
      farmingAdvice: advice
    });
  } catch (error) {
    console.error("Weather API error:", error.message);

    res.status(502).json({
      message: "Unable to retrieve weather forecasts. Please try again later."
    });
  }
});

module.exports = router;
