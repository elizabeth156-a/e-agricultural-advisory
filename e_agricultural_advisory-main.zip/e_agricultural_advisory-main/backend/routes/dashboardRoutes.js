// Dashboard statistics — one aggregated payload per user so the
// dashboard shows real numbers instead of static cards.
const express = require("express");
const pool = require("../config/db");
const { authenticateToken } = require("../middleware/auth");

const router = express.Router();

router.get("/stats", authenticateToken, async (req, res) => {
    try {
        const userId = req.user.user_id;
        const role = req.user.role;
        const isStaff = ["advisor", "admin"].includes(role);

        const [
            advisories,
            latestAdvisories,
            unreadNotifications,
            myListings,
            myQuestions,
            pendingQuestions,
            openReports,
            unreadChat
        ] = await Promise.all([
            pool.query("SELECT COUNT(*) AS total FROM advisories"),
            pool.query(
                `SELECT a.advisory_id, a.title, a.category, a.created_at,
                        c.name AS crop_name
                 FROM advisories a
                 LEFT JOIN crops c ON c.crop_id = a.crop_id
                 ORDER BY a.created_at DESC
                 LIMIT 4`
            ),
            pool.query(
                `SELECT COUNT(*) AS total FROM notifications
                 WHERE user_id = $1 AND is_read = false`,
                [userId]
            ),
            role === "farmer"
                ? pool.query(
                      `SELECT COUNT(*) AS total,
                              COUNT(*) FILTER (WHERE status = 'available') AS available
                       FROM market_listings WHERE seller_id = $1`,
                      [userId]
                  )
                : Promise.resolve({ rows: [{ total: 0, available: 0 }] }),
            pool.query(
                `SELECT COUNT(*) AS total,
                        COUNT(*) FILTER (WHERE status = 'answered') AS answered,
                        COUNT(*) FILTER (WHERE status = 'open') AS open
                 FROM questions WHERE asker_id = $1`,
                [userId]
            ),
            isStaff
                ? pool.query(
                      `SELECT COUNT(*) AS total FROM questions WHERE status = 'open'`
                  )
                : Promise.resolve({ rows: [{ total: 0 }] }),
            role === "admin"
                ? pool.query(
                      `SELECT COUNT(*) AS total FROM message_reports
                       WHERE status = 'open'`
                  )
                : Promise.resolve({ rows: [{ total: 0 }] }),
            // Unread chat messages across every room (same rule as
            // the room list: messages from others newer than the
            // member's read pointer for that room).
            pool.query(
                `SELECT COUNT(*) AS total
                 FROM chat_messages m
                 WHERE m.sender_id <> $1
                   AND m.message_id > COALESCE(
                       (SELECT rr.last_read_message_id
                        FROM chat_room_reads rr
                        WHERE rr.user_id = $1 AND rr.room_id = m.room_id),
                       0)`,
                [userId]
            )
        ]);

        res.json({
            stats: {
                advisories_total: Number(advisories.rows[0].total),
                latest_advisories: latestAdvisories.rows,
                unread_notifications: Number(
                    unreadNotifications.rows[0].total
                ),
                my_listings: Number(myListings.rows[0].total),
                my_listings_available: Number(myListings.rows[0].available),
                my_questions: Number(myQuestions.rows[0].total),
                my_questions_answered: Number(myQuestions.rows[0].answered),
                my_questions_open: Number(myQuestions.rows[0].open),
                pending_questions: Number(pendingQuestions.rows[0].total),
                open_reports: Number(openReports.rows[0].total),
                unread_chat_messages: Number(unreadChat.rows[0].total)
            }
        });
    } catch (error) {
        console.error("Dashboard stats error:", error.message);
        res.status(500).json({ message: "Could not load dashboard statistics." });
    }
});

module.exports = router;
