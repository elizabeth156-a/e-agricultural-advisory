// Ask Advisor — farmers ask questions, advisors answer.
const express = require("express");
const pool = require("../config/db");
const { authenticateToken, requireRole } = require("../middleware/auth");

const router = express.Router();

const MAX_TITLE = 200;
const MAX_BODY = 5000;
const VALID_STATUSES = ["open", "answered", "closed"];

const QUESTION_COLUMNS = `
    q.question_id,
    q.title,
    q.body,
    q.status,
    q.crop_id,
    q.crop_name,
    q.created_at,
    q.updated_at,
    q.asker_id,
    u.full_name AS asker_name
`;

// Loads all answers for a set of questions, grouped by question.
async function answersFor(questionIds) {
    if (questionIds.length === 0) return new Map();

    const result = await pool.query(
        `SELECT
            a.answer_id,
            a.question_id,
            a.body,
            a.created_at,
            a.advisor_id,
            u.full_name AS advisor_name
         FROM answers a
         INNER JOIN users u ON u.user_id = a.advisor_id
         WHERE a.question_id = ANY($1::int[])
         ORDER BY a.created_at ASC`,
        [questionIds]
    );

    const grouped = new Map();
    for (const row of result.rows) {
        if (!grouped.has(row.question_id)) {
            grouped.set(row.question_id, []);
        }
        grouped.get(row.question_id).push(row);
    }
    return grouped;
}

// POST /api/questions  { title, body, crop_id?, crop_name? }
// Any logged-in account may ask (farmers are the main users).
router.post("/", authenticateToken, async (req, res) => {
    try {
        const { title, body, crop_id, crop_name } = req.body;

        if (!title?.trim() || !body?.trim()) {
            return res.status(400).json({
                message: "A short title and your question are required."
            });
        }

        if (title.trim().length > MAX_TITLE) {
            return res.status(400).json({
                message: `Title must be ${MAX_TITLE} characters or fewer.`
            });
        }

        if (body.trim().length > MAX_BODY) {
            return res.status(400).json({
                message: `Question must be ${MAX_BODY} characters or fewer.`
            });
        }

        let cropValue = null;
        let cropLabel = crop_name?.trim() || null;

        if (crop_id !== undefined && crop_id !== null && crop_id !== "") {
            const cropId = Number(crop_id);

            if (!Number.isInteger(cropId) || cropId < 1) {
                return res.status(400).json({ message: "Invalid crop." });
            }

            const crop = await pool.query(
                "SELECT name FROM crops WHERE crop_id = $1",
                [cropId]
            );

            if (crop.rows.length === 0) {
                return res.status(400).json({
                    message: "Selected crop does not exist."
                });
            }

            cropValue = cropId;
            cropLabel = cropLabel || crop.rows[0].name;
        }

        const asker = await pool.query(
            "SELECT full_name FROM users WHERE user_id = $1",
            [req.user.user_id]
        );

        if (asker.rows.length === 0) {
            return res.status(401).json({
                message: "Your account could not be found. Please log in again."
            });
        }

        const inserted = await pool.query(
            `INSERT INTO questions
                (asker_id, crop_id, crop_name, title, body, status)
             VALUES ($1, $2, $3, $4, $5, 'open')
             RETURNING question_id, created_at`,
            [
                req.user.user_id,
                cropValue,
                cropLabel,
                title.trim(),
                body.trim()
            ]
        );

        const question = inserted.rows[0];

        // Let advisors and administrators know there is a new question.
        await pool.query(
            `INSERT INTO notifications (user_id, type, title, body, link)
             SELECT user_id, 'question', $1, $2, '/ask-advisor'
             FROM users
             WHERE role IN ('advisor', 'admin') AND user_id <> $3`,
            [
                `New question: ${title.trim().slice(0, 150)}`,
                `${asker.rows[0].full_name} asked a${
                    cropLabel ? ` ${cropLabel}` : ""
                } question.`,
                req.user.user_id
            ]
        );

        res.status(201).json({
            message: "Your question has been submitted.",
            question_id: question.question_id,
            created_at: question.created_at
        });
    } catch (error) {
        console.error("Create question error:", error.message);
        res.status(500).json({ message: "Could not submit the question." });
    }
});

// GET /api/questions/mine
// The asker's own questions, newest first, with answers attached.
router.get("/mine", authenticateToken, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT ${QUESTION_COLUMNS}
             FROM questions q
             INNER JOIN users u ON u.user_id = q.asker_id
             WHERE q.asker_id = $1
             ORDER BY q.created_at DESC`,
            [req.user.user_id]
        );

        const grouped = await answersFor(
            result.rows.map((row) => row.question_id)
        );

        res.json({
            count: result.rows.length,
            questions: result.rows.map((row) => ({
                ...row,
                answers: grouped.get(row.question_id) || []
            }))
        });
    } catch (error) {
        console.error("My questions error:", error.message);
        res.status(500).json({ message: "Could not load your questions." });
    }
});

// GET /api/questions?status=open
// Advisors and administrators: the question queue.
router.get(
    "/",
    authenticateToken,
    requireRole("advisor", "admin"),
    async (req, res) => {
        try {
            const status = VALID_STATUSES.includes(req.query.status)
                ? req.query.status
                : null;

            const params = [];
            let where = "";

            if (status) {
                params.push(status);
                where = "WHERE q.status = $1";
            }

            const result = await pool.query(
                `SELECT ${QUESTION_COLUMNS}
                 FROM questions q
                 INNER JOIN users u ON u.user_id = q.asker_id
                 ${where}
                 ORDER BY CASE q.status WHEN 'open' THEN 0 ELSE 1 END,
                          q.created_at DESC`,
                params
            );

            const grouped = await answersFor(
                result.rows.map((row) => row.question_id)
            );

            res.json({
                count: result.rows.length,
                questions: result.rows.map((row) => ({
                    ...row,
                    answers: grouped.get(row.question_id) || []
                }))
            });
        } catch (error) {
            console.error("Questions queue error:", error.message);
            res.status(500).json({ message: "Could not load questions." });
        }
    }
);

// POST /api/questions/:id/answers  { body }
// Advisors and administrators answer; the asker is notified.
router.post(
    "/:id/answers",
    authenticateToken,
    requireRole("advisor", "admin"),
    async (req, res) => {
        try {
            const questionId = Number(req.params.id);

            if (!Number.isInteger(questionId) || questionId < 1) {
                return res.status(400).json({ message: "Invalid question ID." });
            }

            const body =
                typeof req.body.body === "string" ? req.body.body.trim() : "";

            if (!body) {
                return res.status(400).json({
                    message: "Please write an answer before submitting."
                });
            }

            if (body.length > MAX_BODY) {
                return res.status(400).json({
                    message: `Answer must be ${MAX_BODY} characters or fewer.`
                });
            }

            const questions = await pool.query(
                `SELECT question_id, asker_id, title, status
                 FROM questions WHERE question_id = $1`,
                [questionId]
            );

            if (questions.rows.length === 0) {
                return res.status(404).json({ message: "Question not found." });
            }

            const question = questions.rows[0];

            if (question.status === "closed") {
                return res.status(400).json({
                    message: "Closed questions cannot be answered."
                });
            }

            const inserted = await pool.query(
                `INSERT INTO answers (question_id, advisor_id, body)
                 VALUES ($1, $2, $3)
                 RETURNING answer_id, created_at`,
                [questionId, req.user.user_id, body]
            );

            // First answer moves the question to "answered".
            await pool.query(
                `UPDATE questions
                 SET status = 'answered', updated_at = CURRENT_TIMESTAMP
                 WHERE question_id = $1 AND status = 'open'`,
                [questionId]
            );

            await pool.query(
                `INSERT INTO notifications (user_id, type, title, body, link)
                 VALUES ($1, 'answer', $2, $3, '/ask-advisor')`,
                [
                    question.asker_id,
                    `Your question was answered: ${question.title.slice(0, 150)}`,
                    "An agricultural advisor has replied to your question."
                ]
            );

            res.status(201).json({
                message: "Answer submitted.",
                answer_id: inserted.rows[0].answer_id
            });
        } catch (error) {
            console.error("Answer question error:", error.message);
            res.status(500).json({ message: "Could not submit the answer." });
        }
    }
);

// PATCH /api/questions/:id  { status: 'open' | 'closed' }
// The asker may close their own question; advisors/admins may
// close or reopen any question.
router.patch("/:id", authenticateToken, async (req, res) => {
    try {
        const questionId = Number(req.params.id);
        const { status } = req.body;

        if (
            !Number.isInteger(questionId) ||
            questionId < 1 ||
            !["open", "closed"].includes(status)
        ) {
            return res.status(400).json({
                message: "Invalid question ID or status."
            });
        }

        const existing = await pool.query(
            "SELECT question_id, asker_id, status FROM questions WHERE question_id = $1",
            [questionId]
        );

        if (existing.rows.length === 0) {
            return res.status(404).json({ message: "Question not found." });
        }

        const question = existing.rows[0];
        const isOwner = question.asker_id === req.user.user_id;
        const isStaff = ["advisor", "admin"].includes(req.user.role);

        if (!isOwner && !isStaff) {
            return res.status(403).json({
                message: "You can only manage your own questions."
            });
        }

        // Reopening is reserved for advisors and administrators.
        if (status === "open" && !isStaff) {
            return res.status(403).json({
                message: "Only advisors can reopen a question."
            });
        }

        await pool.query(
            `UPDATE questions
             SET status = $1, updated_at = CURRENT_TIMESTAMP
             WHERE question_id = $2`,
            [status, questionId]
        );

        res.json({ message: `Question marked as ${status}.` });
    } catch (error) {
        console.error("Update question error:", error.message);
        res.status(500).json({ message: "Could not update the question." });
    }
});

module.exports = router;
