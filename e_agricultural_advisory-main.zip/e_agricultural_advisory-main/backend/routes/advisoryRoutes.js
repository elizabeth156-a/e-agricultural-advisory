// Crop advisories — public reading, advisor/admin authoring.
const express = require("express");
const pool = require("../config/db");
const { authenticateToken, requireRole } = require("../middleware/auth");

const router = express.Router();

const VALID_CATEGORIES = [
    "planting",
    "fertilization",
    "irrigation",
    "weed_management",
    "harvesting",
    "general"
];

const ADVISORY_COLUMNS = `
    a.advisory_id,
    a.title,
    a.category,
    a.growth_stage,
    a.content,
    a.created_at,
    a.crop_id,
    c.name AS crop_name,
    a.created_by,
    u.full_name AS author_name,
    u.role AS author_role
`;

// GET /api/advisories/crops
// Public: crop list used by filter dropdowns.
// Registered before /:id so "crops" is not treated as an ID.
router.get("/crops", async (req, res) => {
    try {
        const crops = await pool.query(
            "SELECT crop_id, name FROM crops ORDER BY name ASC"
        );

        res.json({ crops: crops.rows });
    } catch (error) {
        console.error("Advisory crops error:", error.message);
        res.status(500).json({ message: "Could not load crops." });
    }
});

// GET /api/advisories?crop=&category=&search=
// Public: browse advisories.
router.get("/", async (req, res) => {
    try {
        const { crop, category, search } = req.query;

        const conditions = [];
        const params = [];

        if (crop && crop.trim()) {
            const index = params.length + 1;
            conditions.push(`c.name ILIKE $${index}`);
            params.push(crop.trim());
        }

        if (category && VALID_CATEGORIES.includes(category)) {
            const index = params.length + 1;
            conditions.push(`a.category = $${index}`);
            params.push(category);
        }

        if (search && search.trim()) {
            const index = params.length + 1;
            conditions.push(
                `(a.title ILIKE $${index} OR a.content ILIKE $${index})`
            );
            params.push(`%${search.trim()}%`);
        }

        const where = conditions.length
            ? `WHERE ${conditions.join(" AND ")}`
            : "";

        const result = await pool.query(
            `SELECT ${ADVISORY_COLUMNS}
             FROM advisories a
             LEFT JOIN crops c ON c.crop_id = a.crop_id
             LEFT JOIN users u ON u.user_id = a.created_by
             ${where}
             ORDER BY a.created_at DESC`,
            params
        );

        res.json({
            count: result.rows.length,
            advisories: result.rows
        });
    } catch (error) {
        console.error("Advisories error:", error.message);
        res.status(500).json({
            message: "Could not load advisories."
        });
    }
});

// GET /api/advisories/:id
// Public: one advisory with full content.
router.get("/:id", async (req, res) => {
    try {
        const advisoryId = Number(req.params.id);

        if (!Number.isInteger(advisoryId) || advisoryId < 1) {
            return res.status(400).json({ message: "Invalid advisory ID." });
        }

        const result = await pool.query(
            `SELECT ${ADVISORY_COLUMNS}
             FROM advisories a
             LEFT JOIN crops c ON c.crop_id = a.crop_id
             LEFT JOIN users u ON u.user_id = a.created_by
             WHERE a.advisory_id = $1`,
            [advisoryId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: "Advisory not found." });
        }

        res.json({ advisory: result.rows[0] });
    } catch (error) {
        console.error("Get advisory error:", error.message);
        res.status(500).json({ message: "Could not load this advisory." });
    }
});

// POST /api/advisories
// Advisors and administrators publish advisories.
router.post(
    "/",
    authenticateToken,
    requireRole("advisor", "admin"),
    async (req, res) => {
        try {
            const {
                title,
                content,
                crop_id,
                category = "general",
                growth_stage
            } = req.body;

            if (!title?.trim() || !content?.trim()) {
                return res.status(400).json({
                    message: "Title and content are required."
                });
            }

            if (title.trim().length > 200) {
                return res.status(400).json({
                    message: "Title must be 200 characters or fewer."
                });
            }

            if (!VALID_CATEGORIES.includes(category)) {
                return res.status(400).json({
                    message: "Please select a valid category."
                });
            }

            let cropValue = null;

            if (crop_id !== undefined && crop_id !== null && crop_id !== "") {
                const cropId = Number(crop_id);

                if (!Number.isInteger(cropId) || cropId < 1) {
                    return res.status(400).json({ message: "Invalid crop." });
                }

                const crop = await pool.query(
                    "SELECT crop_id FROM crops WHERE crop_id = $1",
                    [cropId]
                );

                if (crop.rows.length === 0) {
                    return res.status(400).json({
                        message: "Selected crop does not exist."
                    });
                }

                cropValue = cropId;
            }

            const result = await pool.query(
                `INSERT INTO advisories
                    (crop_id, title, category, growth_stage, content, created_by)
                 VALUES ($1, $2, $3, $4, $5, $6)
                 RETURNING advisory_id`,
                [
                    cropValue,
                    title.trim(),
                    category,
                    growth_stage?.trim() || null,
                    content.trim(),
                    req.user.user_id
                ]
            );

            res.status(201).json({
                message: "Advisory published.",
                advisory_id: result.rows[0].advisory_id
            });
        } catch (error) {
            console.error("Create advisory error:", error.message);
            res.status(500).json({
                message: "Could not publish the advisory."
            });
        }
    }
);

// PUT /api/advisories/:id
// Author or administrator may update.
router.put(
    "/:id",
    authenticateToken,
    requireRole("advisor", "admin"),
    async (req, res) => {
        try {
            const advisoryId = Number(req.params.id);

            if (!Number.isInteger(advisoryId) || advisoryId < 1) {
                return res.status(400).json({ message: "Invalid advisory ID." });
            }

            const existing = await pool.query(
                "SELECT advisory_id, created_by FROM advisories WHERE advisory_id = $1",
                [advisoryId]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({ message: "Advisory not found." });
            }

            if (
                existing.rows[0].created_by !== req.user.user_id &&
                req.user.role !== "admin"
            ) {
                return res.status(403).json({
                    message: "You can only edit advisories you created."
                });
            }

            const {
                title,
                content,
                crop_id,
                category,
                growth_stage
            } = req.body;

            if (!title?.trim() || !content?.trim()) {
                return res.status(400).json({
                    message: "Title and content are required."
                });
            }

            if (!VALID_CATEGORIES.includes(category)) {
                return res.status(400).json({
                    message: "Please select a valid category."
                });
            }

            let cropValue = null;

            if (crop_id !== undefined && crop_id !== null && crop_id !== "") {
                const cropId = Number(crop_id);

                if (!Number.isInteger(cropId) || cropId < 1) {
                    return res.status(400).json({ message: "Invalid crop." });
                }

                cropValue = cropId;
            }

            await pool.query(
                `UPDATE advisories
                 SET crop_id = $1, title = $2, category = $3,
                     growth_stage = $4, content = $5
                 WHERE advisory_id = $6`,
                [
                    cropValue,
                    title.trim(),
                    category,
                    growth_stage?.trim() || null,
                    content.trim(),
                    advisoryId
                ]
            );

            res.json({ message: "Advisory updated." });
        } catch (error) {
            console.error("Update advisory error:", error.message);
            res.status(500).json({
                message: "Could not update the advisory."
            });
        }
    }
);

// DELETE /api/advisories/:id
// Author or administrator may delete.
router.delete(
    "/:id",
    authenticateToken,
    requireRole("advisor", "admin"),
    async (req, res) => {
        try {
            const advisoryId = Number(req.params.id);

            if (!Number.isInteger(advisoryId) || advisoryId < 1) {
                return res.status(400).json({ message: "Invalid advisory ID." });
            }

            const existing = await pool.query(
                "SELECT advisory_id, created_by FROM advisories WHERE advisory_id = $1",
                [advisoryId]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({ message: "Advisory not found." });
            }

            if (
                existing.rows[0].created_by !== req.user.user_id &&
                req.user.role !== "admin"
            ) {
                return res.status(403).json({
                    message: "You can only delete advisories you created."
                });
            }

            await pool.query(
                "DELETE FROM advisories WHERE advisory_id = $1",
                [advisoryId]
            );

            res.json({ message: "Advisory deleted." });
        } catch (error) {
            console.error("Delete advisory error:", error.message);
            res.status(500).json({
                message: "Could not delete the advisory."
            });
        }
    }
);

module.exports = router;
