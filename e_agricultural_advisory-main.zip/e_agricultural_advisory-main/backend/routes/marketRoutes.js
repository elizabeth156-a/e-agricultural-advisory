
const express = require("express");
const pool = require("../config/db");
const { authenticateToken, requireFarmer } = require("../middleware/auth");

const router = express.Router();

const VALID_CATEGORIES = [
    "produce",
    "seeds",
    "seedlings",
    "fertilizer",
    "other"
];

// Product images are stored as either an http(s) URL or a compact
// base64 data:image URL (no temporary server files are used).
const MAX_IMAGE_CHARS = 1500000;

function isValidImageValue(value) {
    if (value === null || value === undefined || value === "") {
        return true;
    }

    if (typeof value !== "string" || value.length > MAX_IMAGE_CHARS) {
        return false;
    }

    if (/^https?:\/\/\S+$/i.test(value)) {
        return true;
    }

    return /^data:image\/(jpeg|jpg|png|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i.test(
        value
    );
}

const LISTING_COLUMNS = `
    m.listing_id,
    m.seller_id,
    m.title,
    m.description,
    m.image_url,
    m.category,
    m.quantity,
    m.unit,
    m.price,
    m.district,
    m.contact_phone,
    m.status,
    m.created_at,
    u.full_name AS seller_name,
    COALESCE(m.contact_phone, u.phone) AS seller_contact
`;

// GET /api/market
// Public: browse and search available listings
router.get("/", async (req, res) => {
    try {
        const { search, category, district, sort } = req.query;

        const conditions = ["m.status = 'available'"];
        const params = [];

        // $n placeholders are numbered by current parameter count.
        // ILIKE keeps the case-insensitive matching MySQL provided.
        if (search && search.trim()) {
            const index = params.length + 1;
            conditions.push(
                `(m.title ILIKE $${index} OR m.description ILIKE $${index})`
            );
            params.push(`%${search.trim()}%`);
        }

        if (category && VALID_CATEGORIES.includes(category)) {
            const index = params.length + 1;
            conditions.push(`m.category = $${index}`);
            params.push(category);
        }

        if (district && district.trim()) {
            const index = params.length + 1;
            conditions.push(`m.district ILIKE $${index}`);
            params.push(`%${district.trim()}%`);
        }

        let orderBy = "m.created_at DESC";

        if (sort === "price_asc") {
            orderBy = "m.price ASC";
        } else if (sort === "price_desc") {
            orderBy = "m.price DESC";
        }

        const sql = `
            SELECT
                ${LISTING_COLUMNS}
            FROM market_listings m
            INNER JOIN users u ON m.seller_id = u.user_id
            WHERE ${conditions.join(" AND ")}
            ORDER BY ${orderBy}
        `;

        const listings = await pool.query(sql, params);

        res.json({
            count: listings.rows.length,
            listings: listings.rows
        });
    } catch (error) {
        console.error("Market listing error:", error.message);
        res.status(500).json({
            message: "Could not load market listings."
        });
    }
});

// GET /api/market/mine
// Authenticated farmers: all of their own listings (any status).
// Must be registered before GET /:id so "mine" is not treated as an ID.
router.get("/mine", authenticateToken, requireFarmer, async (req, res) => {
    try {
        const listings = await pool.query(
            `SELECT
                ${LISTING_COLUMNS}
             FROM market_listings m
             INNER JOIN users u ON m.seller_id = u.user_id
             WHERE m.seller_id = $1
             ORDER BY m.created_at DESC`,
            [req.user.user_id]
        );

        res.json({
            count: listings.rows.length,
            listings: listings.rows
        });
    } catch (error) {
        console.error("My listings error:", error.message);
        res.status(500).json({
            message: "Could not load your listings."
        });
    }
});

// GET /api/market/:id
// Public: view one listing
router.get("/:id", async (req, res) => {
    try {
        const listingId = Number(req.params.id);

        if (!Number.isInteger(listingId) || listingId < 1) {
            return res.status(400).json({
                message: "Invalid listing ID."
            });
        }

        const rows = await pool.query(
            `SELECT
                ${LISTING_COLUMNS}
             FROM market_listings m
             INNER JOIN users u ON m.seller_id = u.user_id
             WHERE m.listing_id = $1`,
            [listingId]
        );

        if (rows.rows.length === 0) {
            return res.status(404).json({
                message: "Listing not found."
            });
        }

        res.json({ listing: rows.rows[0] });
    } catch (error) {
        console.error("Get market listing error:", error.message);
        res.status(500).json({
            message: "Could not load this listing."
        });
    }
});

// POST /api/market
// Authenticated farmers: publish a listing
router.post("/", authenticateToken, requireFarmer, async (req, res) => {
    try {
        const {
            title,
            description,
            image_url,
            category = "produce",
            quantity,
            unit,
            price,
            district,
            contact_phone
        } = req.body;

        if (
            !title?.trim() ||
            quantity === undefined ||
            quantity === null ||
            quantity === "" ||
            !unit?.trim() ||
            price === undefined ||
            price === null ||
            price === "" ||
            !district?.trim()
        ) {
            return res.status(400).json({
                message: "Title, quantity, unit, price and district are required."
            });
        }

        if (!VALID_CATEGORIES.includes(category)) {
            return res.status(400).json({
                message: "Please select a valid product category."
            });
        }

        if (!isValidImageValue(image_url)) {
            return res.status(400).json({
                message: "The product image must be a valid image link or uploaded image."
            });
        }

        const numericQuantity = Number(quantity);
        const numericPrice = Number(price);

        if (
            !Number.isFinite(numericQuantity) ||
            numericQuantity <= 0 ||
            !Number.isFinite(numericPrice) ||
            numericPrice < 0
        ) {
            return res.status(400).json({
                message: "Quantity must be greater than zero and price cannot be negative."
            });
        }

        const users = await pool.query(
            "SELECT user_id, phone FROM users WHERE user_id = $1",
            [req.user.user_id]
        );

        if (users.rows.length === 0) {
            return res.status(401).json({
                message: "Your account could not be found. Please log in again."
            });
        }

        const seller = users.rows[0];
        const phone = contact_phone?.trim() || seller.phone || null;

        const result = await pool.query(
            `INSERT INTO market_listings
                (seller_id, title, description, image_url, category, quantity,
                 unit, price, district, contact_phone)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
             RETURNING listing_id`,
            [
                seller.user_id,
                title.trim(),
                description?.trim() || null,
                image_url || null,
                category,
                numericQuantity,
                unit.trim(),
                numericPrice,
                district.trim(),
                phone
            ]
        );

        res.status(201).json({
            message: "Market listing created successfully.",
            listing_id: result.rows[0].listing_id
        });
    } catch (error) {
        console.error("Create market listing error:", error.message);
        res.status(500).json({
            message: "Could not create the market listing."
        });
    }
});

// PUT /api/market/:id
// Listing owner: update their listing
router.put("/:id", authenticateToken, requireFarmer, async (req, res) => {
    try {
        const listingId = Number(req.params.id);

        if (!Number.isInteger(listingId) || listingId < 1) {
            return res.status(400).json({
                message: "Invalid listing ID."
            });
        }

        const {
            title,
            description,
            image_url,
            category,
            quantity,
            unit,
            price,
            district,
            contact_phone,
            status
        } = req.body;

        if (
            !title?.trim() ||
            quantity === undefined ||
            quantity === null ||
            quantity === "" ||
            !unit?.trim() ||
            price === undefined ||
            price === null ||
            price === "" ||
            !district?.trim()
        ) {
            return res.status(400).json({
                message: "Title, quantity, unit, price and district are required."
            });
        }

        if (
            !VALID_CATEGORIES.includes(category) ||
            !["available", "sold"].includes(status)
        ) {
            return res.status(400).json({
                message: "Invalid category or listing status."
            });
        }

        if (!isValidImageValue(image_url)) {
            return res.status(400).json({
                message: "The product image must be a valid image link or uploaded image."
            });
        }

        const numericQuantity = Number(quantity);
        const numericPrice = Number(price);

        if (
            !Number.isFinite(numericQuantity) ||
            numericQuantity <= 0 ||
            !Number.isFinite(numericPrice) ||
            numericPrice < 0
        ) {
            return res.status(400).json({
                message: "Invalid quantity or price."
            });
        }

        const result = await pool.query(
            `UPDATE market_listings
             SET title = $1, description = $2, image_url = $3, category = $4,
                 quantity = $5, unit = $6, price = $7, district = $8,
                 contact_phone = $9, status = $10
             WHERE listing_id = $11 AND seller_id = $12`,
            [
                title.trim(),
                description?.trim() || null,
                image_url || null,
                category,
                numericQuantity,
                unit.trim(),
                numericPrice,
                district.trim(),
                contact_phone?.trim() || null,
                status,
                listingId,
                req.user.user_id
            ]
        );

        if (result.rowCount === 0) {
            const existing = await pool.query(
                "SELECT listing_id FROM market_listings WHERE listing_id = $1",
                [listingId]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({
                    message: "Listing not found."
                });
            }

            return res.status(403).json({
                message: "You can only edit your own listings."
            });
        }

        res.json({
            message: "Market listing updated successfully."
        });
    } catch (error) {
        console.error("Update market listing error:", error.message);
        res.status(500).json({
            message: "Could not update the market listing."
        });
    }
});

// DELETE /api/market/:id
// Listing owner: delete their listing
router.delete("/:id", authenticateToken, requireFarmer, async (req, res) => {
    try {
        const listingId = Number(req.params.id);

        if (!Number.isInteger(listingId) || listingId < 1) {
            return res.status(400).json({
                message: "Invalid listing ID."
            });
        }

        const result = await pool.query(
            `DELETE FROM market_listings
             WHERE listing_id = $1 AND seller_id = $2`,
            [listingId, req.user.user_id]
        );

        if (result.rowCount === 0) {
            const existing = await pool.query(
                "SELECT listing_id FROM market_listings WHERE listing_id = $1",
                [listingId]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({
                    message: "Listing not found."
                });
            }

            return res.status(403).json({
                message: "You can only delete your own listings."
            });
        }

        res.json({
            message: "Market listing deleted successfully."
        });
    } catch (error) {
        console.error("Delete market listing error:", error.message);
        res.status(500).json({
            message: "Could not delete the market listing."
        });
    }
});

module.exports = router;
