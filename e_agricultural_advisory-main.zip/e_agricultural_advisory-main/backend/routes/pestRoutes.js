// Pests & diseases reference library — public reading,
// advisor/admin authoring.
const express = require("express");
const pool = require("../config/db");
const { authenticateToken, requireRole } = require("../middleware/auth");

const router = express.Router();

const VALID_TYPES = ["pest", "disease"];

const PEST_COLUMNS = `
    p.pest_id,
    p.name,
    p.pest_type,
    p.summary,
    p.symptoms,
    p.management,
    p.affected_crops,
    p.icon,
    p.created_at,
    p.created_by,
    u.full_name AS author_name
`;

// GET /api/pests?search=&type=
// Public: browse the reference library.
router.get("/", async (req, res) => {
    try {
        const { search, type } = req.query;

        const conditions = [];
        const params = [];

        if (search && search.trim()) {
            const index = params.length + 1;
            conditions.push(
                `(p.name ILIKE $${index} OR p.summary ILIKE $${index}` +
                    ` OR p.symptoms ILIKE $${index}` +
                    ` OR p.affected_crops ILIKE $${index})`
            );
            params.push(`%${search.trim()}%`);
        }

        if (type && VALID_TYPES.includes(type)) {
            const index = params.length + 1;
            conditions.push(`p.pest_type = $${index}`);
            params.push(type);
        }

        const where = conditions.length
            ? `WHERE ${conditions.join(" AND ")}`
            : "";

        const result = await pool.query(
            `SELECT ${PEST_COLUMNS}
             FROM pests p
             LEFT JOIN users u ON u.user_id = p.created_by
             ${where}
             ORDER BY p.name ASC`,
            params
        );

        res.json({
            count: result.rows.length,
            pests: result.rows
        });
    } catch (error) {
        console.error("Pests error:", error.message);
        res.status(500).json({ message: "Could not load pests and diseases." });
    }
});

// GET /api/pests/:id
router.get("/:id", async (req, res) => {
    try {
        const pestId = Number(req.params.id);

        if (!Number.isInteger(pestId) || pestId < 1) {
            return res.status(400).json({ message: "Invalid pest ID." });
        }

        const result = await pool.query(
            `SELECT ${PEST_COLUMNS}
             FROM pests p
             LEFT JOIN users u ON u.user_id = p.created_by
             WHERE p.pest_id = $1`,
            [pestId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: "Entry not found." });
        }

        res.json({ pest: result.rows[0] });
    } catch (error) {
        console.error("Get pest error:", error.message);
        res.status(500).json({ message: "Could not load this entry." });
    }
});

function validatePestBody(body) {
    const { name, pest_type, summary, symptoms, management } = body;

    if (!name?.trim() || !symptoms?.trim() || !management?.trim()) {
        return "Name, symptoms and management are required.";
    }

    if (name.trim().length > 150) {
        return "Name must be 150 characters or fewer.";
    }

    if (!VALID_TYPES.includes(pest_type)) {
        return "Type must be 'pest' or 'disease'.";
    }

    return null;
}

// POST /api/pests — advisors/admins add entries.
router.post(
    "/",
    authenticateToken,
    requireRole("advisor", "admin"),
    async (req, res) => {
        try {
            const problem = validatePestBody(req.body);
            if (problem) {
                return res.status(400).json({ message: problem });
            }

            const {
                name,
                pest_type,
                summary,
                symptoms,
                management,
                affected_crops,
                icon
            } = req.body;

            const result = await pool.query(
                `INSERT INTO pests
                    (name, pest_type, summary, symptoms, management,
                     affected_crops, icon, created_by)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                 RETURNING pest_id`,
                [
                    name.trim(),
                    pest_type,
                    summary?.trim() || null,
                    symptoms.trim(),
                    management.trim(),
                    affected_crops?.trim() || null,
                    icon?.trim() || null,
                    req.user.user_id
                ]
            );

            res.status(201).json({
                message: "Entry added.",
                pest_id: result.rows[0].pest_id
            });
        } catch (error) {
            if (error.code === "23505") {
                return res.status(409).json({
                    message: "An entry with that name already exists."
                });
            }

            console.error("Create pest error:", error.message);
            res.status(500).json({ message: "Could not add the entry." });
        }
    }
);

// PUT /api/pests/:id — advisors/admins update entries.
router.put(
    "/:id",
    authenticateToken,
    requireRole("advisor", "admin"),
    async (req, res) => {
        try {
            const pestId = Number(req.params.id);

            if (!Number.isInteger(pestId) || pestId < 1) {
                return res.status(400).json({ message: "Invalid pest ID." });
            }

            const problem = validatePestBody(req.body);
            if (problem) {
                return res.status(400).json({ message: problem });
            }

            const {
                name,
                pest_type,
                summary,
                symptoms,
                management,
                affected_crops,
                icon
            } = req.body;

            const result = await pool.query(
                `UPDATE pests
                 SET name = $1, pest_type = $2, summary = $3,
                     symptoms = $4, management = $5,
                     affected_crops = $6, icon = $7
                 WHERE pest_id = $8`,
                [
                    name.trim(),
                    pest_type,
                    summary?.trim() || null,
                    symptoms.trim(),
                    management.trim(),
                    affected_crops?.trim() || null,
                    icon?.trim() || null,
                    pestId
                ]
            );

            if (result.rowCount === 0) {
                return res.status(404).json({ message: "Entry not found." });
            }

            res.json({ message: "Entry updated." });
        } catch (error) {
            if (error.code === "23505") {
                return res.status(409).json({
                    message: "An entry with that name already exists."
                });
            }

            console.error("Update pest error:", error.message);
            res.status(500).json({ message: "Could not update the entry." });
        }
    }
);

// DELETE /api/pests/:id — advisors/admins remove entries.
router.delete(
    "/:id",
    authenticateToken,
    requireRole("advisor", "admin"),
    async (req, res) => {
        try {
            const pestId = Number(req.params.id);

            if (!Number.isInteger(pestId) || pestId < 1) {
                return res.status(400).json({ message: "Invalid pest ID." });
            }

            const result = await pool.query(
                "DELETE FROM pests WHERE pest_id = $1",
                [pestId]
            );

            if (result.rowCount === 0) {
                return res.status(404).json({ message: "Entry not found." });
            }

            res.json({ message: "Entry deleted." });
        } catch (error) {
            console.error("Delete pest error:", error.message);
            res.status(500).json({ message: "Could not delete the entry." });
        }
    }
);

module.exports = router;
