// Per-user notifications (bell menu).
const express = require("express");
const pool = require("../config/db");
const { authenticateToken } = require("../middleware/auth");

const router = express.Router();

router.use(authenticateToken);

const MAX_ITEMS = 100;

// GET /api/notifications
// The signed-in user's notifications plus their unread count.
router.get("/", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT
                notification_id,
                type,
                title,
                body,
                link,
                is_read,
                created_at
             FROM notifications
             WHERE user_id = $1
             ORDER BY created_at DESC
             LIMIT $2`,
            [req.user.user_id, MAX_ITEMS]
        );

        const unread = await pool.query(
            `SELECT COUNT(*) AS unread
             FROM notifications
             WHERE user_id = $1 AND is_read = false`,
            [req.user.user_id]
        );

        res.json({
            unread: Number(unread.rows[0].unread),
            notifications: result.rows
        });
    } catch (error) {
        console.error("Notifications error:", error.message);
        res.status(500).json({ message: "Could not load notifications." });
    }
});

// PATCH /api/notifications/:id/read
// Marks one of the user's own notifications as read.
router.patch("/:id/read", async (req, res) => {
    try {
        const notificationId = Number(req.params.id);

        if (!Number.isInteger(notificationId) || notificationId < 1) {
            return res.status(400).json({ message: "Invalid notification ID." });
        }

        const result = await pool.query(
            `UPDATE notifications
             SET is_read = true
             WHERE notification_id = $1 AND user_id = $2`,
            [notificationId, req.user.user_id]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({ message: "Notification not found." });
        }

        res.json({ message: "Notification marked as read." });
    } catch (error) {
        console.error("Mark notification error:", error.message);
        res.status(500).json({ message: "Could not update the notification." });
    }
});

// POST /api/notifications/read-all
router.post("/read-all", async (req, res) => {
    try {
        const result = await pool.query(
            `UPDATE notifications
             SET is_read = true
             WHERE user_id = $1 AND is_read = false`,
            [req.user.user_id]
        );

        res.json({
            message: "All notifications marked as read.",
            updated: result.rowCount
        });
    } catch (error) {
        console.error("Mark all notifications error:", error.message);
        res.status(500).json({ message: "Could not update notifications." });
    }
});

module.exports = router;
