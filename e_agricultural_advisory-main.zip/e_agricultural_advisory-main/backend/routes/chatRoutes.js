// Farmer chatroom API — database-backed messaging with polling.
// (Real-time transport such as Socket.IO can be layered on later
// without changing these endpoints.)
const express = require("express");
const pool = require("../config/db");
const { authenticateToken, requireRole } = require("../middleware/auth");

const router = express.Router();

// Every chat endpoint requires a logged-in account.
router.use(authenticateToken);

const MAX_MESSAGE_LENGTH = 5000;
const MAX_REASON_LENGTH = 500;
const DEFAULT_PAGE_SIZE = 50;
const MAX_PAGE_SIZE = 100;

// PostgreSQL unique-violation error code.
const UNIQUE_VIOLATION = "23505";

function isValidId(value) {
    const id = Number(value);
    return Number.isInteger(id) && id >= 1;
}

// Loads a room, hiding inactive rooms from non-administrators.
async function findRoom(roomId, role) {
    const result = await pool.query(
        "SELECT * FROM chat_rooms WHERE room_id = $1",
        [roomId]
    );

    if (result.rows.length === 0) return null;

    const room = result.rows[0];
    if (!room.is_active && role !== "admin") return null;

    return room;
}

// GET /api/chat/rooms
// Room list with unread counts and the latest message preview.
router.get("/rooms", async (req, res) => {
    try {
        const isAdmin = req.user.role === "admin";

        const result = await pool.query(
            `SELECT
                r.room_id,
                r.name,
                r.description,
                r.icon,
                r.is_active,
                (SELECT COUNT(*)
                 FROM chat_messages m
                 WHERE m.room_id = r.room_id) AS message_count,
                (SELECT m.body
                 FROM chat_messages m
                 WHERE m.room_id = r.room_id
                 ORDER BY m.message_id DESC
                 LIMIT 1) AS last_message,
                (SELECT m.created_at
                 FROM chat_messages m
                 WHERE m.room_id = r.room_id
                 ORDER BY m.message_id DESC
                 LIMIT 1) AS last_message_at,
                (SELECT COUNT(*)
                 FROM chat_messages m
                 WHERE m.room_id = r.room_id
                   AND m.sender_id <> $1
                   AND m.message_id > COALESCE(
                       (SELECT rr.last_read_message_id
                        FROM chat_room_reads rr
                        WHERE rr.room_id = r.room_id
                          AND rr.user_id = $2),
                       0)) AS unread_count
             FROM chat_rooms r
             WHERE r.is_active = true OR $3 = 1
             ORDER BY r.name ASC`,
            [req.user.user_id, req.user.user_id, isAdmin ? 1 : 0]
        );

        res.json({ rooms: result.rows });
    } catch (error) {
        console.error("Chat rooms error:", error.message);
        res.status(500).json({ message: "Could not load discussion rooms." });
    }
});

// GET /api/chat/rooms/:id/messages?before=&limit=
// Latest messages, newest first in SQL, returned oldest-first for display.
router.get("/rooms/:id/messages", async (req, res) => {
    try {
        const roomId = Number(req.params.id);

        if (!isValidId(roomId)) {
            return res.status(400).json({ message: "Invalid room ID." });
        }

        const room = await findRoom(roomId, req.user.role);
        if (!room) {
            return res.status(404).json({ message: "Discussion room not found." });
        }

        let limit = Number(req.query.limit);
        if (!Number.isInteger(limit) || limit < 1) {
            limit = DEFAULT_PAGE_SIZE;
        }
        limit = Math.min(limit, MAX_PAGE_SIZE);

        const before = Number(req.query.before);
        const useCursor = Number.isInteger(before) && before > 0;

        // Placeholders: $1 room, optionally $2 cursor, last = limit.
        const cursorClause = useCursor ? "AND m.message_id < $2" : "";
        const limitIndex = useCursor ? 3 : 2;
        const params = useCursor ? [roomId, before, limit] : [roomId, limit];

        const result = await pool.query(
            `SELECT
                m.message_id,
                m.body,
                m.created_at,
                u.user_id AS sender_id,
                u.full_name AS sender_name,
                u.role AS sender_role
             FROM chat_messages m
             INNER JOIN users u ON u.user_id = m.sender_id
             WHERE m.room_id = $1
             ${cursorClause}
             ORDER BY m.message_id DESC
             LIMIT $${limitIndex}`,
            params
        );

        res.json({
            room: {
                room_id: room.room_id,
                name: room.name,
                description: room.description,
                icon: room.icon,
                is_active: room.is_active
            },
            messages: result.rows.reverse(),
            hasMore: result.rows.length === limit
        });
    } catch (error) {
        console.error("Chat messages error:", error.message);
        res.status(500).json({ message: "Could not load messages." });
    }
});

// POST /api/chat/rooms/:id/messages  { body }
router.post("/rooms/:id/messages", async (req, res) => {
    try {
        const roomId = Number(req.params.id);

        if (!isValidId(roomId)) {
            return res.status(400).json({ message: "Invalid room ID." });
        }

        const room = await findRoom(roomId, req.user.role);
        if (!room) {
            return res.status(404).json({ message: "Discussion room not found." });
        }

        if (!room.is_active) {
            return res.status(403).json({
                message: "This room is closed for new messages."
            });
        }

        const body = typeof req.body.body === "string" ? req.body.body.trim() : "";

        if (!body) {
            return res.status(400).json({ message: "Message cannot be empty." });
        }

        if (body.length > MAX_MESSAGE_LENGTH) {
            return res.status(400).json({
                message: `Message must be ${MAX_MESSAGE_LENGTH} characters or fewer.`
            });
        }

        const inserted = await pool.query(
            `INSERT INTO chat_messages (room_id, sender_id, body)
             VALUES ($1, $2, $3)
             RETURNING message_id, body, created_at`,
            [roomId, req.user.user_id, body]
        );
        const newMessage = inserted.rows[0];

        // Sending a message marks the room as read for the sender.
        await pool.query(
            `INSERT INTO chat_room_reads (user_id, room_id, last_read_message_id)
             VALUES ($1, $2, $3)
             ON CONFLICT (user_id, room_id) DO UPDATE SET
                last_read_message_id = GREATEST(
                    chat_room_reads.last_read_message_id,
                    EXCLUDED.last_read_message_id
                )`,
            [req.user.user_id, roomId, newMessage.message_id]
        );

        const sender = await pool.query(
            `SELECT user_id, full_name, role FROM users WHERE user_id = $1`,
            [req.user.user_id]
        );
        const senderRow = sender.rows[0];

        res.status(201).json({
            message: {
                message_id: newMessage.message_id,
                body: newMessage.body,
                created_at: newMessage.created_at,
                sender_id: senderRow.user_id,
                sender_name: senderRow.full_name,
                sender_role: senderRow.role
            }
        });
    } catch (error) {
        console.error("Send message error:", error.message);
        res.status(500).json({ message: "Could not send the message." });
    }
});

// POST /api/chat/rooms/:id/read  { last_read_message_id }
router.post("/rooms/:id/read", async (req, res) => {
    try {
        const roomId = Number(req.params.id);
        const lastRead = Number(req.body.last_read_message_id);

        if (!isValidId(roomId) || !Number.isInteger(lastRead) || lastRead < 0) {
            return res.status(400).json({ message: "Invalid read position." });
        }

        const room = await findRoom(roomId, req.user.role);
        if (!room) {
            return res.status(404).json({ message: "Discussion room not found." });
        }

        await pool.query(
            `INSERT INTO chat_room_reads (user_id, room_id, last_read_message_id)
             VALUES ($1, $2, $3)
             ON CONFLICT (user_id, room_id) DO UPDATE SET
                last_read_message_id = GREATEST(
                    chat_room_reads.last_read_message_id,
                    EXCLUDED.last_read_message_id
                )`,
            [req.user.user_id, roomId, lastRead]
        );

        res.json({ message: "Read position updated." });
    } catch (error) {
        console.error("Chat read error:", error.message);
        res.status(500).json({ message: "Could not update read position." });
    }
});

// POST /api/chat/messages/:id/report  { reason }
router.post("/messages/:id/report", async (req, res) => {
    try {
        const messageId = Number(req.params.id);

        if (!isValidId(messageId)) {
            return res.status(400).json({ message: "Invalid message ID." });
        }

        const reason =
            typeof req.body.reason === "string" ? req.body.reason.trim() : "";

        if (!reason) {
            return res.status(400).json({
                message: "Please explain why you are reporting this message."
            });
        }

        if (reason.length > MAX_REASON_LENGTH) {
            return res.status(400).json({
                message: `Reason must be ${MAX_REASON_LENGTH} characters or fewer.`
            });
        }

        const messages = await pool.query(
            "SELECT message_id FROM chat_messages WHERE message_id = $1",
            [messageId]
        );

        if (messages.rows.length === 0) {
            return res.status(404).json({ message: "Message not found." });
        }

        await pool.query(
            `INSERT INTO message_reports
                (message_id, reporter_id, reason, status, created_at)
             VALUES ($1, $2, $3, 'open', CURRENT_TIMESTAMP)
             ON CONFLICT (message_id, reporter_id) DO UPDATE SET
                reason = EXCLUDED.reason,
                status = 'open',
                created_at = CURRENT_TIMESTAMP`,
            [messageId, req.user.user_id, reason]
        );

        res.status(201).json({
            message: "Report submitted. An administrator will review it."
        });
    } catch (error) {
        console.error("Report message error:", error.message);
        res.status(500).json({ message: "Could not submit the report." });
    }
});

// ------------------------------------------------------------
// Administrator moderation
// ------------------------------------------------------------

// GET /api/chat/reports?status=open
router.get("/reports", requireRole("admin"), async (req, res) => {
    try {
        const status = ["open", "reviewed", "dismissed"].includes(
            req.query.status
        )
            ? req.query.status
            : "open";

        const result = await pool.query(
            `SELECT
                rep.report_id,
                rep.reason,
                rep.status,
                rep.created_at,
                m.message_id,
                m.body AS message_body,
                m.created_at AS message_created_at,
                r.room_id,
                r.name AS room_name,
                ru.full_name AS reporter_name,
                su.user_id AS sender_id,
                su.full_name AS sender_name
             FROM message_reports rep
             INNER JOIN chat_messages m ON m.message_id = rep.message_id
             INNER JOIN chat_rooms r ON r.room_id = m.room_id
             INNER JOIN users ru ON ru.user_id = rep.reporter_id
             INNER JOIN users su ON su.user_id = m.sender_id
             WHERE rep.status = $1
             ORDER BY rep.created_at DESC
             LIMIT 100`,
            [status]
        );

        res.json({ reports: result.rows });
    } catch (error) {
        console.error("Chat reports error:", error.message);
        res.status(500).json({ message: "Could not load reports." });
    }
});

// PATCH /api/chat/reports/:id  { status: 'reviewed' | 'dismissed' }
router.patch("/reports/:id", requireRole("admin"), async (req, res) => {
    try {
        const reportId = Number(req.params.id);
        const { status } = req.body;

        if (!isValidId(reportId) || !["reviewed", "dismissed"].includes(status)) {
            return res.status(400).json({
                message: "Invalid report ID or status."
            });
        }

        const result = await pool.query(
            `UPDATE message_reports
             SET status = $1, reviewed_by = $2, reviewed_at = CURRENT_TIMESTAMP
             WHERE report_id = $3`,
            [status, req.user.user_id, reportId]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({ message: "Report not found." });
        }

        res.json({ message: `Report marked as ${status}.` });
    } catch (error) {
        console.error("Update report error:", error.message);
        res.status(500).json({ message: "Could not update the report." });
    }
});

// DELETE /api/chat/messages/:id — remove inappropriate content.
router.delete("/messages/:id", requireRole("admin"), async (req, res) => {
    try {
        const messageId = Number(req.params.id);

        if (!isValidId(messageId)) {
            return res.status(400).json({ message: "Invalid message ID." });
        }

        const result = await pool.query(
            "DELETE FROM chat_messages WHERE message_id = $1",
            [messageId]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({ message: "Message not found." });
        }

        res.json({ message: "Message removed." });
    } catch (error) {
        console.error("Delete message error:", error.message);
        res.status(500).json({ message: "Could not remove the message." });
    }
});

// POST /api/chat/rooms  { name, description?, icon? }  (admin)
router.post("/rooms", requireRole("admin"), async (req, res) => {
    try {
        const name = typeof req.body.name === "string" ? req.body.name.trim() : "";
        const description =
            typeof req.body.description === "string"
                ? req.body.description.trim().slice(0, 255)
                : null;
        const icon =
            typeof req.body.icon === "string" && req.body.icon.trim()
                ? req.body.icon.trim().slice(0, 10)
                : null;

        if (!name || name.length > 100) {
            return res.status(400).json({
                message: "Room name is required (100 characters maximum)."
            });
        }

        const result = await pool.query(
            `INSERT INTO chat_rooms (name, description, icon)
             VALUES ($1, $2, $3)
             RETURNING room_id`,
            [name, description, icon]
        );

        res.status(201).json({
            message: "Discussion room created.",
            room_id: result.rows[0].room_id
        });
    } catch (error) {
        if (error.code === UNIQUE_VIOLATION) {
            return res.status(409).json({
                message: "A room with that name already exists."
            });
        }

        console.error("Create room error:", error.message);
        res.status(500).json({ message: "Could not create the room." });
    }
});

// PATCH /api/chat/rooms/:id  { name?, description?, icon?, is_active? } (admin)
router.patch("/rooms/:id", requireRole("admin"), async (req, res) => {
    try {
        const roomId = Number(req.params.id);

        if (!isValidId(roomId)) {
            return res.status(400).json({ message: "Invalid room ID." });
        }

        const existing = await pool.query(
            "SELECT * FROM chat_rooms WHERE room_id = $1",
            [roomId]
        );

        if (existing.rows.length === 0) {
            return res.status(404).json({ message: "Room not found." });
        }

        const room = existing.rows[0];

        const name =
            typeof req.body.name === "string" && req.body.name.trim()
                ? req.body.name.trim().slice(0, 100)
                : room.name;

        const description =
            typeof req.body.description === "string"
                ? req.body.description.trim().slice(0, 255)
                : room.description;

        const icon =
            typeof req.body.icon === "string"
                ? req.body.icon.trim().slice(0, 10) || null
                : room.icon;

        const isActive =
            typeof req.body.is_active === "boolean"
                ? req.body.is_active
                : room.is_active;

        await pool.query(
            `UPDATE chat_rooms
             SET name = $1, description = $2, icon = $3, is_active = $4
             WHERE room_id = $5`,
            [name, description, icon, isActive, roomId]
        );

        res.json({ message: "Room updated." });
    } catch (error) {
        if (error.code === UNIQUE_VIOLATION) {
            return res.status(409).json({
                message: "A room with that name already exists."
            });
        }

        console.error("Update room error:", error.message);
        res.status(500).json({ message: "Could not update the room." });
    }
});

module.exports = router;
