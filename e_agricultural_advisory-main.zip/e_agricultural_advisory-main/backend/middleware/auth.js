// Shared authentication and authorisation middleware.
const jwt = require("jsonwebtoken");

// Verifies the Bearer token and attaches the JWT payload to req.user.
function authenticateToken(req, res, next) {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            message: "Please log in to continue."
        });
    }

    if (!process.env.JWT_SECRET) {
        return res.status(500).json({
            message: "Authentication service is not configured."
        });
    }

    jwt.verify(token, process.env.JWT_SECRET, (error, user) => {
        if (error) {
            return res.status(401).json({
                message: "Your session has expired. Please log in again."
            });
        }

        req.user = user;
        next();
    });
}

// Allows only the listed roles (e.g. requireRole("advisor", "admin")).
function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({
                message: "You do not have permission to perform this action."
            });
        }

        next();
    };
}

// Marketplace listings may only be published by farmers.
function requireFarmer(req, res, next) {
    if (!req.user || req.user.role !== "farmer") {
        return res.status(403).json({
            message: "Only farmer accounts can publish market listings."
        });
    }

    next();
}

module.exports = { authenticateToken, requireRole, requireFarmer };
