// Applies the base schema and migrations to a PostgreSQL database.
// Usage: node apply-sql.js <connectionString> [file ...]
// Default files: schema_postgres.sql + migrations 001-003.
const fs = require("fs");
const path = require("path");
const { Client } = require("pg");

async function main() {
    const connectionString = process.argv[2];
    if (!connectionString) {
        console.error("Usage: node apply-sql.js <connectionString> [files...]");
        process.exit(1);
    }

    const repoRoot = path.join(__dirname, "../..");
    const files = process.argv.slice(3);
    const targets = files.length
        ? files
        : [
              "database/schema_postgres.sql",
              "database/migrations/001_market_listings_image_url.sql",
              "database/migrations/002_chatroom.sql",
              "database/migrations/003_seed_chat_rooms.sql",
              "database/migrations/004_ask_advisor.sql",
              "database/migrations/005_pests.sql",
              "database/migrations/006_notifications.sql",
              "database/migrations/007_user_profile.sql"
          ];

    // Same TLS handling as config/db.js: newer pg treats sslmode=require
    // in a URL as verify-full, which fails against Supabase's pooler.
    // Strip sslmode and pass the ssl option explicitly. Default for this
    // script is no TLS (local dev); hosted URLs carry sslmode=require.
    let url = connectionString;
    let urlMode = null;
    try {
        const parsed = new URL(url);
        urlMode = parsed.searchParams.get("sslmode");
        parsed.searchParams.delete("sslmode");
        url = parsed.toString();
    } catch {
        // keep the original string if it is not a parseable URL
    }

    const explicitSsl = process.env.DB_SSL;
    let ssl;
    if (explicitSsl === "false" || urlMode === "disable") {
        ssl = false;
    } else if (explicitSsl === "true" || urlMode) {
        ssl = { rejectUnauthorized: process.env.DB_SSL_VERIFY === "true" };
    } else {
        ssl = false;
    }

    const client = new Client({ connectionString: url, ssl });
    await client.connect();

    try {
        for (const relative of targets) {
            const file = path.isAbsolute(relative)
                ? relative
                : path.join(repoRoot, relative);
            const sql = fs.readFileSync(file, "utf8");
            console.log(`Applying ${relative} ...`);
            await client.query(sql);
            console.log("  OK");
        }
        console.log("All SQL applied.");
    } finally {
        await client.end();
    }
}

main().catch((error) => {
    console.error("FAILED:", error.message);
    process.exit(1);
});
