// Promotes (or demotes) a registered account to another role.
// Usage: node scripts/set-role.js <email> <farmer|advisor|admin>
//
// Registration always creates farmers, so this is the supported way
// to create the first advisor/administrator account: register through
// the app, then run this script with your email.
const pool = require("../config/db");

const VALID_ROLES = ["farmer", "advisor", "admin"];

async function main() {
    const email = (process.argv[2] || "").trim().toLowerCase();
    const role = (process.argv[3] || "").trim().toLowerCase();

    if (!email || !VALID_ROLES.includes(role)) {
        console.error("Usage: node scripts/set-role.js <email> <farmer|advisor|admin>");
        process.exit(1);
    }

    const result = await pool.query(
        "UPDATE users SET role = $1 WHERE email = $2 RETURNING user_id, full_name, role",
        [role, email]
    );

    if (result.rowCount === 0) {
        console.error(`No user found with email ${email}`);
        process.exit(1);
    }

    const user = result.rows[0];
    console.log(`Updated: ${user.full_name} <${email}> -> role '${user.role}'`);
    await pool.end();
}

main().catch((error) => {
    console.error("FAILED:", error.message);
    process.exit(1);
});
