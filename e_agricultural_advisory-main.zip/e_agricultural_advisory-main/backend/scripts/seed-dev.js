// ============================================================
// LOCAL DEV SEED — never run against the production database.
// Creates test accounts for each role plus sample content so
// the full application can be exercised locally.
//
// Usage:  node scripts/seed-dev.js
// (expects DATABASE_URL or DB_* environment pointing at the
//  local development database)
// ============================================================
const bcrypt = require("bcryptjs");
const pool = require("../config/db");

const PASSWORD = "Password123!";

async function main() {
    const hash = await bcrypt.hash(PASSWORD, 10);

    const users = [
        ["Test Farmer", "farmer@example.com", "0772000001", "farmer"],
        ["Test Advisor", "advisor@example.com", "0772000002", "advisor"],
        ["Test Admin", "admin@example.com", "0772000003", "admin"]
    ];

    for (const [name, email, phone, role] of users) {
        await pool.query(
            `INSERT INTO users (full_name, email, phone, password, role)
             VALUES ($1, $2, $3, $4, $5)
             ON CONFLICT (email) DO UPDATE SET full_name = EXCLUDED.full_name`,
            [name, email, phone, hash, role]
        );
    }

    const crops = ["Maize", "Beans", "Tomatoes", "Coffee", "Cassava", "Bananas"];
    for (const crop of crops) {
        await pool.query(
            `INSERT INTO crops (name) VALUES ($1)
             ON CONFLICT (name) DO NOTHING`,
            [crop]
        );
    }

    const maize = await pool.query(
        "SELECT crop_id FROM crops WHERE name = 'Maize'"
    );
    const advisor = await pool.query(
        "SELECT user_id FROM users WHERE email = 'advisor@example.com'"
    );
    const farmer = await pool.query(
        "SELECT user_id FROM users WHERE email = 'farmer@example.com'"
    );

    const existingAdvisories = await pool.query(
        "SELECT COUNT(*) AS total FROM advisories"
    );

    if (Number(existingAdvisories.rows[0].total) === 0) {
        await pool.query(
            `INSERT INTO advisories
                (crop_id, title, category, growth_stage, content, created_by)
             VALUES ($1, $2, 'planting', 'Land preparation', $3, $4)`,
            [
                maize.rows[0]?.crop_id || null,
                "Maize planting guide for the long rains",
                "Plough and harrow early, plant certified seed at 75x25 cm spacing, " +
                "apply planting fertiliser at 50 kg per acre, and plant at the onset " +
                "of reliable rains.",
                advisor.rows[0]?.user_id || null
            ]
        );

        await pool.query(
            `INSERT INTO advisories
                (crop_id, title, category, growth_stage, content, created_by)
             VALUES ($1, $2, 'general', 'Crop management', $3, $4)`,
            [
                maize.rows[0]?.crop_id || null,
                "Weed control in maize",
                "Weed within three weeks of emergence to reduce competition. " +
                "Repeat weeding at six weeks if necessary and keep the field clean.",
                advisor.rows[0]?.user_id || null
            ]
        );
    }

    const existingListings = await pool.query(
        "SELECT COUNT(*) AS total FROM market_listings"
    );

    if (Number(existingListings.rows[0].total) === 0) {
        const listings = [
            ["Fresh maize cobs", "Well matured maize, dried and sorted.", "produce", 20, "bags", 120000, "Mukono", "0772000001", "available"],
            ["Bean seed - NABE 14", "Certified bean seed, high germination.", "seeds", 50, "packets", 8000, "Kabale", "0772000001", "available"],
            ["Tomato seedlings", "Healthy grafted tomato seedlings, 3 weeks old.", "seedlings", 300, "pieces", 1500, "Mbarara", "0772000001", "available"],
            ["NPK fertiliser", "Compound fertiliser for maize and beans.", "fertilizer", 10, "bags", 185000, "Gulu", "0772000001", "sold"]
        ];

        for (const [title, description, category, quantity, unit, price, district, phone, status] of listings) {
            await pool.query(
                `INSERT INTO market_listings
                    (seller_id, title, description, category, quantity, unit,
                     price, district, contact_phone, status)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
                [farmer.rows[0].user_id, title, description, category, quantity, unit, price, district, phone, status]
            );
        }
    }

    const counts = await pool.query(
        `SELECT
            (SELECT COUNT(*) FROM users) AS users,
            (SELECT COUNT(*) FROM advisories) AS advisories,
            (SELECT COUNT(*) FROM market_listings) AS listings`
    );

    console.log("Dev seed complete:", counts.rows[0]);
    console.log(`Test accounts (password: ${PASSWORD}):`);
    console.log("  farmer@example.com  (farmer)");
    console.log("  advisor@example.com (advisor)");
    console.log("  admin@example.com   (admin)");
    process.exit(0);
}

main().catch((error) => {
    console.error("Seed failed:", error.message);
    process.exit(1);
});
