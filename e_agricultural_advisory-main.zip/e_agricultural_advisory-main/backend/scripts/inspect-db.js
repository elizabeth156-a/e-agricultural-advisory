// Read-only helper: prints the live PostgreSQL database schema
// (tables, columns, keys, foreign keys).
const pool = require("../config/db");

(async () => {
    try {
        const tables = await pool.query(
            `SELECT c.relname AS table_name,
                    GREATEST(c.reltuples::bigint, 0) AS table_rows
             FROM pg_class c
             JOIN pg_namespace n ON n.oid = c.relnamespace
             WHERE n.nspname = 'public'
               AND c.relkind = 'r'
             ORDER BY c.relname`
        );

        console.log("=== TABLES ===");
        for (const t of tables.rows) {
            console.log(`- ${t.table_name} (~${t.table_rows} rows)`);
        }

        for (const t of tables.rows) {
            const cols = await pool.query(
                `SELECT column_name,
                        data_type,
                        character_maximum_length,
                        is_nullable,
                        column_default,
                        is_identity
                 FROM information_schema.columns
                 WHERE table_schema = 'public' AND table_name = $1
                 ORDER BY ordinal_position`,
                [t.table_name]
            );
            console.log(`\n=== ${t.table_name} ===`);
            for (const c of cols.rows) {
                const type =
                    c.character_maximum_length != null
                        ? `${c.data_type}(${c.character_maximum_length})`
                        : c.data_type;
                console.log(
                    `  ${c.column_name}: ${type} ${c.is_nullable === "NO" ? "NOT NULL" : ""} ${c.is_identity === "YES" ? "identity" : ""} ${c.column_default ? `default=${c.column_default}` : ""}`
                );
            }

            const indexes = await pool.query(
                `SELECT indexname, indexdef
                 FROM pg_indexes
                 WHERE schemaname = 'public' AND tablename = $1
                 ORDER BY indexname`,
                [t.table_name]
            );
            for (const k of indexes.rows) {
                console.log(`  KEY ${k.indexname}: ${k.indexdef}`);
            }

            const fks = await pool.query(
                `SELECT tc.constraint_name,
                        kcu.column_name,
                        ccu.table_name AS referenced_table_name,
                        ccu.column_name AS referenced_column_name
                 FROM information_schema.table_constraints tc
                 JOIN information_schema.key_column_usage kcu
                   ON kcu.constraint_name = tc.constraint_name
                  AND kcu.table_schema = tc.table_schema
                 JOIN information_schema.constraint_column_usage ccu
                   ON ccu.constraint_name = tc.constraint_name
                  AND ccu.table_schema = tc.table_schema
                 WHERE tc.constraint_type = 'FOREIGN KEY'
                   AND tc.table_schema = 'public'
                   AND tc.table_name = $1`,
                [t.table_name]
            );
            for (const fk of fks.rows) {
                console.log(
                    `  FK ${fk.constraint_name}: ${fk.column_name} -> ${fk.referenced_table_name}.${fk.referenced_column_name}`
                );
            }
        }

        process.exit(0);
    } catch (error) {
        console.error("ERROR:", error.message);
        process.exit(1);
    }
})();
