// End-to-end API smoke tests against a running backend instance.
// Usage: node scripts/api-tests.js [baseUrl]
const BASE = (process.argv[2] || "http://localhost:5099").replace(/\/$/, "");

let passed = 0;
let failed = 0;
const failures = [];

function check(name, condition, detail) {
    if (condition) {
        passed += 1;
        console.log(`  ok  - ${name}`);
    } else {
        failed += 1;
        failures.push(name);
        console.log(`FAIL  - ${name}${detail ? ` :: ${detail}` : ""}`);
    }
}

async function req(method, path, { token, body } = {}) {
    const response = await fetch(`${BASE}${path}`, {
        method,
        headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: body ? JSON.stringify(body) : undefined
    });

    let data = null;
    try {
        data = await response.json();
    } catch {
        data = null;
    }

    return { status: response.status, data, headers: response.headers };
}

async function main() {
    console.log(`\nAPI tests against ${BASE}\n`);

    // --- health ---
    let r = await req("GET", "/");
    check("API root responds", r.status === 200 && r.data?.message);
    check(
        "security headers present (helmet)",
        (r.headers?.get("x-content-type-options") || "") === "nosniff",
        r.headers?.get("x-content-type-options")
    );

    r = await req("GET", "/api/test-db");
    check("database reachable", r.status === 200, JSON.stringify(r.data));

    // --- registration ---
    const stamp = Date.now();
    const farmerAEmail = `farmer.a.${stamp}@example.com`;
    const farmerBEmail = `farmer.b.${stamp}@example.com`;
    const advisorEmail = `advisor.${stamp}@example.com`;

    r = await req("POST", "/api/auth/register", {
        body: { full_name: "Farmer A", email: farmerAEmail, phone: "0772111001", password: "Password123!" }
    });
    check("register farmer A", r.status === 201, JSON.stringify(r.data));

    r = await req("POST", "/api/auth/register", {
        body: { full_name: "Farmer A", email: farmerAEmail, password: "Password123!" }
    });
    check("duplicate email rejected", r.status === 409);

    r = await req("POST", "/api/auth/register", {
        body: { full_name: "No Email", password: "Password123!" }
    });
    check("missing fields rejected", r.status === 400);

    r = await req("POST", "/api/auth/register", {
        body: { full_name: "Short PW", email: `short.${stamp}@example.com`, password: "abc" }
    });
    check("short password rejected -> 400", r.status === 400);

    r = await req("POST", "/api/auth/register", {
        body: { full_name: "Farmer B", email: farmerBEmail, phone: "0772111002", password: "Password123!" }
    });
    check("register farmer B", r.status === 201, JSON.stringify(r.data));

    r = await req("POST", "/api/auth/register", {
        body: { full_name: "Local Advisor", email: advisorEmail, phone: "0772111003", password: "Password123!" }
    });
    check("register advisor (seeded as farmer; role escalation is not allowed)", r.status === 201);

    // --- login ---
    r = await req("POST", "/api/auth/login", {
        body: { email: farmerAEmail, password: "Password123!" }
    });
    check("farmer A login", r.status === 200 && r.data?.token, JSON.stringify(r.data));
    const tokenA = r.data?.token;
    const userA = r.data?.user;
    check(
        "rate-limit headers on auth responses",
        Boolean(r.headers?.get("ratelimit-limit") || r.headers?.get("x-ratelimit-limit")),
        `limit=${r.headers?.get("ratelimit-limit")}`
    );

    r = await req("POST", "/api/auth/login", {
        body: { email: farmerAEmail, password: "wrong-password" }
    });
    check("wrong password rejected", r.status === 401);

    r = await req("POST", "/api/auth/login", {
        body: { email: `missing.${stamp}@example.com`, password: "Password123!" }
    });
    check("unknown email rejected", r.status === 401);

    r = await req("POST", "/api/auth/login", {
        body: { email: "farmer@example.com", password: "Password123!" }
    });
    check("seeded farmer login", r.status === 200 && r.data?.token);
    const tokenSeed = r.data?.token;

    r = await req("POST", "/api/auth/login", {
        body: { email: "advisor@example.com", password: "Password123!" }
    });
    check("seeded advisor login", r.status === 200 && r.data?.token);
    const tokenAdvisor = r.data?.token;

    r = await req("POST", "/api/auth/login", {
        body: { email: "admin@example.com", password: "Password123!" }
    });
    check("seeded admin login", r.status === 200 && r.data?.token);
    const tokenAdmin = r.data?.token;

    // --- market: public browse ---
    r = await req("GET", "/api/market");
    check("public market list", r.status === 200 && Array.isArray(r.data?.listings), JSON.stringify(r.data)?.slice(0, 120));
    const publicCount = r.data?.listings?.length || 0;
    // Seed data varies per environment (the seeder skips when real
    // listings exist), so only assert that the public list works.
    check("public listings visible", publicCount >= 1, `count=${publicCount}`);

    r = await req("GET", "/api/market?category=seeds");
    check("category filter", r.status === 200 &&
        (r.data?.listings || []).every((l) => l.category === "seeds"));

    r = await req("GET", "/api/market?district=kabale");
    check("district filter (case-insensitive)", r.status === 200 &&
        (r.data?.listings || []).every((l) => l.district.toLowerCase().includes("kabale")));

    r = await req("GET", "/api/market?search=maize");
    check("search filter", r.status === 200 && r.data?.listings?.length >= 1);

    r = await req("GET", "/api/market?sort=price_asc");
    const prices = (r.data?.listings || []).map((l) => Number(l.price));
    check("price ascending sort", r.status === 200 &&
        prices.every((p, i) => i === 0 || prices[i - 1] <= p));

    r = await req("GET", "/api/market?sort=price_desc");
    const pricesDesc = (r.data?.listings || []).map((l) => Number(l.price));
    check("price descending sort", r.status === 200 &&
        pricesDesc.every((p, i) => i === 0 || pricesDesc[i - 1] >= p));

    r = await req("GET", "/api/market?category=not-a-category");
    check("invalid category ignored safely", r.status === 200);

    // --- market: detail ---
    // Use a real listing from the list above (IDs differ per
    // environment; seed data is not guaranteed).
    const detailId =
        r.data?.listings?.[0]?.listing_id ??
        (await req("GET", "/api/market")).data?.listings?.[0]?.listing_id;
    r = await req("GET", `/api/market/${detailId}`);
    check(
        "listing detail",
        r.status === 200 && r.data?.listing?.listing_id === detailId,
        `id=${detailId} status=${r.status}`
    );

    r = await req("GET", "/api/market/999999");
    check("missing listing -> 404", r.status === 404);

    r = await req("GET", "/api/market/abc");
    check("invalid id -> 400", r.status === 400);

    // --- market: create ---
    r = await req("POST", "/api/market", {
        body: {
            title: "Test maize harvest",
            description: "Freshly harvested maize",
            category: "produce",
            quantity: 15,
            unit: "bags",
            price: 150000,
            district: "Mukono"
        }
    });
    check("create listing without auth -> 401", r.status === 401);

    const newListing = {
        title: "Test sukuma wiki seedlings",
        description: "Vigorous seedlings",
        image_url: "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
        category: "seedlings",
        quantity: 120,
        unit: "seedlings",
        price: 1200,
        district: "Wakiso",
        contact_phone: "0772111001"
    };

    r = await req("POST", "/api/market", { token: tokenA, body: newListing });
    check("farmer A creates listing", r.status === 201 && r.data?.listing_id, JSON.stringify(r.data));
    const listingId = r.data?.listing_id;

    r = await req("POST", "/api/market", {
        token: tokenA,
        body: { ...newListing, price: -5 }
    });
    check("negative price rejected", r.status === 400);

    r = await req("POST", "/api/market", {
        token: tokenA,
        body: { ...newListing, category: "cars" }
    });
    check("invalid category rejected", r.status === 400);

    r = await req("POST", "/api/market", {
        token: tokenA,
        body: { ...newListing, image_url: "javascript:alert(1)" }
    });
    check("malicious image value rejected", r.status === 400);

    r = await req("POST", "/api/market", {
        token: tokenA,
        body: { title: "", quantity: 1, unit: "bags", price: 100, district: "Mukono" }
    });
    check("missing title rejected", r.status === 400);

    // --- market: my listings ---
    r = await req("GET", "/api/market/mine", { token: tokenA });
    check("farmer A mine (auth)", r.status === 200 &&
        (r.data?.listings || []).every((l) => Number(l.seller_id) === Number(userA.user_id)));

    r = await req("GET", "/api/market/mine");
    check("mine without auth -> 401", r.status === 401);

    // --- market: ownership enforcement ---
    r = await req("POST", "/api/auth/login", { body: { email: farmerBEmail, password: "Password123!" } });
    const tokenB = r.data?.token;

    r = await req("PUT", `/api/market/${listingId}`, {
        token: tokenB,
        body: { ...newListing, title: "Hijacked title", status: "available" }
    });
    check("farmer B cannot edit farmer A's listing", r.status === 403, `status=${r.status}`);

    r = await req("DELETE", `/api/market/${listingId}`, { token: tokenB });
    check("farmer B cannot delete farmer A's listing", r.status === 403);

    // --- market: owner update / status ---
    r = await req("PUT", `/api/market/${listingId}`, {
        token: tokenA,
        body: { ...newListing, title: "Updated title", status: "sold" }
    });
    check("owner updates listing", r.status === 200, JSON.stringify(r.data));

    r = await req("GET", `/api/market/${listingId}`);
    check("update is persisted", r.status === 200 &&
        r.data?.listing?.title === "Updated title" &&
        r.data?.listing?.status === "sold");

    r = await req("GET", "/api/market");
    check("sold listing hidden from public browse",
        r.status === 200 && !(r.data?.listings || []).some((l) => l.listing_id === listingId));

    r = await req("GET", "/api/market/mine", { token: tokenA });
    check("owner still sees sold listing in mine",
        r.status === 200 && (r.data?.listings || []).some((l) => l.listing_id === listingId));

    r = await req("GET", `/api/market/${listingId}`);
    check("detail includes image_url", r.status === 200 && typeof r.data?.listing?.image_url === "string");

    // --- market: advisor cannot publish ---
    r = await req("POST", "/api/market", { token: tokenAdvisor, body: newListing });
    check("non-farmer role cannot publish", r.status === 403);

    // --- market: delete ---
    r = await req("DELETE", `/api/market/${listingId}`, { token: tokenA });
    check("owner deletes listing", r.status === 200, JSON.stringify(r.data));

    r = await req("GET", `/api/market/${listingId}`);
    check("deleted listing -> 404", r.status === 404);

    // --- weather ---
    r = await req("GET", "/api/weather?latitude=0.35&longitude=32.58");
    check("weather for Kampala", r.status === 200 && r.data?.current && r.data?.daily, JSON.stringify(r.data)?.slice(0, 100));
    check(
        "current weather includes weather_code",
        r.status === 200 && r.data?.current?.weather_code !== undefined,
        JSON.stringify(r.data?.current)
    );
    check(
        "farming advice returned",
        r.status === 200 && Array.isArray(r.data?.farmingAdvice) && r.data.farmingAdvice.length > 0
    );

    r = await req("GET", "/api/weather?latitude=51.5&longitude=-0.12");
    check("location outside Uganda rejected", r.status === 400);

    r = await req("GET", "/api/weather?latitude=abc&longitude=abc");
    check("invalid coordinates rejected", r.status === 400);

    // --- security: token handling ---
    r = await req("GET", "/api/market/mine", { token: "not.a.real.token" });
    check("garbage token rejected", r.status === 401);

    // --- chat: rooms ---
    r = await req("GET", "/api/chat/rooms");
    check("chat rooms without auth -> 401", r.status === 401);

    r = await req("GET", "/api/chat/rooms", { token: tokenA });
    check("chat rooms list", r.status === 200 && Array.isArray(r.data?.rooms),
        JSON.stringify(r.data)?.slice(0, 150));
    const roomCount = r.data?.rooms?.length || 0;
    check("seeded discussion rooms present", roomCount >= 7, `count=${roomCount}`);
    const firstRoom = r.data?.rooms?.[0]?.room_id;

    r = await req("GET", "/api/chat/rooms", { token: "not.a.real.token" });
    check("chat rooms garbage token -> 401", r.status === 401);

    // --- chat: messages ---
    r = await req("GET", `/api/chat/rooms/${firstRoom}/messages`, { token: tokenA });
    check("room messages load", r.status === 200 && Array.isArray(r.data?.messages),
        JSON.stringify(r.data)?.slice(0, 150));

    r = await req("GET", `/api/chat/rooms/${firstRoom}/messages`);
    check("messages without auth -> 401", r.status === 401);

    r = await req("GET", "/api/chat/rooms/999999/messages", { token: tokenA });
    check("missing room -> 404", r.status === 404);

    r = await req("GET", "/api/chat/rooms/abc/messages", { token: tokenA });
    check("invalid room id -> 400", r.status === 400);

    r = await req("POST", `/api/chat/rooms/${firstRoom}/messages`, {
        token: tokenA,
        body: { body: "" }
    });
    check("empty message rejected", r.status === 400);

    r = await req("POST", `/api/chat/rooms/${firstRoom}/messages`, {
        token: tokenA,
        body: { body: "x".repeat(5001) }
    });
    check("over-long message rejected", r.status === 400);

    r = await req("POST", `/api/chat/rooms/${firstRoom}/messages`, {
        token: tokenA,
        body: { body: "Hello from Farmer A, testing the chatroom." }
    });
    check("farmer sends message", r.status === 201 && r.data?.message?.message_id,
        JSON.stringify(r.data));
    const messageA = r.data?.message;

    r = await req("POST", `/api/chat/rooms/${firstRoom}/messages`, {
        token: tokenSeed,
        body: { body: "A reply from the seeded farmer account." }
    });
    check("second message from another user", r.status === 201);
    const messageB = r.data?.message;

    r = await req("GET", `/api/chat/rooms/${firstRoom}/messages`, { token: tokenA });
    check("messages include both senders", r.status === 200 &&
        (r.data?.messages || []).some((m) => m.message_id === messageA.message_id) &&
        (r.data?.messages || []).some((m) => m.message_id === messageB.message_id));
    check("messages carry sender names and roles",
        r.status === 200 &&
        (r.data?.messages || []).every((m) => m.sender_name && m.sender_role));

    // ordering: oldest first
    const ids = (r.data?.messages || []).map((m) => m.message_id);
    check("messages ordered oldest first",
        ids.every((id, i) => i === 0 || ids[i - 1] <= id));

    // --- chat: read pointer ---
    r = await req("POST", `/api/chat/rooms/${firstRoom}/read`, {
        token: tokenA,
        body: { last_read_message_id: messageB.message_id }
    });
    check("update read position", r.status === 200);

    r = await req("POST", `/api/chat/rooms/${firstRoom}/read`, {
        token: tokenA,
        body: { last_read_message_id: "junk" }
    });
    check("invalid read position rejected", r.status === 400);

    // --- chat: reporting ---
    r = await req("POST", `/api/chat/messages/${messageB.message_id}/report`, {
        token: tokenA,
        body: { reason: "" }
    });
    check("report without reason rejected", r.status === 400);

    r = await req("POST", `/api/chat/messages/${messageB.message_id}/report`, {
        token: tokenA,
        body: { reason: "Off-topic advertising" }
    });
    check("farmer reports message", r.status === 201);

    r = await req("POST", `/api/chat/messages/${messageB.message_id}/report`, {
        token: tokenA,
        body: { reason: "Duplicate report attempt" }
    });
    check("duplicate report upserts (no 500)", r.status === 201);

    r = await req("POST", `/api/chat/messages/${messageB.message_id}/report`, {
        token: tokenAdvisor,
        body: { reason: "Advisor also reports" }
    });
    check("second reporter can report same message", r.status === 201);

    // --- chat: RBAC on moderation ---
    r = await req("GET", "/api/chat/reports?status=open", { token: tokenA });
    check("farmer cannot list reports -> 403", r.status === 403);

    r = await req("GET", "/api/chat/reports?status=open", { token: tokenAdvisor });
    check("advisor cannot list reports -> 403", r.status === 403);

    r = await req("GET", "/api/chat/reports?status=open");
    check("reports without auth -> 401", r.status === 401);

    r = await req("POST", "/api/chat/rooms", {
        token: tokenA,
        body: { name: "Sneaky Room" }
    });
    check("farmer cannot create rooms -> 403", r.status === 403);

    r = await req("DELETE", `/api/chat/messages/${messageA.message_id}`, { token: tokenSeed });
    check("farmer cannot delete messages -> 403", r.status === 403);

    // --- chat: admin moderation flow ---
    r = await req("GET", "/api/chat/reports?status=open", { token: tokenAdmin });
    check("admin lists open reports", r.status === 200 && r.data?.reports?.length >= 1,
        JSON.stringify(r.data)?.slice(0, 150));
    const openReport = r.data?.reports?.[0];

    r = await req("PATCH", `/api/chat/reports/${openReport.report_id}`, {
        token: tokenAdmin,
        body: { status: "reviewed" }
    });
    check("admin marks report reviewed", r.status === 200);

    r = await req("PATCH", `/api/chat/reports/${openReport.report_id}`, {
        token: tokenA,
        body: { status: "dismissed" }
    });
    check("farmer cannot update reports -> 403", r.status === 403);

    r = await req("PATCH", `/api/chat/reports/${openReport.report_id}`, {
        token: tokenAdmin,
        body: { status: "banana" }
    });
    check("invalid report status rejected", r.status === 400);

    r = await req("DELETE", `/api/chat/messages/${messageB.message_id}`, { token: tokenAdmin });
    check("admin deletes reported message", r.status === 200);

    r = await req("GET", `/api/chat/rooms/${firstRoom}/messages`, { token: tokenA });
    check("deleted message gone", r.status === 200 &&
        !(r.data?.messages || []).some((m) => m.message_id === messageB.message_id));

    // --- chat: admin room management ---
    r = await req("POST", "/api/chat/rooms", {
        token: tokenAdmin,
        body: { name: `Test Room ${stamp}`, description: "Created by API tests", icon: "🧪" }
    });
    check("admin creates room", r.status === 201 && r.data?.room_id,
        JSON.stringify(r.data));
    const testRoomId = r.data?.room_id;

    r = await req("POST", "/api/chat/rooms", {
        token: tokenAdmin,
        body: { name: `Test Room ${stamp}` }
    });
    check("duplicate room name rejected", r.status === 409);

    r = await req("POST", "/api/chat/rooms", {
        token: tokenAdmin,
        body: { name: "" }
    });
    check("empty room name rejected", r.status === 400);

    r = await req("PATCH", `/api/chat/rooms/${testRoomId}`, {
        token: tokenAdmin,
        body: { is_active: false }
    });
    check("admin closes room", r.status === 200);

    r = await req("POST", `/api/chat/rooms/${testRoomId}/messages`, {
        token: tokenA,
        body: { body: "Should not be allowed in a closed room" }
    });
    check("closed room hidden from farmers -> 404", r.status === 404);

    r = await req("POST", `/api/chat/rooms/${testRoomId}/messages`, {
        token: tokenAdmin,
        body: { body: "Should not be allowed in a closed room either" }
    });
    check("closed room rejects messages for admin too -> 403", r.status === 403);

    r = await req("GET", `/api/chat/rooms/${testRoomId}/messages`, { token: tokenA });
    check("farmer cannot see closed room -> 404", r.status === 404);

    r = await req("GET", `/api/chat/rooms/${testRoomId}/messages`, { token: tokenAdmin });
    check("admin can still see closed room", r.status === 200);

    r = await req("PATCH", `/api/chat/rooms/${testRoomId}`, {
        token: tokenAdmin,
        body: { is_active: true }
    });
    check("admin reopens room", r.status === 200);

    r = await req("PATCH", `/api/chat/rooms/999999`, {
        token: tokenAdmin,
        body: { is_active: false }
    });
    check("updating missing room -> 404", r.status === 404);

    r = await req("PATCH", `/api/chat/rooms/1`, {
        token: tokenA,
        body: { name: "Hijacked" }
    });
    check("farmer cannot edit rooms -> 403", r.status === 403);

    // --- advisories: public reading ---
    r = await req("GET", "/api/advisories");
    check("public advisories list", r.status === 200 && Array.isArray(r.data?.advisories), JSON.stringify(r.data)?.slice(0, 120));

    r = await req("GET", "/api/advisories/crops");
    check("public crop list", r.status === 200 && Array.isArray(r.data?.crops) && r.data.crops.length > 0, JSON.stringify(r.data)?.slice(0, 120));
    const cropId = r.data?.crops?.[0]?.crop_id;

    r = await req("GET", "/api/advisories?search=zzzz-no-such-advisory");
    check("advisory search with no matches", r.status === 200 && r.data?.count === 0);

    r = await req("GET", "/api/advisories/999999");
    check("missing advisory -> 404", r.status === 404);

    // --- advisories: authoring ---
    r = await req("POST", "/api/advisories", { token: tokenA, body: { title: "Nope", content: "Nope" } });
    check("farmer cannot publish advisories -> 403", r.status === 403);

    r = await req("POST", "/api/advisories");
    check("advisory create without auth -> 401", r.status === 401);

    r = await req("POST", "/api/advisories", {
        token: tokenAdvisor,
        body: { title: "", content: "" }
    });
    check("empty advisory rejected -> 400", r.status === 400);

    r = await req("POST", "/api/advisories", {
        token: tokenAdvisor,
        body: { title: "TEST-ADVISORY entry", content: "Test content for the suite.", crop_id: cropId, category: "planting" }
    });
    check("advisor publishes advisory", r.status === 201 && r.data?.advisory_id, JSON.stringify(r.data));
    const advisoryId = r.data?.advisory_id;

    r = await req("POST", "/api/advisories", {
        token: tokenAdvisor,
        body: { title: "Bad category", content: "x", category: "nonsense" }
    });
    check("invalid advisory category -> 400", r.status === 400);

    r = await req("GET", `/api/advisories/${advisoryId}`);
    check("advisory detail loads with crop and author", r.status === 200 && r.data?.advisory?.crop_name && r.data?.advisory?.author_name, JSON.stringify(r.data)?.slice(0, 160));

    r = await req("GET", `/api/advisories?crop=${encodeURIComponent(r.data.advisory.crop_name)}`);
    check("advisory crop filter works", r.status === 200 && r.data?.count >= 1);

    r = await req("GET", "/api/advisories?category=planting");
    check("advisory category filter works", r.status === 200 && r.data?.advisories?.every((a) => a.category === "planting"));

    r = await req("PUT", `/api/advisories/${advisoryId}`, {
        token: tokenAdmin,
        body: { title: "TEST-ADVISORY entry", content: "Updated test content.", category: "general" }
    });
    check("admin updates any advisory", r.status === 200, JSON.stringify(r.data));

    r = await req("DELETE", `/api/advisories/${advisoryId}`, { token: tokenSeed });
    check("farmer cannot delete advisories -> 403", r.status === 403);

    r = await req("DELETE", `/api/advisories/${advisoryId}`, { token: tokenAdvisor });
    check("author deletes own advisory", r.status === 200);

    r = await req("DELETE", `/api/advisories/${advisoryId}`, { token: tokenAdvisor });
    check("deleting missing advisory -> 404", r.status === 404);

    // --- pests: public reading ---
    r = await req("GET", "/api/pests");
    check("public pests list", r.status === 200 && Array.isArray(r.data?.pests) && r.data.pests.length >= 3, JSON.stringify(r.data)?.slice(0, 120));

    r = await req("GET", "/api/pests?type=disease");
    check("pest type filter", r.status === 200 && r.data?.pests?.every((p) => p.pest_type === "disease"));

    r = await req("GET", "/api/pests?search=armyworm");
    check("pest search finds armyworm", r.status === 200 && r.data?.count >= 1);

    r = await req("GET", "/api/pests/999999");
    check("missing pest -> 404", r.status === 404);

    // --- pests: authoring ---
    r = await req("POST", "/api/pests", { token: tokenA, body: { name: "Nope", pest_type: "pest", symptoms: "x", management: "y" } });
    check("farmer cannot add pest entries -> 403", r.status === 403);

    r = await req("POST", "/api/pests", {
        token: tokenAdvisor,
        body: { name: `Test Pest ${stamp}`, pest_type: "pest", summary: "Test entry", symptoms: "Test symptoms.", management: "Test management." }
    });
    check("advisor adds pest entry", r.status === 201 && r.data?.pest_id, JSON.stringify(r.data));
    const pestId = r.data?.pest_id;

    r = await req("POST", "/api/pests", {
        token: tokenAdvisor,
        body: { name: `Test Pest ${stamp}`, pest_type: "pest", symptoms: "x", management: "y" }
    });
    check("duplicate pest name -> 409", r.status === 409);

    r = await req("POST", "/api/pests", {
        token: tokenAdvisor,
        body: { name: `Bad Type ${stamp}`, pest_type: "virus", symptoms: "x", management: "y" }
    });
    check("invalid pest type -> 400", r.status === 400);

    r = await req("PUT", `/api/pests/${pestId}`, {
        token: tokenAdmin,
        body: { name: `Test Pest ${stamp}`, pest_type: "pest", symptoms: "Updated symptoms.", management: "Updated management." }
    });
    check("admin updates pest entry", r.status === 200);

    r = await req("DELETE", `/api/pests/${pestId}`, { token: tokenA });
    check("farmer cannot delete pest entries -> 403", r.status === 403);

    r = await req("DELETE", `/api/pests/${pestId}`, { token: tokenAdvisor });
    check("advisor deletes pest entry", r.status === 200);

    // --- profile ---
    r = await req("GET", "/api/auth/me");
    check("profile without auth -> 401", r.status === 401);

    r = await req("GET", "/api/auth/me", { token: tokenA });
    check("profile loads for signed-in user", r.status === 200 && r.data?.user?.email === farmerAEmail, JSON.stringify(r.data)?.slice(0, 160));

    r = await req("PATCH", "/api/auth/me", {
        token: tokenA,
        body: { district: "Mukono", bio: "Grows maize and beans.", phone: "0772111001" }
    });
    check("profile update", r.status === 200 && r.data?.user?.district === "Mukono", JSON.stringify(r.data)?.slice(0, 160));

    r = await req("GET", "/api/auth/me", { token: tokenA });
    check("profile update persisted", r.status === 200 && r.data?.user?.bio === "Grows maize and beans.");

    r = await req("PATCH", "/api/auth/me", { token: tokenA, body: { district: "x".repeat(100) } });
    check("overlong district rejected -> 400", r.status === 400);

    r = await req("PATCH", "/api/auth/me", { token: tokenA, body: { current_password: "wrong", new_password: "NewPass123!" } });
    check("password change with wrong current -> 401", r.status === 401);

    r = await req("PATCH", "/api/auth/me", { token: tokenA, body: { current_password: "Password123!", new_password: "short" } });
    check("short new password rejected -> 400", r.status === 400);

    r = await req("PATCH", "/api/auth/me", {
        token: tokenA,
        body: { current_password: "Password123!", new_password: "NewPass123!" }
    });
    check("password change succeeds", r.status === 200, JSON.stringify(r.data));

    r = await req("POST", "/api/auth/login", { body: { email: farmerAEmail, password: "Password123!" } });
    check("old password no longer works", r.status === 401);

    r = await req("POST", "/api/auth/login", { body: { email: farmerAEmail, password: "NewPass123!" } });
    check("new password logs in", r.status === 200 && r.data?.user?.district === "Mukono", JSON.stringify(r.data)?.slice(0, 160));
    const tokenA2 = r.data?.token;

    // --- ask advisor ---
    r = await req("POST", "/api/questions");
    check("question without auth -> 401", r.status === 401);

    r = await req("POST", "/api/questions", { token: tokenA2, body: { title: "", body: "" } });
    check("empty question rejected -> 400", r.status === 400);

    r = await req("POST", "/api/questions", {
        token: tokenA2,
        body: { title: "TEST question: yellow leaves", body: "My maize leaves are turning yellow.", crop_id: cropId }
    });
    check("farmer asks question", r.status === 201 && r.data?.question_id, JSON.stringify(r.data));
    const questionId = r.data?.question_id;

    r = await req("GET", "/api/questions", { token: tokenA2 });
    check("farmer cannot open the advisor queue -> 403", r.status === 403);

    r = await req("GET", "/api/questions/mine", { token: tokenA2 });
    check("farmer sees own question as open", r.status === 200 && r.data?.questions?.[0]?.status === "open" && Array.isArray(r.data?.questions?.[0]?.answers), JSON.stringify(r.data)?.slice(0, 160));

    r = await req("GET", "/api/questions", { token: tokenAdvisor });
    check("advisor sees the question queue", r.status === 200 && r.data?.questions?.some((q) => q.question_id === questionId), JSON.stringify(r.data)?.slice(0, 160));

    r = await req("GET", "/api/questions?status=open", { token: tokenAdvisor });
    check("queue status filter", r.status === 200 && r.data?.questions?.every((q) => q.status === "open"));

    r = await req("POST", `/api/questions/${questionId}/answers`, { token: tokenA2, body: { body: "Not allowed to self-answer as a farmer test." } });
    check("farmer cannot answer questions -> 403", r.status === 403);

    r = await req("POST", `/api/questions/${questionId}/answers`, { token: tokenAdvisor, body: { body: "" } });
    check("empty answer rejected -> 400", r.status === 400);

    r = await req("POST", `/api/questions/${questionId}/answers`, {
        token: tokenAdvisor,
        body: { body: "Check soil moisture and nitrogen levels before applying fertiliser." }
    });
    check("advisor answers question", r.status === 201 && r.data?.answer_id, JSON.stringify(r.data));

    r = await req("GET", "/api/questions/mine", { token: tokenA2 });
    const answeredQuestion = r.data?.questions?.find((q) => q.question_id === questionId);
    check("question marked answered with advisor reply", answeredQuestion?.status === "answered" && answeredQuestion?.answers?.length === 1 && answeredQuestion.answers[0].advisor_name, JSON.stringify(answeredQuestion)?.slice(0, 200));

    r = await req("GET", "/api/notifications", { token: tokenA2 });
    check("answer notification created", r.status === 200 && r.data?.unread >= 1 && r.data?.notifications?.some((n) => n.type === "answer"), JSON.stringify(r.data)?.slice(0, 200));
    const notifId = r.data?.notifications?.[0]?.notification_id;

    r = await req("PATCH", `/api/notifications/${notifId}/read`, { token: tokenA });
    check("mark one notification read", r.status === 200);

    r = await req("PATCH", `/api/notifications/999999/read`, { token: tokenA2 });
    check("missing notification -> 404", r.status === 404);

    r = await req("POST", "/api/notifications/read-all", { token: tokenA2 });
    check("mark all notifications read", r.status === 200 && r.data?.updated >= 0, JSON.stringify(r.data));

    r = await req("GET", "/api/notifications", { token: tokenA2 });
    check("unread count reaches zero", r.status === 200 && r.data?.unread === 0);

    r = await req("GET", "/api/notifications");
    check("notifications without auth -> 401", r.status === 401);

    r = await req("POST", `/api/questions/${questionId}/answers`, { token: tokenAdmin, body: { body: "Admin follow-up." } });
    check("second answer allowed", r.status === 201);

    r = await req("PATCH", `/api/questions/${questionId}`, { token: tokenA2, body: { status: "closed" } });
    check("owner closes own question", r.status === 200);

    r = await req("POST", `/api/questions/${questionId}/answers`, { token: tokenAdvisor, body: { body: "Too late." } });
    check("closed question rejects answers -> 400", r.status === 400);

    r = await req("PATCH", `/api/questions/${questionId}`, { token: tokenA2, body: { status: "open" } });
    check("owner cannot reopen -> 403", r.status === 403);

    r = await req("PATCH", `/api/questions/${questionId}`, { token: tokenAdvisor, body: { status: "open" } });
    check("advisor reopens question", r.status === 200);

    r = await req("PATCH", `/api/questions/999999`, { token: tokenAdvisor, body: { status: "closed" } });
    check("missing question -> 404", r.status === 404);

    r = await req("PATCH", `/api/questions/${questionId}`, { token: tokenSeed, body: { status: "closed" } });
    check("other farmer cannot close question -> 403", r.status === 403);

    // --- dashboard stats ---
    r = await req("GET", "/api/dashboard/stats");
    check("dashboard stats without auth -> 401", r.status === 401);

    r = await req("GET", "/api/dashboard/stats", { token: tokenA2 });
    check(
        "dashboard stats load with real counts",
        r.status === 200 &&
            typeof r.data?.stats?.advisories_total === "number" &&
            typeof r.data?.stats?.unread_notifications === "number" &&
            typeof r.data?.stats?.my_questions === "number" &&
            Array.isArray(r.data?.stats?.latest_advisories),
        JSON.stringify(r.data)?.slice(0, 200)
    );
    check("dashboard reflects the asked question", r.data?.stats?.my_questions >= 1);

    r = await req("GET", "/api/dashboard/stats", { token: tokenAdvisor });
    check("advisor dashboard shows pending questions", r.status === 200 && r.data?.stats?.pending_questions >= 0, JSON.stringify(r.data)?.slice(0, 160));

    // --- 404 ---
    r = await req("GET", "/api/definitely-not-a-route");
    check("unknown API route -> 404", r.status === 404);

    console.log(`\nResults: ${passed} passed, ${failed} failed\n`);
    if (failed > 0) {
        console.log("Failed checks:");
        failures.forEach((name) => console.log(`  - ${name}`));
        process.exit(1);
    }
    process.exit(0);
}

main().catch((error) => {
    console.error("Test run crashed:", error);
    process.exit(1);
});
