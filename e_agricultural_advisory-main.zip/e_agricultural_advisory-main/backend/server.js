
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
require("dotenv").config();

const pool = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const weatherRoutes = require("./routes/weatherroute");
const marketRoutes = require("./routes/marketRoutes");
const chatRoutes = require("./routes/chatRoutes");
const advisoryRoutes = require("./routes/advisoryRoutes");
const pestRoutes = require("./routes/pestRoutes");
const questionRoutes = require("./routes/questionRoutes");
const notificationRoutes = require("./routes/notificationRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");

const app = express();
const PORT = process.env.PORT || 5000;

// Render sits behind a proxy; trust the first hop so rate limiting
// sees each client's real IP instead of sharing the proxy's.
app.set("trust proxy", 1);

// CORS: when CORS_ORIGIN is set (comma-separated list of origins)
// only those origins may call the API. Without it the API stays
// open so existing deployments keep working.
const corsOrigins = (process.env.CORS_ORIGIN || "")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);

// Middleware
// Security headers. The API is consumed cross-origin by the
// Vercel frontend, so the resource policy must allow it.
app.use(
    helmet({
        crossOriginResourcePolicy: { policy: "cross-origin" }
    })
);
app.use(
    cors(corsOrigins.length > 0 ? { origin: corsOrigins } : {})
);
// Raised limit so farmers can submit compressed product images
// stored as data:image URLs (no server-side file storage).
app.use(express.json({ limit: "3mb" }));

// API routes
app.use("/api/auth", authRoutes);
app.use("/api/weather", weatherRoutes);
app.use("/api/market", marketRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/advisories", advisoryRoutes);
app.use("/api/pests", pestRoutes);
app.use("/api/questions", questionRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/dashboard", dashboardRoutes);

// Home route
app.get("/", (req, res) => {
    res.json({
        message: "E-Agricultural Advisory System API is running"
    });
});

// Test route
app.get("/test", (req, res) => {
    res.status(200).json({
        message: "TEST ROUTE WORKS"
    });
});

// Test database connection
app.get("/api/test-db", async (req, res) => {
    try {
        const rows = await pool.query(
            "SELECT 1 AS result, current_database() AS database"
        );

        res.status(200).json({
            message: "PostgreSQL database connected successfully",
            database: rows.rows[0].database,
            result: rows.rows[0].result
        });
    } catch (error) {
        console.error(
            "Database connection error:",
            error.message
        );

        res.status(500).json({
            message: "Database connection failed",
            error: error.message
        });
    }
});

// Handle unknown routes
app.use((req, res) => {
    res.status(404).json({
        message: "Route not found",
        path: req.originalUrl
    });
});

// Start server
app.listen(PORT, () => {
    console.log(
        `E-Agricultural Advisory System API running on port ${PORT}`
    );
});
